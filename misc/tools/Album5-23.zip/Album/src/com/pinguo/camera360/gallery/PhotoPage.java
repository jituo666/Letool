/*
 * Copyright (C) 2010 The Android Open Source Project Licensed under the Apache
 * License, Version 2.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0 Unless required by applicable law
 * or agreed to in writing, software distributed under the License is
 * distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

package com.pinguo.camera360.gallery;

import com.pinguo.camera360.gallery.data.DataManager;
import com.pinguo.camera360.gallery.data.MediaItem;
import com.pinguo.camera360.gallery.data.MediaSet;
import com.pinguo.camera360.gallery.data.Path;
import com.pinguo.camera360.gallery.ui.AlbumActionBar;
import com.pinguo.camera360.gallery.ui.GLCanvas;
import com.pinguo.camera360.gallery.ui.GLRoot;
import com.pinguo.camera360.gallery.ui.GLView;
import com.pinguo.camera360.gallery.ui.PhotoFallbackEffect;
import com.pinguo.camera360.gallery.ui.PhotoView;
import com.pinguo.camera360.gallery.ui.PhotoSelector;
import com.pinguo.camera360.gallery.ui.SynchronizedHandler;
import com.pinguo.camera360.gallery.ui.GLRoot.OnGLIdleListener;
import com.pinguo.camera360.gallery.uitl.Log;
import com.pinguo.camera360.gallery.uitl.Utils;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;

public class PhotoPage extends ActivityState implements PhotoView.Listener, OrientationManager.Listener,
        View.OnClickListener {

    private static final String TAG = "PhotoPage";
    private static final int MSG_HIDE_BARS = 1;
    private static final int MSG_LOCK_ORIENTATION = 2;
    private static final int MSG_UNLOCK_ORIENTATION = 3;
    private static final int MSG_ON_FULL_SCREEN_CHANGED = 4;
    private static final int MSG_UNFREEZE_GLROOT = 6;
    private static final int UNFREEZE_GLROOT_TIMEOUT = 250;
    public static final String KEY_MEDIA_SET_PATH = "media-set-path";
    public static final String KEY_MEDIA_ITEM_PATH = "media-item-path";
    public static final String KEY_INDEX_HINT = "index-hint";
    public static final String KEY_OPEN_ANIMATION_RECT = "open-animation-rect";
    public static final String KEY_APP_BRIDGE = "app-bridge";
    public static final String KEY_TREAT_BACK_AS_UP = "treat-back-as-up";
    public static final String KEY_RETURN_INDEX_HINT = "return-index-hint";
    //
    private PhotoView mPhotoView;
    private PhotoPage.Model mModel;
    private Path mMediaSetPath;
    // mMediaSet could be null if there is no KEY_MEDIA_SET_PATH supplied.
    // E.g., viewing a photo in gmail attachment
    private MediaSet mOriginalSet;
    private int mCurrentIndex = 0;
    private int mTotalCount = 0;
    private Handler mHandler;
    private MediaItem mCurrentPhoto = null;
    // This is the original mSetPathString before adding the camera preview item.
    private OrientationManager mOrientationManager;
    private boolean mTreatBackAsUp;
    // The item that is deleted (but it can still be undeleted before commiting)
    private Path mDeletePath;
    private boolean mDeleteIsFocus; // whether the deleted item was in focus

    public static interface Model extends PhotoView.Model {

        public void resume();

        public void pause();

        public boolean isEmpty();

        public void setCurrentPhoto(Path path, int indexHint);
    }

    private final GLView mRootPane = new GLView() {

        @Override
        protected void renderBackground(GLCanvas view) {
            view.clearBuffer();
        }

        @Override
        protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
            mPhotoView.layout(0, 0, right - left, bottom - top);
        }
    };

    @Override
    public void onCreate(Bundle data, Bundle restoreState) {
        mPhotoView = new PhotoView(mActivity);
        mPhotoView.setListener(this);
        mRootPane.addComponent(mPhotoView);
        mOrientationManager = mActivity.getOrientationManager();
        mOrientationManager.addListener(this);
        mActivity.getGLRoot().setOrientationSource(mOrientationManager);
        mTreatBackAsUp = data.getBoolean(KEY_TREAT_BACK_AS_UP, false);
        //
        mMediaSetPath = new Path(data.getInt(DataManager.MEDIA_TYPE), data.getString(DataManager.MEDIA_PATH_ID));
        mOriginalSet = mActivity.getDataManager().getMediaSet(mMediaSetPath);
        mCurrentIndex = data.getInt(KEY_INDEX_HINT, 0);
        Log.i(TAG, "---------mCurrentIndex " + mCurrentIndex);
        PhotoDataAdapter pda = new PhotoDataAdapter(mActivity, mPhotoView, mOriginalSet, mCurrentIndex);
        mModel = pda;
        mPhotoView.setModel(mModel);
        pda.setDataListener(new PhotoDataAdapter.DataListener() {

            @Override
            public void onPhotoChanged(int index, String item) {
                mCurrentIndex = index;
                mActivity.getTopActionBar().setPhotoBrowseTitle(
                        mActivity.getResources().getString(R.string.album_full_image_browse) + "("
                                + (mCurrentIndex + 1) + "/" + mTotalCount + ")");
                if (item != null) {
                    MediaItem photo = mModel.getMediaItem(0);
                    if (photo != null)
                        updateCurrentPhoto(photo);
                }
                hideBars();
            }

            @Override
            public void onLoadingFinished() {
                if (!mModel.isEmpty()) {
                    MediaItem photo = mModel.getMediaItem(0);
                    if (photo != null)
                        updateCurrentPhoto(photo);
                }
            }

            @Override
            public void onLoadingStarted() {
                mTotalCount = mOriginalSet.getMediaItemCount();
                if (mCurrentIndex >= mTotalCount) {
                    mCurrentIndex = mTotalCount - 1;
                }
                mActivity.getTopActionBar().setPhotoBrowseTitle(
                        mActivity.getResources().getString(R.string.album_full_image_browse) + "("
                                + (mCurrentIndex + 1) + "/" + mTotalCount + ")");
            }
        });
        mHandler = new SynchronizedHandler(mActivity.getGLRoot()) {

            @Override
            public void handleMessage(Message message) {
                switch (message.what) {
                    case MSG_HIDE_BARS: {
                        hideBars();
                        break;
                    }
                    case MSG_LOCK_ORIENTATION: {
                        mOrientationManager.lockOrientation();
                        break;
                    }
                    case MSG_UNLOCK_ORIENTATION: {
                        mOrientationManager.unlockOrientation();
                        break;
                    }
                    case MSG_ON_FULL_SCREEN_CHANGED: {
                        break;
                    }
                    case MSG_UNFREEZE_GLROOT: {
                        mActivity.getGLRoot().unfreeze();
                        break;
                    }
                    default:
                        throw new AssertionError(message.what);
                }
            }
        };
        // start the opening animation only if it's not restored.
        if (restoreState == null) {
            mPhotoView.setOpenAnimationRect((Rect) data.getParcelable(KEY_OPEN_ANIMATION_RECT));
        }
    }

    private void updateCurrentPhoto(MediaItem photo) {
        if (mCurrentPhoto == photo)
            return;
        mCurrentPhoto = photo;
    }

    @Override
    public void onOrientationCompensationChanged() {
        mActivity.getGLRoot().requestLayoutContentPane();
    }

    @Override
    protected void onBackPressed() {
        // We are leaving this page. Set the result now.
        setResult();
        if (mTreatBackAsUp) {
            onUpPressed();
        } else {
            super.onBackPressed();
        }
    }

    private void onUpPressed() {
        if (mActivity.getStateManager().getStateCount() > 1) {
            super.onBackPressed();
            return;
        }
    }

    private void setResult() {
        Intent result = null;
        if (!mPhotoView.getFilmMode()) {
            result = new Intent();
            result.putExtra(KEY_RETURN_INDEX_HINT, mCurrentIndex);
        }
        setStateResult(Activity.RESULT_OK, result);
    }

    // ////////////////////////////////////////////////////////////////////////
    // AppBridge.Server interface
    // ////////////////////////////////////////////////////////////////////////
    // //////////////////////////////////////////////////////////////////////////
    // Callbacks from PhotoView
    // //////////////////////////////////////////////////////////////////////////
    @Override
    public void onSingleTapUp(int x, int y) {
        MediaItem item = mModel.getMediaItem(0);
        if (item == null) {
            // item is not ready or it is camera preview, ignore
            return;
        }
        toggleBars();
    }

    private boolean mShowBars = true;

    private void toggleBars() {
        if (mShowBars) {
            hideBars();
        } else {
            showBars();
        }
    }

    private void showBars() {
        if (mShowBars)
            return;
        mShowBars = true;
        mOrientationManager.unlockOrientation();
        mActivity.getTopActionBar().setActionBarMode(AlbumActionBar.ACION_MODE_PHOTO_EDIT);
        //mActivity.getGLRoot().setLightsOutMode(false);
    }

    private void hideBars() {
        if (!mShowBars)
            return;
        mShowBars = false;
        mActivity.getTopActionBar().setActionBarMode(AlbumActionBar.ACION_MODE_PHOTO_BROWSE);
        //mActivity.getGLRoot().setLightsOutMode(true);
    }

    @Override
    public void lockOrientation() {
        mHandler.sendEmptyMessage(MSG_LOCK_ORIENTATION);
    }

    @Override
    public void unlockOrientation() {
        mHandler.sendEmptyMessage(MSG_UNLOCK_ORIENTATION);
    }

    @Override
    public void onFullScreenChanged(boolean full) {
        Message m = mHandler.obtainMessage(MSG_ON_FULL_SCREEN_CHANGED, full ? 1 : 0, 0);
        m.sendToTarget();
    }

    // How we do delete/undo:
    //
    // When the user choose to delete a media item, we just tell the
    // FilterDeleteSet to hide that item. If the user choose to undo it, we
    // again tell FilterDeleteSet not to hide it. If the user choose to commit
    // the deletion, we then actually delete the media item.
    // @Override
    public void onDeleteImage(Path path, int offset) {
        onCommitDeleteImage(); // commit the previous deletion
        mDeletePath = path;
        mDeleteIsFocus = (offset == 0);
    }

    @Override
    public void onUndoDeleteImage() {
        if (mDeletePath == null)
            return;
        // If the deletion was done on the focused item, we want the model to
        // focus on it when it is undeleted.
        if (mDeleteIsFocus)
            mModel.setFocusHintPath(mDeletePath);
        mDeletePath = null;
    }

    @Override
    public void onCommitDeleteImage() {
        if (mDeletePath == null)
            return;
        mDeletePath = null;
    }

    @Override
    public void onCurrentImageUpdated() {
        mActivity.getGLRoot().unfreeze();
    }

    private class PreparePhotoFallback implements OnGLIdleListener {

        private PhotoFallbackEffect mPhotoFallback = new PhotoFallbackEffect();
        private boolean mResultReady = false;

        public synchronized PhotoFallbackEffect get() {
            while (!mResultReady) {
                Utils.waitWithoutInterrupt(this);
            }
            return mPhotoFallback;
        }

        @Override
        public boolean onGLIdle(GLCanvas canvas, boolean renderRequested) {
            mPhotoFallback = mPhotoView.buildFallbackEffect(mRootPane, canvas);
            synchronized (this) {
                mResultReady = true;
                notifyAll();
            }
            return false;
        }
    }

    private void preparePhotoFallbackView() {
        GLRoot root = mActivity.getGLRoot();
        PreparePhotoFallback task = new PreparePhotoFallback();
        root.unlockRenderThread();
        PhotoFallbackEffect anim;
        try {
            root.addOnGLIdleListener(task);
            anim = task.get();
        } finally {
            root.lockRenderThread();
        }
        mActivity.getTransitionStore().put(AlbumPage.KEY_RESUME_ANIMATION, anim);
    }

    @Override
    public void onPause() {
        super.onPause();
        mActivity.getGLRoot().unfreeze();
        mHandler.removeMessages(MSG_UNFREEZE_GLROOT);
        if (isFinishing())
            preparePhotoFallbackView();
        mPhotoView.pause();
        mModel.pause();
        onCommitDeleteImage();
    }

    @Override
    protected void onResume() {
        super.onResume();
        mActivity.getTopActionBar().setActionBarMode(AlbumActionBar.ACION_MODE_PHOTO_EDIT);
        mActivity.getTopActionBar().setBackListener(this);
        mActivity.getGLRoot().freeze();
        setContentPane(mRootPane);
        mModel.resume();
        mPhotoView.resume();
        mHandler.sendEmptyMessageDelayed(MSG_UNFREEZE_GLROOT, UNFREEZE_GLROOT_TIMEOUT);
    }

    @Override
    protected void onDestroy() {
        mOrientationManager.removeListener(this);
        mActivity.getGLRoot().setOrientationSource(null);
        // Remove all pending messages.
        mHandler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    @Override
    public void onClick(View v) {
        mActivity.getGLRoot().lockRenderThread();
        onUpPressed();
        mActivity.getGLRoot().unlockRenderThread();
    }
}
