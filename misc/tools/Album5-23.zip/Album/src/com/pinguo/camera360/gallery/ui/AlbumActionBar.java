package com.pinguo.camera360.gallery.ui;

import com.pinguo.camera360.gallery.ActivityState;
import com.pinguo.camera360.gallery.AlbumPage;
import com.pinguo.camera360.gallery.AlbumSetPage;
import com.pinguo.camera360.gallery.R;
import com.pinguo.camera360.gallery.RootActivity;
import com.pinguo.camera360.gallery.data.DataManager;
import com.pinguo.camera360.gallery.data.Path;
import com.pinguo.camera360.gallery.surpport.PuzzlePickerAdapter;
import com.pinguo.camera360.gallery.ui.PhotoPicker.PuzzleItem;
import com.pinguo.camera360.gallery.uitl.Future;
import com.pinguo.camera360.gallery.uitl.Log;
import com.pinguo.camera360.gallery.uitl.ThreadPool.Job;
import com.pinguo.camera360.gallery.uitl.ThreadPool.JobContext;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnClickListener;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.LinearLayout.LayoutParams;
import java.util.ArrayList;
import java.util.HashMap;

public class AlbumActionBar implements View.OnClickListener {

	private static final String TAG = "AlbumActionBar";
	// action modes
	public static final int ACION_MODE_NONE = 1 << 0;
	public static final int ACION_MODE_NAVIGATION = 1 << 1;
	public static final int ACION_MODE_SELECTION = 1 << 2;
	public static final int ACION_MODE_ALBUM_BROWSE = 1 << 3;
	public static final int ACION_MODE_OPERATIONS = 1 << 4;
	public static final int ACION_MODE_PUZZLE_PICK = 1 << 5;
	public static final int ACION_MODE_PHOTO_EDIT = 1 << 6;
	public static final int ACION_MODE_PHOTO_BROWSE = 1 << 7;
	//
	private static final int MSG_TASK_COMPLETE = 1;
	private static final int MSG_TASK_UPDATE = 2;
	private static final int MSG_DO_SHARE = 3;
	//
	public static final int EXECUTION_RESULT_SUCCESS = 1;
	public static final int EXECUTION_RESULT_FAIL = 2;
	public static final int EXECUTION_RESULT_CANCEL = 3;
	//
	private final Handler mHandler;
	private int mCurrentActionMode = 0;
	private PhotoSelector mPhotoSelector;
	private PhotoPicker mPhotoPicker;
	private ActivityState mActivityState;
	private RootActivity mActivity;
	private Future<?> mTask;
	private boolean mWaitOnStop;
	// // header bar
	private View mAlbumHeaderBar;
	// navigation panel
	private View mAlbumNavigatePanel;
	private Button mC360Album;
	private Button mSystemAlbumSet;
	// select panel
	private View mItemSelectPanel;
	private TextView mSelectCount;
	private ImageView mBackFromSelection;
	private Button mDelete;
	// album browse panel
	private View mOtherAlbumBrowsePanel;
	private ImageView mBackFromPhotoPage;
	private TextView mSystemAlumTitle;
	// //
	private View mAlbumRooterBar; // rooter bar
	// composite panel
	private View mOperationsPanel;
	private Button mCloudAlbum;
	private Button mPicPuzzle;
	private Button mTemplatePuzzle;
	//
	private View mAlbumPuzzlePickPanel;
	private Button mPuzzleCancel;
	private Button mPuzzleSubmit;
	private TextView mPuzzleTitle;
	private GridView mPuzzleGridview;
	//
	private View mPhotoEditHeaderPanel;
	private ImageView mBackFromBigPic;
	private TextView mPhotoIndex;
	private ImageView mStartCamera;
	//
	private View mPhotoEditRooterPanel;
	private Button mShare;
	private Button mEffect;
	private Button mCompundEffect;
	private Button mPhotoDelete;
	//
	private ProgressDialog mDialog;
	private PuzzlePickerAdapter mPuzzlePickerAdapter;
	private OnItemClickListener mOnPuzzleItemClickListener = new OnItemClickListener() {

		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position,
				long id) {
			mActivity.getGLRoot().lockRenderThread();
			mPhotoPicker.toggle(((PuzzleItem) mPuzzlePickerAdapter
					.getItem(position)).mPath);
			mActivity.getStateManager().getTopState().invalidate();
			mActivity.getGLRoot().unlockRenderThread();
		}
	};

	public AlbumActionBar(RootActivity activity) {
		mActivity = activity;
		// //////顶部
		mAlbumHeaderBar = activity.findViewById(R.id.operation_panel_header);
		// 1
		mAlbumNavigatePanel = activity
				.findViewById(R.id.top_bar_panel_navigation);
		mC360Album = (Button) activity
				.findViewById(R.id.top_bar_action_c360_album);
		mSystemAlbumSet = (Button) activity
				.findViewById(R.id.top_bar_action_other_album);
		// 2选择模式
		mItemSelectPanel = activity.findViewById(R.id.top_bar_panel_selection);
		mSelectCount = (TextView) activity
				.findViewById(R.id.top_bar_label_select_count);
		mBackFromSelection = (ImageView) activity
				.findViewById(R.id.top_bar_action_back_from_selection);
		mDelete = (Button) activity.findViewById(R.id.top_bar_action_delete);
		// 3相册浏览模式（）
		mOtherAlbumBrowsePanel = activity
				.findViewById(R.id.top_bar_panel_album);
		mBackFromPhotoPage = (ImageView) activity
				.findViewById(R.id.top_bar_action_back_from_album);
		mSystemAlumTitle = (TextView) activity
				.findViewById(R.id.top_bar_label_album_title);
		// 4
		mPhotoEditHeaderPanel = activity
				.findViewById(R.id.top_bar_panel_photo_browse);
		mBackFromBigPic = (ImageView) activity
				.findViewById(R.id.top_bar_action_back_from_big_pic);
		mPhotoIndex = (TextView) activity
				.findViewById(R.id.top_bar_label_photo_name);
		mStartCamera = (ImageView) activity
				.findViewById(R.id.top_bar_action_camera);
		// //////底部
		mAlbumRooterBar = activity.findViewById(R.id.operation_panel_rooter);
		// 1
		mOperationsPanel = activity.findViewById(R.id.panel_operations);
		mCloudAlbum = (Button) activity.findViewById(R.id.action_bar_cloud);
		mPicPuzzle = (Button) activity.findViewById(R.id.action_bar_pic_puzzle);
		mTemplatePuzzle = (Button) activity
				.findViewById(R.id.action_bar_templete_puzzle);
		// 2
		mPhotoEditRooterPanel = activity
				.findViewById(R.id.panel_photo_edit_rooter);
		mShare = (Button) activity.findViewById(R.id.action_bar_photo_share);
		mEffect = (Button) activity.findViewById(R.id.action_bar_photo_effect);
		mCompundEffect = (Button) activity
				.findViewById(R.id.action_bar_photo_com_effect);
		mPhotoDelete = (Button) activity
				.findViewById(R.id.action_bar_photo_delete);
		// //////
		mAlbumPuzzlePickPanel = activity.findViewById(R.id.puzzle_picker_panel);
		mPuzzleCancel = (Button) activity
				.findViewById(R.id.action_puzzle_cancel);
		mPuzzleSubmit = (Button) activity
				.findViewById(R.id.action_puzzle_begin);
		mPuzzleTitle = (TextView) activity
				.findViewById(R.id.gallery_smail_puzzle_msg);
		mPuzzleGridview = (GridView) activity
				.findViewById(R.id.gallery_smaill_puzzle_preview);
		mPuzzlePickerAdapter = new PuzzlePickerAdapter(mActivity,
				new ArrayList<PuzzleItem>());
		mPuzzleGridview.setAdapter(mPuzzlePickerAdapter);
		mPuzzleGridview.setOnItemClickListener(mOnPuzzleItemClickListener);
		// header bar buttons
		mC360Album.setOnClickListener(this);
		mSystemAlbumSet.setOnClickListener(this);
		mBackFromSelection.setOnClickListener(this);
		mDelete.setOnClickListener(this);
		mStartCamera.setOnClickListener(this);
		// rooter bar buttons
		mCloudAlbum.setOnClickListener(this);
		mPicPuzzle.setOnClickListener(this);
		mTemplatePuzzle.setOnClickListener(this);
		mPuzzleCancel.setOnClickListener(this);
		mPuzzleSubmit.setOnClickListener(this);
		mShare.setOnClickListener(this);
		mEffect.setOnClickListener(this);
		mCompundEffect.setOnClickListener(this);
		mPhotoDelete.setOnClickListener(this);
		//
		mHandler = new SynchronizedHandler(mActivity.getGLRoot()) {

			@Override
			public void handleMessage(Message message) {
				switch (message.what) {
				case MSG_TASK_COMPLETE: {
					stopTaskAndDismissDialog();
					if (message.obj != null) {
						ProgressListener listener = (ProgressListener) message.obj;
						listener.onProgressComplete(message.arg1);
					}
					if (mPhotoSelector != null
							&& mPhotoSelector.inSelectionMode())
						mPhotoSelector.leaveSelectionMode();
					break;
				}
				case MSG_TASK_UPDATE: {
					if (mDialog != null)
						mDialog.setProgress(message.arg1);
					if (message.obj != null) {
						ProgressListener listener = (ProgressListener) message.obj;
						listener.onProgressUpdate(message.arg1);
					}
					break;
				}
				case MSG_DO_SHARE: {
					mActivity.getAndroidContext().startActivity(
							(Intent) message.obj);
					break;
				}
				}
			}
		};
	}

	public void setActionBarMode(int actionMode) {
		mCurrentActionMode = actionMode;
		mAlbumHeaderBar
				.setVisibility((mCurrentActionMode & (ACION_MODE_NAVIGATION
						| ACION_MODE_SELECTION | ACION_MODE_ALBUM_BROWSE | ACION_MODE_PHOTO_EDIT)) != 0 ? View.VISIBLE
						: View.GONE);
		mAlbumNavigatePanel
				.setVisibility((mCurrentActionMode & ACION_MODE_NAVIGATION) != 0 ? View.VISIBLE
						: View.GONE);
		mItemSelectPanel
				.setVisibility((mCurrentActionMode & ACION_MODE_SELECTION) != 0 ? View.VISIBLE
						: View.GONE);
		mOtherAlbumBrowsePanel
				.setVisibility((mCurrentActionMode & ACION_MODE_ALBUM_BROWSE) != 0 ? View.VISIBLE
						: View.GONE);
		mPhotoEditHeaderPanel
				.setVisibility((mCurrentActionMode & ACION_MODE_PHOTO_EDIT) != 0 ? View.VISIBLE
						: View.GONE);
		//
		mAlbumRooterBar
				.setVisibility((mCurrentActionMode & (ACION_MODE_OPERATIONS
						| ACION_MODE_PUZZLE_PICK | ACION_MODE_PHOTO_EDIT)) != 0 ? View.VISIBLE
						: View.GONE);
		mOperationsPanel
				.setVisibility((mCurrentActionMode & ACION_MODE_OPERATIONS) != 0 ? View.VISIBLE
						: View.GONE);
		mPhotoEditRooterPanel
				.setVisibility((mCurrentActionMode & ACION_MODE_PHOTO_EDIT) != 0 ? View.VISIBLE
						: View.GONE);
		mAlbumPuzzlePickPanel
				.setVisibility((mCurrentActionMode & ACION_MODE_PUZZLE_PICK) != 0 ? View.VISIBLE
						: View.GONE);
	}

	// for action :selection
	public void setActvityState(ActivityState activityState) {
		mActivityState = activityState;
	}

	public void setPhotoSelector(PhotoSelector sm) {
		mPhotoSelector = sm;
	}

	// for action: pick
	public void setPhotoPicker(PhotoPicker photoPicker) {
		mPhotoPicker = photoPicker;
	}

	public void setSystemAlbumTitle(String title) {
		mSystemAlumTitle.setText(title);
	}

	public void setC360AlbumTitle(String title) {
		mC360Album.setText(title);
	}

	public void setSystemAlbumSetTitle(String title) {
		mSystemAlbumSet.setText(title);
	}

	public void setPhotoBrowseTitle(String title) {
		mPhotoIndex.setText(title);
	}

	public void setBackListener(View.OnClickListener listener) {
		mBackFromPhotoPage.setOnClickListener(listener);
		mBackFromBigPic.setOnClickListener(listener);
	}

	public void setPuzzleList() {
		ArrayList<PuzzleItem> list = mPhotoPicker.getPicked();
		LayoutParams params = new LayoutParams(list.size()
				* (mActivity.getResources().getDimensionPixelSize(
						R.dimen.album_puzzle_picker_colum_width) + mActivity
						.getResources().getDimensionPixelSize(
								R.dimen.album_puzzle_picker_colum_space)),
				LayoutParams.WRAP_CONTENT);
		mPuzzleGridview.setLayoutParams(params);
		mPuzzleGridview.setNumColumns(list.size());
		mPuzzlePickerAdapter.setList(list);
		setPuzzleTitle(mActivity.getResources().getString(
				R.string.puzzle_msg_line_normal, list.size(),
				mPhotoPicker.getMaxPickCount()));
	}

	public void clearPuzzleList() {
		mPhotoPicker.clearPicked();
		mPuzzlePickerAdapter.clearAll();
	}

	public void setPuzzleTitle(String title) {
		mPuzzleTitle.setText(title);
	}

	@Override
	public void onClick(View v) {
		ProgressListener listener = null;
		String confirmMsg = null;
		switch (v.getId()) {
		case R.id.top_bar_action_c360_album: {
			if (mActivityState instanceof AlbumSetPage) {
				mActivity.findViewById(R.id.top_bar_action_c360_album_selector)
						.setVisibility(View.VISIBLE);
				mActivity
						.findViewById(R.id.top_bar_action_other_album_selector)
						.setVisibility(View.GONE);
				mC360Album.setTextColor(Color.BLACK);
				mSystemAlbumSet.setTextColor(mActivity.getResources().getColor(
						R.color.album_header_action_btn_color));
				//
				Bundle d = new Bundle();
				d.putInt(DataManager.MEDIA_TYPE,
						DataManager.MEDIA_TYPE_C360_ALBUM);
				d.putString(DataManager.MEDIA_PATH_ID,
						DataManager.MEDIA_PATH_ID_C360);
				mActivity.getGLRoot().lockRenderThread();
				mActivity.getStateManager().switchState(mActivityState,
						AlbumPage.class, d);
				mActivity.getGLRoot().unlockRenderThread();
			}
			return;
		}
		case R.id.top_bar_action_other_album: {
			if (mActivityState instanceof AlbumPage) {
				mActivity.findViewById(R.id.top_bar_action_c360_album_selector)
						.setVisibility(View.GONE);
				mActivity
						.findViewById(R.id.top_bar_action_other_album_selector)
						.setVisibility(View.VISIBLE);
				mC360Album.setTextColor(mActivity.getResources().getColor(
						R.color.album_header_action_btn_color));
				mSystemAlbumSet.setTextColor(Color.BLACK);
				//
				Bundle d = new Bundle();
				d.putInt(DataManager.MEDIA_TYPE,
						DataManager.MEDIA_TYPE_ALBUM_SET);
				d.putString(DataManager.MEDIA_PATH_ID,
						DataManager.MEDIA_PATH_ID_SET);
				mActivity.getGLRoot().lockRenderThread();
				mActivity.getStateManager().switchState(mActivityState,
						AlbumSetPage.class, d);
				mActivity.getGLRoot().unlockRenderThread();
			}
			return;
		}
		case R.id.top_bar_action_back_from_selection: {
			if (mPhotoSelector != null && mPhotoSelector.inSelectionMode())
				mPhotoSelector.leaveSelectionMode();
			return;
		}
		case R.id.top_bar_action_back_from_album: {

			return;
		}
		case R.id.top_bar_action_camera: {
			break;
		}
		case R.id.action_bar_cloud: {
			break;
		}
		case R.id.action_bar_pic_puzzle: {
			mPhotoPicker.enterPickerMode(PhotoPicker.MAX_PICTURE_PUZZLE_COUNT);
			setPuzzleTitle(mActivity.getResources().getString(
					R.string.puzzle_msg_line_normal, 0,
					mPhotoPicker.getMaxPickCount()));
			break;
		}
		case R.id.action_bar_templete_puzzle: {
			mPhotoPicker.enterPickerMode(PhotoPicker.MAX_TEMPLATE_PUZZLE_COUNT);
			setPuzzleTitle(mActivity.getResources().getString(
					R.string.puzzle_msg_line_normal, 0,
					mPhotoPicker.getMaxPickCount()));
			break;
		}
		case R.id.action_puzzle_cancel: {
			mPhotoPicker.leavePickerMode();
			break;
		}
		case R.id.action_puzzle_begin: {
			break;
		}
		case R.id.action_bar_photo_share: {
			break;
		}
		case R.id.action_bar_photo_effect: {
			break;
		}
		case R.id.action_bar_photo_com_effect: {
			break;
		}
		case R.id.action_bar_photo_delete: {
			break;
		}
		case R.id.top_bar_action_delete: {
			confirmMsg = mActivity.getResources().getQuantityString(
					R.plurals.delete_selection,
					mPhotoSelector.getSelectedCount());
			final int action = v.getId();
			ConfirmDialogListener cdl = new ConfirmDialogListener(action,
					listener);
			new AlertDialog.Builder(mActivity.getAndroidContext())
					.setMessage(confirmMsg).setOnCancelListener(cdl)
					.setPositiveButton(R.string.ok, cdl)
					.setNegativeButton(R.string.cancel, cdl).create().show();
			break;
		}
		}
	}

	public void updateSelectionState() {
		int count = mPhotoSelector.getSelectedCount();
		String format = mActivity.getResources().getQuantityString(
				R.plurals.number_of_items_selected, count);
		mSelectCount.setText(String.format(format, count));

	}

	/**************************************************** For Time-consuming events ******************************************************/
	public void onActionItemClicked(int action, ProgressListener listener,
			boolean waitOnStop, boolean showDialog) {
		int title;
		switch (action) {
		case R.id.top_bar_action_delete:
			title = R.string.album_delete;
			break;
		case R.id.action_bar_photo_delete:
			title = R.string.album_delete;
			break;
		default:
			return;
		}
		startAction(action, title, listener, waitOnStop, showDialog);
	}

	public void startAction(int action, int title, ProgressListener listener,
			boolean waitOnStop, boolean showDialog) {
		stopTaskAndDismissDialog();
		Activity activity = (Activity) mActivity;
		mDialog = createProgressDialog(activity, title,
				mPhotoSelector.getSelectedCount());
		if (showDialog) {
			mDialog.show();
		}
		// excute it!
		MediaOperation operation = new MediaOperation(action, mPhotoSelector,
				listener);
		mTask = mActivity.getThreadPool().submit(operation, null);
		mWaitOnStop = waitOnStop;
	}

	private void stopTaskAndDismissDialog() {
		if (mTask != null) {
			if (!mWaitOnStop)
				mTask.cancel();
			mTask.waitDone();
			mDialog.dismiss();
			mDialog = null;
			mTask = null;
		}
	}

	public void pause() {
		stopTaskAndDismissDialog();
	}

	private void onActionItemClicked(int action, ProgressListener listener) {
		onActionItemClicked(action, listener, false, true);
	}

	public interface ProgressListener {

		public void onConfirmDialogShown();

		public void onConfirmDialogDismissed(boolean confirmed);

		public void onProgressUpdate(int index);

		public void onProgressComplete(int result);
	}

	private class ConfirmDialogListener implements OnClickListener,
			OnCancelListener {

		private final int mActionId;
		private final ProgressListener mListener;

		public ConfirmDialogListener(int actionId, ProgressListener listener) {
			mActionId = actionId;
			mListener = listener;
		}

		@Override
		public void onClick(DialogInterface dialog, int which) {
			if (which == DialogInterface.BUTTON_POSITIVE) {
				if (mListener != null) {
					mListener.onConfirmDialogDismissed(true);
				}
				onActionItemClicked(mActionId, mListener);
			} else {
				if (mListener != null) {
					mListener.onConfirmDialogDismissed(false);
				}
			}
		}

		@Override
		public void onCancel(DialogInterface dialog) {
			if (mListener != null) {
				mListener.onConfirmDialogDismissed(false);
			}
		}
	}

	private static ProgressDialog createProgressDialog(Context context,
			int titleId, int progressMax) {
		ProgressDialog dialog = new ProgressDialog(context);
		dialog.setTitle(titleId);
		dialog.setMax(progressMax);
		dialog.setCancelable(false);
		dialog.setIndeterminate(false);
		if (progressMax > 1) {
			dialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
		}
		return dialog;
	}

	private class MediaOperation implements Job<Void> {

		private final PhotoSelector mSelector;
		private final int mOperation;
		private final ProgressListener mListener;

		public MediaOperation(int operation, PhotoSelector selector,
				ProgressListener listener) {
			mOperation = operation;
			mSelector = selector;
			mListener = listener;
		}

		public Void run(JobContext jc) {
			int index = 0;
			int result = EXECUTION_RESULT_SUCCESS;
			try {
				ArrayList<Path> paths = mSelector.getSelectedPaths();
				Log.i(TAG, "-----------------------pp:" + paths.size());
				for (Path path : paths) {
					if (jc.isCancelled()) {
						result = EXECUTION_RESULT_CANCEL;
						break;
					}
					Log.i(TAG,
							"-----------------------pppppp:" + path.getPathId());
					if (!execute(jc, mOperation, path)) {
						result = EXECUTION_RESULT_FAIL;
					}
					onProgressUpdate(index++, mListener);
				}
			} catch (Throwable th) {
				Log.e(TAG, "failed to execute operation " + mOperation + " : "
						+ th);
			} finally {
				onProgressComplete(result, mListener);
			}
			return null;
		}

		private boolean execute(JobContext jc, int cmd, Path path) {
			boolean result = true;
			Log.v(TAG, "Execute cmd: " + cmd + " for " + path);
			long startTime = System.currentTimeMillis();
			switch (cmd) {
			case R.id.top_bar_action_delete:
				mActivity.getDataManager().delete(path);
				break;
			case R.id.action_bar_photo_delete:
				mActivity.getDataManager().delete(path);
				break;
			default:
				throw new AssertionError();
			}
			Log.v(TAG, "It takes " + (System.currentTimeMillis() - startTime)
					+ " ms to execute cmd for " + path);
			return result;
		}

		private void onProgressUpdate(int index, ProgressListener listener) {
			mHandler.sendMessage(mHandler.obtainMessage(MSG_TASK_UPDATE, index,
					0, listener));
		}

		private void onProgressComplete(int result, ProgressListener listener) {
			mHandler.sendMessage(mHandler.obtainMessage(MSG_TASK_COMPLETE,
					result, 0, listener));
		}
	}
}
