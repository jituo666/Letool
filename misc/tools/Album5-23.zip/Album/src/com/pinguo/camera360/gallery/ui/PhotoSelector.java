/*
 * Copyright (C) 2010 The Android Open Source Project Licensed under the Apache
 * License, Version 2.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0 Unless required by applicable law
 * or agreed to in writing, software distributed under the License is
 * distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

package com.pinguo.camera360.gallery.ui;

import com.pinguo.camera360.gallery.AlbumActivity;
import com.pinguo.camera360.gallery.data.MediaSet;
import com.pinguo.camera360.gallery.data.MediaSet.SortTag;
import com.pinguo.camera360.gallery.data.Path;
import com.pinguo.camera360.gallery.ui.layout.BaseSlotLayout.SlotPos;

import java.util.ArrayList;

public class PhotoSelector {

	@SuppressWarnings("unused")
	private static final String TAG = "PhotoSelector";
	public static final int ENTER_SELECTION_MODE = 1;
	public static final int LEAVE_SELECTION_MODE = 2;
	private ArrayList<SortTag> mTags;
	private ArrayList<SlotPos> mSlotPos;
	private MediaSet mSourceMediaSet;
	private SelectionListener mListener;
	private boolean mInSelectionMode;
	private boolean mAutoLeave = true;

	// private int mTotal;

	public interface SelectionListener {
		public void onSelectionModeChange(int mode);

		public void onSelectionChange();
	}

	public PhotoSelector(AlbumActivity context) {
	}

	public void setTagsAndSlotPos(ArrayList<SortTag> tags,
			ArrayList<SlotPos> slotPos) {
		mTags = tags;
		mSlotPos = slotPos;
	}

	// Whether we will leave selection mode automatically once the number of
	// selected items is down to zero.
	public void setAutoLeaveSelectionMode(boolean enable) {
		mAutoLeave = enable;
	}

	public void setSelectionListener(SelectionListener listener) {
		mListener = listener;
	}

	public boolean inSelectionMode() {
		return mInSelectionMode;
	}

	public void enterSelectionMode() {
		if (mInSelectionMode)
			return;
		mInSelectionMode = true;
		if (mListener != null)
			mListener.onSelectionModeChange(ENTER_SELECTION_MODE);
	}

	public void leaveSelectionMode() {
		if (!mInSelectionMode)
			return;
		mInSelectionMode = false;
		resetAllSCheckSedtate();
		if (mListener != null)
			mListener.onSelectionModeChange(LEAVE_SELECTION_MODE);
	}

	public boolean isItemSelected(Path itemId, int slotIndex) {
		return mSlotPos.get(slotIndex).isChecked;
	}

	public int getSelectedCount() {
		if (mSlotPos == null) return 0;
		int total = 0;
		for (SlotPos pos : mSlotPos) {
			if (pos.isChecked)
				total++;
		}
		return total;
	}

	public void toggleSlot(int slotIndex) {
		boolean checked = !mSlotPos.get(slotIndex).isChecked;
		mSlotPos.get(slotIndex).isChecked = checked;
		modifyTagCheckedState(slotIndex);
		if (mListener != null)
			mListener.onSelectionChange();
		if (checked) {
			enterSelectionMode();
		} else {
			int count = getSelectedCount();
			if (count == 0 && mAutoLeave) {
				leaveSelectionMode();
			}
		}
	}

	public void toggleTag(int tagIndex, boolean checked) {
		SortTag tag = mTags.get(tagIndex);
		for (int i = tag.index; i < (tag.index + tag.count); i++) {
			mSlotPos.get(i).isChecked = checked;
		}
		if (mListener != null)
			mListener.onSelectionChange();
		if (checked) {
			enterSelectionMode();
		} else {
			int count = getSelectedCount();
			if (count == 0 && mAutoLeave) {
				leaveSelectionMode();
			}
		}
	}

	public void resetAllSCheckSedtate() {
		for (SlotPos pos : mSlotPos) {
			pos.isChecked = false;
		}
		for (SortTag tag : mTags) {
			tag.checked = false;
		}
	}

	public void modifyTagCheckedState(int slotIndex) {
		SortTag tag = findTag(slotIndex);
		for (int i = (tag.index + tag.count - 1); i >= tag.index; i--) {
			if (!mSlotPos.get(i).isChecked) {
				tag.checked = false;
				return;
			}
		}
		tag.checked = true;
	}

	private SortTag findTag(int slotIndex) {
		SortTag tag = null;
		for (int index = 0; index < mTags.size(); index++) {
			if (index == mTags.size() - 1) {
				tag = mTags.get(index);
			} else if (slotIndex < mTags.get(index).index) {
				tag = mTags.get(index - 1);
			}
			if (tag != null) {
				break;
			}
		}
		return tag;
	}

	public ArrayList<Path> getSelectedPaths() {
		return mSourceMediaSet.getMediaItem(mSlotPos, getSelectedCount());
	}

	public void setSourceMediaSet(MediaSet set) {
		mSourceMediaSet = set;
	}
}
