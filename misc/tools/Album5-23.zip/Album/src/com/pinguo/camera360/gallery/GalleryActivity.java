
package com.pinguo.camera360.gallery;

import com.pinguo.camera360.gallery.data.DataManager;

import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;

public class GalleryActivity extends RootActivity {

    public static final String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.album_main);
        super.onCreate(savedInstanceState);
        if (savedInstanceState != null) {
            getStateManager().restoreFromState(savedInstanceState);
        } else {
            startC360ALbumPage();
        }
    }

    private void startC360ALbumPage() {
//        Bundle d = new Bundle();
//        d.putInt(DataManager.MEDIA_TYPE, DataManager.MEDIA_TYPE_C360_ALBUM);
//        d.putString(DataManager.MEDIA_PATH_ID, DataManager.MEDIA_PATH_ID_C360);
//        getStateManager().startState(AlbumPage.class, d);
        Bundle d = new Bundle();
        d.putInt(DataManager.MEDIA_TYPE,
                DataManager.MEDIA_TYPE_ALBUM_SET);
        d.putString(DataManager.MEDIA_PATH_ID,
                DataManager.MEDIA_PATH_ID_SET);
        getStateManager().startState(AlbumSetPage.class, d);
    }
}
