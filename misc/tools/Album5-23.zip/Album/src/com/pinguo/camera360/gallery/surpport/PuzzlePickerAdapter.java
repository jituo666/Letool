
package com.pinguo.camera360.gallery.surpport;

import com.pinguo.camera360.gallery.R;
import com.pinguo.camera360.gallery.RootActivity;
import com.pinguo.camera360.gallery.data.MediaItem;
import com.pinguo.camera360.gallery.ui.BitmapLoader;
import com.pinguo.camera360.gallery.ui.SynchronizedHandler;
import com.pinguo.camera360.gallery.ui.PhotoPicker.PuzzleItem;
import com.pinguo.camera360.gallery.uitl.Future;
import com.pinguo.camera360.gallery.uitl.FutureListener;
import com.pinguo.camera360.gallery.uitl.JobLimiter;

import android.graphics.Bitmap;
import android.os.Message;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import java.util.ArrayList;

public class PuzzlePickerAdapter extends AdapterBase {

    private static final String TAG = "PuzzlePickerAdapter";
    private static final int MSG_UPDATE_ENTRY = 0;
    private final SynchronizedHandler mHandler;
    private RootActivity mActivity;
    private final JobLimiter mThreadPool;

    public PuzzlePickerAdapter(RootActivity activity, ArrayList<PuzzleItem> list) {
        super(activity.getAndroidContext(), list);
        mActivity = activity;
        mHandler = new SynchronizedHandler(activity.getGLRoot()) {

            @Override
            public void handleMessage(Message message) {
                if (message.what == MSG_UPDATE_ENTRY) {
                    ((ThumbnailLoader) message.obj).updateEntry();
                }
            }
        };
        mThreadPool = new JobLimiter(mActivity.getThreadPool(), 1);
    }

    static class Holder {

        View layMain;
        ImageView ivEffectIcon;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Holder holder;
        if (convertView == null) {
            convertView = getLayoutInflater().inflate(R.layout.album_puzzle_pre_grid_item, null);
            holder = new Holder();
            holder.ivEffectIcon = (ImageView) convertView.findViewById(R.id.iv_effect_icon);
            convertView.setTag(holder);
        } else {
            holder = (Holder) convertView.getTag();
        }
        bindData(holder, position);
        return convertView;
    }

    private void bindData(Holder holder, int position) {
        PuzzleItem pickerItem = getList().get(position);
        Bitmap b = pickerItem.mMinThumnail;
        if (b != null) {
            holder.ivEffectIcon.setImageBitmap(b);
        } else {
            MediaItem obj = (MediaItem) mActivity.getDataManager().getMediaObject(pickerItem.mPath);
            ThumbnailLoader loader = new ThumbnailLoader(holder.ivEffectIcon, obj, pickerItem);
            loader.startLoad();
        }
    }

    public void clearAll() {
        mList.clear();
    }

    private class ThumbnailLoader extends BitmapLoader {

        private final ImageView mIv;
        private final MediaItem mMedia;
        private final PuzzleItem mPickerItem;

        public ThumbnailLoader(ImageView iv, MediaItem m, PuzzleItem pickerItem) {
            mIv = iv;
            mMedia = m;
            mPickerItem = pickerItem;
        }

        @Override
        protected void recycleBitmap(Bitmap bitmap) {
            MediaItem.getMicroThumbPool().recycle(bitmap);
        }

        @Override
        protected Future<Bitmap> submitBitmapTask(FutureListener<Bitmap> l) {
            return mThreadPool.submit(mMedia.requestImage(MediaItem.TYPE_MICROTHUMBNAIL), this);
        }

        @Override
        protected void onLoadComplete(Bitmap bitmap) {
            mHandler.obtainMessage(MSG_UPDATE_ENTRY, this).sendToTarget();
        }

        public void updateEntry() {
            Bitmap bitmap = getBitmap();
            mPickerItem.mMinThumnail = bitmap;
            mIv.setImageBitmap(bitmap);
        }
    }
}
