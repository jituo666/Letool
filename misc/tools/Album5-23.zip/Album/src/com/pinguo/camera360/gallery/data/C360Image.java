
package com.pinguo.camera360.gallery.data;

import java.io.File;
import java.io.IOException;

import com.pinguo.camera360.gallery.AlbumAppImpl;
import com.pinguo.camera360.gallery.data.model.C360Photo;
import com.pinguo.camera360.gallery.uitl.AlbumUtils;
import com.pinguo.camera360.gallery.uitl.BitmapUtils;
import com.pinguo.camera360.gallery.uitl.UpdateHelper;
import com.pinguo.camera360.gallery.uitl.ThreadPool.Job;
import com.pinguo.camera360.gallery.uitl.ThreadPool.JobContext;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapRegionDecoder;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore.Images;
import android.util.Log;

public class C360Image extends LocalMediaItem {

	public static final String TAG = "C360Image";
	public static final int INDEX_ID = 0;
	public static final int INDEX_DATE_TAKEN = 4;
	public static final int INDEX_LATITUDE = 5;
	public static final int INDEX_LONGITUDE = 6;
	public static final int INDEX_ORIENTATION = 11;
	public static final int INDEX_DATA = 16;
    public static final String[] PROJECTION = {
            C360Photo._ID, // 0
            C360Photo.CAMERA_MODE_INDEX, // 1
            C360Photo.EFFECT_INDEX, // 2
            C360Photo.EFFECT_CLASS_INDEX,// 3
            C360Photo.TOKEN_MILLISECONDS,// 4
            C360Photo.LATITUDE, // 5
            C360Photo.LONGITUDE, // 6
            C360Photo.EFFECT_PARAMETER,// 7
            C360Photo.FAIL_COUNT,// 8
            C360Photo.EXIF,// 9
            C360Photo.PROJECT_STATE,// 10
            C360Photo.DIRECTION,// 11
            C360Photo.WIDTH,// 12
            C360Photo.HEIGHT,// 13
            C360Photo.COST_MILLISECONDS,// 14
            C360Photo.MODEL,// 15
            C360Photo.EFFECT_PHOTO_SAVE_PATH,// 16
            C360Photo.PROJECT_VERSIONCODE,// 17
            C360Photo.JSON_EXPAND
    // 18
    };
    private final AlbumAppImpl mApplication;
    public int rotation;
    private final Uri mBaseUri = C360Photo.CONTENT_URI;

    public C360Image(AlbumAppImpl application,Path path, Cursor cursor) {
        super(path, nextVersionNumber());
        mApplication = application;
        loadFromCursor(cursor);
    }

    public C360Image(AlbumAppImpl app, Path path) {
        super(path,nextVersionNumber());
        mApplication = app;
        ContentResolver resolver = mApplication.getContentResolver();

        Cursor cursor = resolver.query(mBaseUri, PROJECTION, C360Photo.TOKEN_MILLISECONDS + "=?",
				new String[] { String.valueOf(path.getTokenMills()) }, null);
        if (cursor == null) {
            throw new RuntimeException("cannot get cursor for: " + id);
        }
        try {
            if (cursor.moveToNext()) {
                loadFromCursor(cursor);
            } else {
                throw new RuntimeException("cannot find data for: " + id);
            }
        } finally {
            cursor.close();
        }
    }

    private void loadFromCursor(Cursor cursor) {
        id = cursor.getInt(INDEX_ID);
        latitude = cursor.getDouble(INDEX_LATITUDE);
        longitude = cursor.getDouble(INDEX_LONGITUDE);
        dateTakenInMs = cursor.getLong(INDEX_DATE_TAKEN);
        filePath = cursor.getString(INDEX_DATA);
        rotation = cursor.getInt(INDEX_ORIENTATION);
    }

    @Override
    protected boolean updateFromCursor(Cursor cursor) {
        UpdateHelper uh = new UpdateHelper();
        id = uh.update(id, cursor.getInt(INDEX_ID));
        latitude = uh.update(latitude, cursor.getDouble(INDEX_LATITUDE));
        longitude = uh.update(longitude, cursor.getDouble(INDEX_LONGITUDE));
        dateTakenInMs = uh.update(dateTakenInMs, cursor.getLong(INDEX_DATE_TAKEN));
        filePath = uh.update(filePath, cursor.getString(INDEX_DATA));
        rotation = uh.update(rotation, cursor.getInt(INDEX_ORIENTATION));
        return uh.isUpdated();
    }

    @Override
    public Job<Bitmap> requestImage(int type) {
        return new LocalImageRequest(mApplication, filePath, type, filePath);
    }

    public static class LocalImageRequest extends ImageCacheRequest {

        private String mLocalFilePath;

        LocalImageRequest(AlbumAppImpl application, String path, int type, String localFilePath) {
            super(application, path, type, MediaItem.getTargetSize(type));
            mLocalFilePath = localFilePath;
        }

        @Override
        public Bitmap onDecodeOriginal(JobContext jc, final int type) {
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inPreferredConfig = Bitmap.Config.ARGB_8888;
            options.inPurgeable = true;
            int targetSize = MediaItem.getTargetSize(type);
            // try to decode from JPEG EXIF
            if (type == MediaItem.TYPE_MICROTHUMBNAIL) {
                ExifInterface exif = null;
                byte[] thumbData = null;
                try {
                    exif = new ExifInterface(mLocalFilePath);
                    if (exif != null) {
                        thumbData = exif.getThumbnail();
                    }
                } catch (Throwable t) {
                    Log.w(TAG, "fail to get exif thumb", t);
                }
                if (thumbData != null) {
                    Bitmap bitmap = DecodeUtils.decodeIfBigEnough(jc, thumbData, options, targetSize);
                    if (bitmap != null)
                        return bitmap;
                }
            }
            return DecodeUtils.decodeThumbnail(jc, mLocalFilePath, options, targetSize, type);
        }
    }

    @Override
    public Job<BitmapRegionDecoder> requestLargeImage() {
        if (Build.VERSION.SDK_INT >= 10)
            return new LocalLargeImageRequest(filePath);
        else
            return null;
    }

    public static class LocalLargeImageRequest implements Job<BitmapRegionDecoder> {

        String mLocalFilePath;

        public LocalLargeImageRequest(String localFilePath) {
            mLocalFilePath = localFilePath;
        }

        public BitmapRegionDecoder run(JobContext jc) {
            return DecodeUtils.createBitmapRegionDecoder(jc, mLocalFilePath, false);
        }
    }

    @Override
    public int getSupportedOperations() {
        int operation = SUPPORT_DELETE | SUPPORT_SHARE | SUPPORT_CROP | SUPPORT_SETAS | SUPPORT_EDIT | SUPPORT_INFO;
        // 此处添加关于是否支持大图的判断，在 api level<10时，bitmapregiondecoder不被系统支持
        if (BitmapUtils.isSupportedByRegionDecoder(mimeType) && Build.VERSION.SDK_INT >= 10) {
            operation |= SUPPORT_FULL_IMAGE;
        }
        if (BitmapUtils.isRotationSupported(mimeType)) {
            operation |= SUPPORT_ROTATE;
        }
        if (AlbumUtils.isValidLocation(latitude, longitude)) {
            operation |= SUPPORT_SHOW_ON_MAP;
        }
        return operation;
    }

    @Override
    public void delete() {
        AlbumUtils.assertNotInRenderThread();
        mApplication.getContentResolver().delete(mBaseUri, "id=?", new String[] {
            String.valueOf(id)
        });
    }

    private static String getExifOrientation(int orientation) {
        switch (orientation) {
            case 0:
                return String.valueOf(ExifInterface.ORIENTATION_NORMAL);
            case 90:
                return String.valueOf(ExifInterface.ORIENTATION_ROTATE_90);
            case 180:
                return String.valueOf(ExifInterface.ORIENTATION_ROTATE_180);
            case 270:
                return String.valueOf(ExifInterface.ORIENTATION_ROTATE_270);
            default:
                throw new AssertionError("invalid: " + orientation);
        }
    }

    @Override
    public void rotate(int degrees) {
        AlbumUtils.assertNotInRenderThread();
        Uri baseUri = Images.Media.EXTERNAL_CONTENT_URI;
        ContentValues values = new ContentValues();
        int rotation = (this.rotation + degrees) % 360;
        if (rotation < 0)
            rotation += 360;
        if (mimeType.equalsIgnoreCase("image/jpeg")) {
            try {
                ExifInterface exif = new ExifInterface(filePath);
                exif.setAttribute(ExifInterface.TAG_ORIENTATION, getExifOrientation(rotation));
                exif.saveAttributes();
            } catch (IOException e) {
                Log.w(TAG, "cannot set exif data: " + filePath);
            }
            // We need to update the filesize as well
            fileSize = new File(filePath).length();
            values.put(Images.Media.SIZE, fileSize);
        }
        values.put(Images.Media.ORIENTATION, rotation);
        mApplication.getContentResolver().update(baseUri, values, "_id=?", new String[] {
            String.valueOf(id)
        });
    }

    @Override
    public Uri getContentUri() {
        return mBaseUri.buildUpon().appendPath(String.valueOf(id)).build();
    }

    @Override
    public int getMediaType() {
        return MEDIA_TYPE_IMAGE;
    }

    @Override
    public MediaDetails getDetails() {
        MediaDetails details = super.getDetails();
        details.addDetail(MediaDetails.INDEX_ORIENTATION, Integer.valueOf(rotation));
        MediaDetails.extractExifInfo(details, filePath);
        return details;
    }

    @Override
    public int getRotation() {
        return rotation;
    }

    @Override
    public int getWidth() {
        return width;
    }

    @Override
    public int getHeight() {
        return height;
    }

}
