/*
 * Copyright (C) 2010 The Android Open Source Project Licensed under the Apache
 * License, Version 2.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0 Unless required by applicable law
 * or agreed to in writing, software distributed under the License is
 * distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

package com.pinguo.camera360.gallery.ui;

import com.pinguo.camera360.gallery.data.Path;

import android.content.Context;
import android.graphics.Bitmap;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class PhotoPicker {

    @SuppressWarnings("unused")
    private static final String TAG = "PhotoPicker";
    public static final int MAX_PICTURE_PUZZLE_COUNT = 9;
    public static final int MAX_TEMPLATE_PUZZLE_COUNT = 4;
    public static final int ENTER_PICKER_MODE = 1;
    public static final int LEAVE_PICKER_MODE = 2;
    private ArrayList<PuzzleItem> mPickedSet;
    private PickerListener mListener;
    private int mMaxPickerCount;
    private boolean mInPickerMode;
    private boolean mAutoLeave = true;
    private Context mContext;

    public interface PickerListener {

        public void onPickerModeChange(int mode);

        public void onPickerChange(Path path, boolean picked);
    }

    public PhotoPicker(Context context) {
        mContext = context;
        mPickedSet = new ArrayList<PuzzleItem>();
    }

    // Whether we will leave selection mode automatically once the number of
    // picked items is down to zero.
    public void setAutoLeavePickerMode(boolean enable) {
        mAutoLeave = enable;
    }

    public void setPickerListener(PickerListener listener) {
        mListener = listener;
    }

    public boolean inPickerMode() {
        return mInPickerMode;
    }

    public void enterPickerMode(int maxPickCount) {
        if (mInPickerMode)
            return;
        mInPickerMode = true;
        mMaxPickerCount = maxPickCount;
        if (mListener != null)
            mListener.onPickerModeChange(ENTER_PICKER_MODE);
    }

    public void leavePickerMode() {
        if (!mInPickerMode)
            return;
        mInPickerMode = false;
        mPickedSet.clear();
        if (mListener != null)
            mListener.onPickerModeChange(LEAVE_PICKER_MODE);
    }

    public boolean isItemPicked(Path itemId) {
        return isPathInSet(itemId);
    }

    public int getPickedCount() {
        return mPickedSet.size();
    }

    public int getMaxPickCount() {
        return mMaxPickerCount;
    }

    public void toggle(Path path) {
        if (isPathInSet(path)) {
            removePathFromSet(path);
        } else {
            enterPickerMode(mMaxPickerCount);
            if (mPickedSet.size() >= mMaxPickerCount) {
                Toast.makeText(mContext, "已达最大选择数！", Toast.LENGTH_SHORT).show();
                return;
            }
            mPickedSet.add(new PuzzleItem(path, null));
        }
        // Convert to inverse selection mode if everything is picked.
        int count = getPickedCount();
        if (mListener != null)
            mListener.onPickerChange(path, isItemPicked(path));
        if (count == 0 && mAutoLeave) {
            leavePickerMode();
        }
    }

    public ArrayList<PuzzleItem> getPicked() {
        return mPickedSet;
    }

    public void clearPicked() {
        mPickedSet.clear();
    }

    private boolean isPathInSet(Path path) {
        for (PuzzleItem item : mPickedSet) {
            if (item.mPath.equals(path)) {
                return true;
            }
        }
        return false;
    }

    private void removePathFromSet(Path path) {
        for (PuzzleItem item : mPickedSet) {
            if (item.mPath.equals(path)) {
                mPickedSet.remove(item);
                return;
            }
        }
    }

    public static class PuzzleItem {

        public PuzzleItem(Path path, Bitmap thumnail) {
            mPath = path;
            mMinThumnail = thumnail;
        }

        public Path mPath = null;
        public Bitmap mMinThumnail = null;
    }
}
