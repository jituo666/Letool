package com.pinguo.camera360.gallery.data.model;

import android.net.Uri;

public class C360Photo {

    public static final String AUTHORITY = "com.pinguo.camera360.gallery";

    public static final Uri AUTHORITY_URI = Uri.parse("content://" + AUTHORITY);

    public static final String TABLE_PATH = "c360_photo";

    public static final Uri CONTENT_URI = Uri.withAppendedPath(AUTHORITY_URI, TABLE_PATH);

    public static final String _ID = "id";

    public static final String CAMERA_MODE_INDEX = "cameraModeIndex";

    public static final String EFFECT_INDEX = "eftIndex";

    public static final String EFFECT_CLASS_INDEX = "eftClassIndex";

    public static final String TOKEN_MILLISECONDS = "tokenMillis";

    public static final String LATITUDE = "lat";

    public static final String LONGITUDE = "lon";

    public static final String EFFECT_PARAMETER = "eftParam";

    public static final String FAIL_COUNT = "failCount";

    public static final String EXIF = "exif";

    public static final String PROJECT_STATE = "projectState";

    public static final String DIRECTION = "direct";

    public static final String WIDTH = "width";

    public static final String HEIGHT = "height";

    public static final String COST_MILLISECONDS = "costMillis";

    public static final String MODEL = "model";

    public static final String EFFECT_PHOTO_SAVE_PATH = "effectPhotoSavePath";

    public static final String PROJECT_VERSIONCODE = "projectVersionCode";

    public static final String JSON_EXPAND = "jsonExpand";

}
