package com.pinguo.camera360.gallery.data;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

import com.pinguo.camera360.gallery.AlbumAppImpl;
import com.pinguo.camera360.gallery.data.model.C360Photo;
import com.pinguo.camera360.gallery.ui.layout.BaseSlotLayout.SlotPos;
import com.pinguo.camera360.gallery.uitl.AlbumUtils;
import com.pinguo.camera360.gallery.uitl.Log;
import com.pinguo.camera360.gallery.uitl.Utils;

import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;

public class C360Album extends MediaSet {

	private static final String TAG = "C360Album";
	private static final String[] COUNT_PROJECTION = { "count(*)" };
	private static final int INVALID_COUNT = -1;
	private final String mOrderClause;
	private final Uri mBaseUri;
	private final String[] mProjection;
	private final AlbumAppImpl mApplication;
	private final ContentResolver mResolver;
	private final ChangeNotifier mNotifier;
	private int mCachedCount = INVALID_COUNT;

	public C360Album(AlbumAppImpl app, Path path) {
		super(path, nextVersionNumber());
		mApplication = app;
		mResolver = app.getContentResolver();
		mBaseUri = C360Photo.CONTENT_URI;
		mProjection = C360Image.PROJECTION;
		mOrderClause = C360Photo.TOKEN_MILLISECONDS + " DESC";
		mNotifier = new ChangeNotifier(this, mBaseUri, app);
	}

	@Override
	public Uri getContentUri() {
		return C360Photo.CONTENT_URI;
	}

	@Override
	public ArrayList<MediaItem> getMediaItem(int start, int count) {
		ArrayList<MediaItem> list = new ArrayList<MediaItem>();
		AlbumUtils.assertNotInRenderThread();
		Cursor cursor = mResolver.query(mBaseUri, mProjection, null, null,
				mOrderClause + " limit " + start + "," + count);
		if (cursor == null) {
			Log.w(TAG, "query fail: " + mBaseUri);
			return list;
		}
		// Log.i(TAG, "-------------start" + start + ": count:"+ count + ":" +
		// cursor.getCount() +":" + uri.toString());
		try {
			while (cursor.moveToNext()) {
				MediaItem item = new C360Image(mApplication, new Path(
						DataManager.MEDIA_TYPE_C360_IMAGE,
						cursor.getString(C360Image.INDEX_DATA),
						cursor.getLong(C360Image.INDEX_DATE_TAKEN)), cursor);
				list.add(item);
			}
		} finally {
			cursor.close();
		}
		return list;
	}


	@Override
	public ArrayList<SortTag> analysisSortTags() {
		long starttime = System.currentTimeMillis();
		ArrayList<SortTag> ret = new ArrayList<SortTag>();
		Cursor cursor = mResolver.query(mBaseUri, new String[] {
				C360Photo.TOKEN_MILLISECONDS, C360Photo.COST_MILLISECONDS,
				"count(" + C360Photo.COST_MILLISECONDS + ")" }, "1) group by ("
				+ C360Photo.TOKEN_MILLISECONDS + "/86400000", null,
				C360Photo.TOKEN_MILLISECONDS + " DESC ");
		if (cursor == null) {
			Log.w(TAG, "query fail: " + mBaseUri);
			return ret;
		}
		try {
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd E");
			int lastCount = 0;
			while (cursor.moveToNext()) {
				SortTag tag = new SortTag();
				tag.name = formatter.format(cursor.getLong(0));
				if (ret.size() > 0) {
					tag.index = lastCount;
				} else {
					tag.index = 0;
				}
				lastCount += cursor.getInt(2);
				ret.add(tag);
				// Log.i(TAG, "-------------get tags :" + tag);
			}
		} finally {
			cursor.close();
		}
		Log.i(TAG,
				"-------------get tags used time:"
						+ (System.currentTimeMillis() - starttime));
		return ret;
	}

	@Override
	public int getMediaItemCount() {
		if (mCachedCount == INVALID_COUNT) {
			Cursor cursor = mResolver.query(mBaseUri, COUNT_PROJECTION, null,
					null, null);
			if (cursor == null) {
				Log.w(TAG, "query fail");
				return 0;
			}
			try {
				Utils.assertTrue(cursor.moveToNext());
				mCachedCount = cursor.getInt(0);
			} finally {
				cursor.close();
			}
		}
		return mCachedCount;
	}

	@Override
	public String getName() {
		return null;
	}

	@Override
	public long reload() {
		if (mNotifier.isDirty()) {
			mDataVersion = nextVersionNumber();
			mCachedCount = INVALID_COUNT;
		}
		return mDataVersion;
	}

	// 不支持一次行将所有c360相片删除
	@Override
	public void delete() {
		AlbumUtils.assertNotInRenderThread();
		mResolver.delete(mBaseUri, null, null);
	}

	@Override
	public boolean isLeafAlbum() {
		return true;
	}

	@Override
	public ArrayList<Path> getMediaItem(ArrayList<SlotPos> slotPos,	int checkedCount) {
		ArrayList<Path> list = new ArrayList<Path>();
		AlbumUtils.assertNotInRenderThread();
		Cursor cursor = mResolver.query(mBaseUri, mProjection, null, null,mOrderClause);
		if (cursor == null || cursor.getCount() != slotPos.size()) {
			Log.w(TAG, " getMediaItem fail**********360album********: " + mBaseUri);
			return list;
		}
		try {
			int index = 0;
			while (cursor.moveToNext() && list.size() < checkedCount) {
				if (slotPos.get(index).isChecked) {
					list.add(new Path(DataManager.MEDIA_TYPE_C360_IMAGE,
							cursor.getString(C360Image.INDEX_DATA), cursor
									.getLong(C360Image.INDEX_DATE_TAKEN)));
				}
				index++;
			}
		} finally {
			cursor.close();
		}
		return list;
	}
}
