/*
 * Copyright (C) 2012 The Android Open Source Project Licensed under the Apache
 * License, Version 2.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0 Unless required by applicable law
 * or agreed to in writing, software distributed under the License is
 * distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

package com.pinguo.camera360.gallery.ui;

import com.pinguo.camera360.gallery.R;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;

public abstract class AbstractSlotRenderer implements SlotView.SlotRenderer {

    private final NinePatchTexture mFramePressed;
    private final NinePatchTexture mFrameSelected;
    private final BitmapTexture mTagChecked;
    private final BitmapTexture mTagUnChecked;
    private FadeOutTexture mFramePressedUp;

    protected AbstractSlotRenderer(Context context) {
        mFramePressed = new NinePatchTexture(context, R.drawable.gg_grid_pressed);
        mFrameSelected = new NinePatchTexture(context, R.drawable.gg_grid_selected);
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inPreferredConfig = Bitmap.Config.ARGB_8888;
        mTagChecked = new BitmapTexture(BitmapFactory.decodeResource(context.getResources(),
                R.drawable.gg_bs_btn_checkbox_dark_on, options));
        mTagUnChecked = new BitmapTexture(BitmapFactory.decodeResource(context.getResources(),
                R.drawable.gg_bs_btn_checkbox_dark_off, options));
    }

    protected void drawContent(GLCanvas canvas, Texture content, int width, int height, int rotation) {
        canvas.save(GLCanvas.SAVE_FLAG_MATRIX);

        if (rotation != 0) {
            canvas.translate(width / 2, height / 2);
            canvas.rotate(rotation, 0, 0, 1);
            canvas.translate(-width / 2, -height / 2);
            if (((rotation % 90) & 1) != 0) {
                int temp = height;
                height = width;
                width = height;
            }
        }

        // Fit the content into the box
        float scale = Math.min((float) width / content.getWidth(), (float) height / content.getHeight());
        canvas.scale(scale, scale, 1);
        content.draw(canvas, 0, 0);

        canvas.restore();
    }
    /*
     * protected void drawVideoOverlay(GLCanvas canvas, int width, int height) {
     * // Scale the video overlay to the height of the thumbnail and put it //
     * on the left side. ResourceTexture v = mVideoOverlay; float scale =
     * (float) height / v.getHeight(); int w = Math.round(scale * v.getWidth());
     * int h = Math.round(scale * v.getHeight()); v.draw(canvas, 0, 0, w, h);
     * int s = Math.min(width, height) / 6; mVideoPlayIcon.draw(canvas, (width -
     * s) / 2, (height - s) / 2, s, s); } protected void
     * drawPanoramaBorder(GLCanvas canvas, int width, int height) { float scale
     * = (float) width / mPanoramaBorder.getWidth(); int w = Math.round(scale *
     * mPanoramaBorder.getWidth()); int h = Math.round(scale *
     * mPanoramaBorder.getHeight()); // draw at the top
     * mPanoramaBorder.draw(canvas, 0, 0, w, h); // draw at the bottom
     * mPanoramaBorder.draw(canvas, 0, height - h, w, h); }
     */

    protected boolean isPressedUpFrameFinished() {
        if (mFramePressedUp != null) {
            if (mFramePressedUp.isAnimating()) {
                return false;
            } else {
                mFramePressedUp = null;
            }
        }
        return true;
    }

    protected void drawPressedUpFrame(GLCanvas canvas, int width, int height) {
        if (mFramePressedUp == null) {
            mFramePressedUp = new FadeOutTexture(mFramePressed);
        }
        drawFrame(canvas, mFramePressed.getPaddings(), mFramePressedUp, 0, 0, width, height);
    }

    protected void drawPressedFrame(GLCanvas canvas, int width, int height) {
        drawFrame(canvas, mFramePressed.getPaddings(), mFramePressed, 0, 0, width, height);
    }

    protected void drawSelectedFrame(GLCanvas canvas, int width, int height) {
        drawFrame(canvas, mFrameSelected.getPaddings(), mFrameSelected, 0, 0, width, height);
    }

    protected static void drawFrame(GLCanvas canvas, Rect padding, Texture frame, int x, int y, int width, int height) {
        frame.draw(canvas, x - padding.left, y - padding.top, width + padding.left + padding.right, height
                + padding.top + padding.bottom);
    }
    //
    protected void drawCheckedBox(GLCanvas canvas, int width, int height) {
        drawFrame(canvas, mFramePressed.getPaddings(), mTagChecked, 0, 0, width, height);
    }
    protected void drawUncheckedBox(GLCanvas canvas, int width, int height) {
        drawFrame(canvas, mFramePressed.getPaddings(), mTagUnChecked, 0, 0, width, height);
    }
    protected static void drawBox(GLCanvas canvas, Rect padding, Texture frame, int x, int y, int width, int height) {
        frame.draw(canvas, x, y, width, height);
    }
}
