/*
 *                                                                                         
 * Copyright (c)2010-2012  Pinguo Company
 *                 品果科技                            版权所有 2010-2012
 * 
 * PROPRIETARY RIGHTS of Pinguo Company are involved in the
 * subject matter of this material.  All manufacturing, reproduction, use,
 * and sales rights pertaining to this subject matter are governed by the
 * license agreement.  The recipient of this software implicitly accepts   
 * the terms of the license.
 * 本软件文档资料是品果公司的资产,任何人士阅读和使用本资料必须获得
 * 相应的书面授权,承担保密责任和接受相应的法律约束.
 * 
 * FileName:AdapterBase.java
 * Author:
 * Date:2012-10-22 下午1:37:29 
 * 
 */

package com.pinguo.camera360.gallery.surpport;

import com.pinguo.camera360.gallery.data.Path;
import com.pinguo.camera360.gallery.ui.PhotoPicker.PuzzleItem;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.widget.BaseAdapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * // Base Adapter.
 * 
 * @author lizhipeng
 */
public abstract class AdapterBase extends BaseAdapter {

    protected List mList;
    private Context mContext;
    private LayoutInflater mLayoutInflater;
    
    public AdapterBase(Context context, List list) {
        mContext = context;
        mList = list;
        mLayoutInflater = LayoutInflater.from(mContext);
    }

    /**
     * Get parent context.
     * 
     * @return Context
     */
    public Context getContext() {
        return mContext;
    }

    @Override
    public int getCount() {
        return mList.size();
    }

    @Override
    public Object getItem(int pPosition) {
        return mList.get(pPosition);
    }

    @Override
    public long getItemId(int pPosition) {
        return pPosition;
    }

    /**
     * Get content list.
     * 
     * @return List
     */
    public List<PuzzleItem> getList() {
        return mList;
    }

    /**
     * Set content list.
     * 
     * @param list Content list
     */
    public void setList(List list) {
        mList = list;
        notifyDataSetChanged();
    }

    /**
     * Get layout inflater.
     * 
     * @return LayoutInflater
     */
    public LayoutInflater getLayoutInflater() {
        return mLayoutInflater;
    }

    /**
     * Set layout inflater.
     * 
     * @param layoutInflater Layout inflater
     */
    public void setLayoutInflater(LayoutInflater layoutInflater) {
        mLayoutInflater = layoutInflater;
    }

}
