
package com.pinguo.camera360.gallery.data.model;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Environment;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class C360PhotoDBHelper extends SQLiteOpenHelper {

    private static final String TAG = "C360PhotoDataBaseHelper";
    private static final String DATABASE_NAME = "sandbox.db";
    private static final int DATABASE_VERSION = 5;
    private static final String EXTERNAL_SDCARD_DB_DIRECTORY = "/Camera360/TempData/.sandbox/";
    private static final String EXTERNAL_SDCARD_DB_PATH = Environment.getExternalStorageDirectory().getPath()
            + EXTERNAL_SDCARD_DB_DIRECTORY + DATABASE_NAME;

    // 还原之前版本的数据库，这是个耗时操作，注意不要放在主线程做
    public static void restoreDBFromSdCard(Context context) {
        File file = context.getDatabasePath(DATABASE_NAME);
        if (!file.exists()) {
            try {
                File fileDir = new File(file.getParent());
                fileDir.mkdirs();
                copyDBFileFromSdCard(file);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    // 备份当前版本的数据库，这是个耗时操作，注意不要放在主线程做
    public static void backupDBToSdCard(Context context) {
        File file = context.getDatabasePath(DATABASE_NAME);
        if (file.exists()) {
            try {
                copyDBFileToSdCard(file);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private static void copyDBFileFromSdCard(File file) throws IOException {
        File dbFile = new File(EXTERNAL_SDCARD_DB_PATH); // SDCard上的数据库文件路径
        if (dbFile.exists()) {
            InputStream dbInput = new FileInputStream(dbFile);
            OutputStream dbOutput = new FileOutputStream(file);
            byte[] buffer = new byte[1024];
            int length;
            while ((length = dbInput.read(buffer)) > 0) {
                dbOutput.write(buffer, 0, length);
            }
            dbOutput.flush();
            dbOutput.close();
            dbInput.close();
        } else {
            // Log.i(TAG, "no album database file ound on sdcard!");
        }
    }

    private static void copyDBFileToSdCard(File file) throws IOException {
        File sdcardDBFile = new File(EXTERNAL_SDCARD_DB_PATH); // SDCard上的数据库文件路径
        if (!sdcardDBFile.exists()) {
            File fileDir = new File(sdcardDBFile.getParent());
            fileDir.mkdirs();
            sdcardDBFile.createNewFile();
        }
        if (sdcardDBFile.exists()) {
            InputStream dbInput = new FileInputStream(file);
            OutputStream dbOutput = new FileOutputStream(sdcardDBFile);
            byte[] buffer = new byte[1024];
            int length;
            while ((length = dbInput.read(buffer)) > 0) {
                dbOutput.write(buffer, 0, length);
            }
            dbOutput.flush();
            dbOutput.close();
            dbInput.close();
        } else {
            // Log.i(TAG, "no album database file ound on sdcard!");
        }
    }

    public C360PhotoDBHelper(Context context) {
        super(context, EXTERNAL_SDCARD_DB_PATH, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        //createCamera360PhotoTable(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (newVersion == 4) {
            Cursor cur = db.rawQuery("select sql from sqlite_master where tbl_name=?", new String[] {
                "photoproject"
            });
            if (oldVersion == 1) {
                if (cur.moveToFirst()) {
                    String str = cur.getString(cur.getColumnIndex("sql"));
                    if (str.indexOf("effectPhotoSavePath") == -1) {
                        // 增加字段
                        db.execSQL("alter table 'photoproject' add 'eftParam' varchar(500)");
                        db.execSQL("alter table 'photoproject' add 'failCount' int");
                        db.execSQL("alter table 'photoproject' add 'exif' varchar(500)");
                        db.execSQL("alter table 'photoproject' add 'projectState' varchar(20)");
                        db.execSQL("alter table 'photoproject' add 'direct' int");
                        db.execSQL("alter table 'photoproject' add 'width' int");
                        db.execSQL("alter table 'photoproject' add 'height' int");
                        db.execSQL("alter table 'photoproject' add 'costMillis' integer");
                        db.execSQL("alter table 'photoproject' add 'model' varchar(50)");
                        db.execSQL("alter table 'photoproject' add 'effectPhotoSavePath' varchar(700)");
                        db.execSQL("alter table 'photoproject' add 'projectVersionCode' int");
                        db.execSQL("alter table 'photoproject' add 'jsonExpand' varchar(700)");
                    }
                }
            } else if (oldVersion == 2) {
                if (cur.moveToFirst()) {
                    String str = cur.getString(cur.getColumnIndex("sql"));
                    if (str.indexOf("effectPhotoSavePath") == -1) {
                        db.execSQL("alter table 'photoproject' add 'effectPhotoSavePath' varchar(700)");
                        db.execSQL("alter table 'photoproject' add 'projectVersionCode' int");
                        db.execSQL("alter table 'photoproject' add 'jsonExpand' varchar(700)");
                    }
                }
            } else if (oldVersion == 3) {
                if (cur.moveToFirst()) {
                    String str = cur.getString(cur.getColumnIndex("sql"));
                    if (str.indexOf("projectVersionCode") == -1) {
                        db.execSQL("alter table 'photoproject' add 'projectVersionCode' int");
                        db.execSQL("alter table 'photoproject' add 'jsonExpand' varchar(700)");
                    }
                }
            }
        }
        if (newVersion == 3) {
            Cursor cur = db.rawQuery("select sql from sqlite_master where tbl_name=?", new String[] {
                "photoproject"
            });
            if (oldVersion == 1) {
                if (cur.moveToFirst()) {
                    String str = cur.getString(cur.getColumnIndex("sql"));
                    if (str.indexOf("effectPhotoSavePath") == -1) {
                        db.execSQL("alter table 'photoproject' add 'eftParam' varchar(500)");
                        db.execSQL("alter table 'photoproject' add 'failCount' int");
                        db.execSQL("alter table 'photoproject' add 'exif' varchar(500)");
                        db.execSQL("alter table 'photoproject' add 'projectState' varchar(20)");
                        db.execSQL("alter table 'photoproject' add 'direct' int");
                        db.execSQL("alter table 'photoproject' add 'width' int");
                        db.execSQL("alter table 'photoproject' add 'height' int");
                        db.execSQL("alter table 'photoproject' add 'costMillis' integer");
                        db.execSQL("alter table 'photoproject' add 'model' varchar(50)");
                        db.execSQL("alter table 'photoproject' add 'effectPhotoSavePath' varchar(700)");
                    }
                }
            } else if (oldVersion == 2) {
                if (cur.moveToFirst()) {
                    String str = cur.getString(cur.getColumnIndex("sql"));
                    if (str.indexOf("effectPhotoSavePath") == -1) {
                        db.execSQL("alter table 'photoproject' add 'effectPhotoSavePath' varchar(700)");
                    }
                }
            }
        }
        if (newVersion == 2) {
            if (oldVersion == 1 || oldVersion == 2) {
                Cursor cur = db.rawQuery("select sql from sqlite_master where tbl_name=?", new String[] {
                    "photoproject"
                });
                if (cur.moveToFirst()) {
                    String str = cur.getString(cur.getColumnIndex("sql"));
                    if (str.indexOf("eftParam") == -1) {
                        db.execSQL("alter table 'photoproject' add 'eftParam' varchar(500)");
                        db.execSQL("alter table 'photoproject' add 'failCount' int");
                        db.execSQL("alter table 'photoproject' add 'exif' varchar(500)");
                        db.execSQL("alter table 'photoproject' add 'projectState' varchar(20)");
                        db.execSQL("alter table 'photoproject' add 'direct' int");
                        db.execSQL("alter table 'photoproject' add 'width' int");
                        db.execSQL("alter table 'photoproject' add 'height' int");
                        db.execSQL("alter table 'photoproject' add 'costMillis' integer");
                        db.execSQL("alter table 'photoproject' add 'model' varchar(50)");
                    }
                }
            }
        }
    }

    private void createCamera360PhotoTable(SQLiteDatabase db) {
        String createTableSql = "CREATE TABLE " + C360PhotoProvider.PHOTO_TABLE_NAME + " (" + C360Photo._ID
                + " INTEGER PRIMARY KEY," + C360Photo.CAMERA_MODE_INDEX + " INTEGER," + C360Photo.EFFECT_INDEX
                + " INTEGER," + C360Photo.EFFECT_CLASS_INDEX + " INTEGER," + C360Photo.TOKEN_MILLISECONDS + " INTEGER,"
                + C360Photo.LATITUDE + " REAL," + C360Photo.LONGITUDE + " REAL," + C360Photo.EFFECT_PARAMETER
                + " VARCHAR(500), " + C360Photo.FAIL_COUNT + " INTEGER," + C360Photo.EXIF + " VARCHAR(500), "
                + C360Photo.PROJECT_STATE + " VARCHAR(20), " + C360Photo.DIRECTION + " INTEGER," + C360Photo.WIDTH
                + " INTEGER," + C360Photo.HEIGHT + " INTEGER," + C360Photo.COST_MILLISECONDS + " INTEGER,"
                + C360Photo.MODEL + " VARCHAR(50), " + C360Photo.EFFECT_PHOTO_SAVE_PATH + " VARCHAR(700), "
                + C360Photo.PROJECT_VERSIONCODE + " INTEGER," + C360Photo.JSON_EXPAND + " VARCHAR(700) " + ");";
        db.execSQL(createTableSql);
    }
}
