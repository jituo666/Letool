
package com.pinguo.camera360.gallery.data.model;

import com.pinguo.camera360.gallery.uitl.Log;

import android.content.ContentProvider;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;

public class C360PhotoProvider extends ContentProvider {

    private static final String TAG = "C360PhotoProvider";

    private static final UriMatcher sURLMatcher = new UriMatcher(UriMatcher.NO_MATCH);

    private static final int URL_CAMER360_PHOTO = 1;

    public static final String PHOTO_TABLE_NAME = "photoproject";

    private SQLiteOpenHelper mOpenHelper;

    static {
        sURLMatcher.addURI(C360Photo.AUTHORITY, C360Photo.TABLE_PATH, URL_CAMER360_PHOTO);
    }

    @Override
    public int delete(Uri url, String where, String[] whereArgs) {
        int count = 0;
        String tableName = "";
        SQLiteDatabase db = mOpenHelper.getWritableDatabase();
        switch (sURLMatcher.match(url)) {
            case URL_CAMER360_PHOTO: {
                tableName = PHOTO_TABLE_NAME;
                count = db.delete(tableName, where, whereArgs);
                break;
            }
        }
        if (count > 0) {
            getContext().getContentResolver().notifyChange(url, null);
        }
        //Log.i(TAG, "---------C360PhotoProvider-------delete" + count + ":whereArgs:" + whereArgs);
        return count;
    }

    @Override
    public String getType(Uri url) {
        switch (sURLMatcher.match(url)) {
            case URL_CAMER360_PHOTO:
                return "image";
            default:
                throw new IllegalArgumentException("Unknown URL " + url);
        }
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {

        String tableName = "";
        switch (sURLMatcher.match(uri)) {
            case URL_CAMER360_PHOTO: {
                tableName = PHOTO_TABLE_NAME;
                break;
            }
        }
        SQLiteDatabase db = mOpenHelper.getWritableDatabase();
        long rowID = db.insert(tableName, null, values);
        if (rowID > 0) {
            notifyChange(uri);
        } else {
            //Log.d(TAG, "insert failed!");
        }
        return null;
    }

    @Override
    public boolean onCreate() {
        mOpenHelper = new C360PhotoDBHelper(getContext());
        return true;
    }

    @Override
    public Cursor query(Uri uri, String[] projectionIn, String selection, String[] selectionArgs, String sort) {

        //Log.i(TAG, "xxxxxxxxxxxxxxxxx:projectionIn:" + projectionIn.toString() + " selection:" + selection + " selectionArgs:" +selectionArgs );
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();
        switch (sURLMatcher.match(uri)) {
            case URL_CAMER360_PHOTO: {
                constructQueryForCamera360Photo(qb, 0);
                break;
            }
            default: {
                return null;
            }
        }
        SQLiteDatabase db = mOpenHelper.getReadableDatabase();
        Cursor ret = qb.query(db, projectionIn, selection, selectionArgs, null, null, sort);
        ret.setNotificationUri(getContext().getContentResolver(), uri);
        return ret;
    }

    private void constructQueryForCamera360Photo(SQLiteQueryBuilder qb, int type) {
        qb.setTables(PHOTO_TABLE_NAME);
        if (type != 0) {
            qb.appendWhere("type=" + type);
        }
    }

    @Override
    public int update(Uri uri, ContentValues values, String where, String[] whereArgs) {
        int count = 0;
        String tableName = "";
        SQLiteDatabase db = mOpenHelper.getWritableDatabase();

        switch (sURLMatcher.match(uri)) {
            case URL_CAMER360_PHOTO: {
                tableName = PHOTO_TABLE_NAME;
                break;
            }
        }
        // where = DatabaseUtils.concatenateWhere(where, extraWhere);
        count = db.update(tableName, values, where, whereArgs);

        if (count > 0) {
            notifyChange(uri);
        }
        return 0;
    }

    private void notifyChange(Uri uri) {
        ContentResolver cr = getContext().getContentResolver();
        cr.notifyChange(uri, null);
    }

}
