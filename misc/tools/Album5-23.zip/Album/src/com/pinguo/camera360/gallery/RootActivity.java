/*
 * Copyright (C) 2010 The Android Open Source Project Licensed under the Apache
 * License, Version 2.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0 Unless required by applicable law
 * or agreed to in writing, software distributed under the License is
 * distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

package com.pinguo.camera360.gallery;

import com.pinguo.camera360.gallery.data.DataManager;
import com.pinguo.camera360.gallery.data.MediaItem;
import com.pinguo.camera360.gallery.data.Path;
import com.pinguo.camera360.gallery.ui.AlbumActionBar;
import com.pinguo.camera360.gallery.ui.GLRoot;
import com.pinguo.camera360.gallery.ui.GLRootView;
import com.pinguo.camera360.gallery.ui.PhotoPicker;
import com.pinguo.camera360.gallery.uitl.ThreadPool;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;

public class RootActivity extends Activity implements AlbumActivity, PhotoPicker.PickerListener {

    @SuppressWarnings("unused")
    private static final String TAG = "AbstractGalleryActivity";
    private GLRootView mGLRootView;
    private StateManager mStateManager;
    private OrientationManager mOrientationManager;
    private TransitionStore mTransitionStore = new TransitionStore();
    private PhotoPicker mPhotoPicker = null;
    private boolean mDisableToggleStatusBar;
    private AlertDialog mAlertDialog = null;
    protected AlbumActionBar mAlbumActionBar;
    private BroadcastReceiver mMountReceiver = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
            if (getExternalCacheDir() != null)
                onStorageReady();
        }
    };
    private IntentFilter mMountFilter = new IntentFilter(Intent.ACTION_MEDIA_MOUNTED);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mAlbumActionBar = new AlbumActionBar(this);
        mPhotoPicker = new PhotoPicker(this.getAndroidContext());
        mPhotoPicker.setPickerListener(this);
        mAlbumActionBar.setPhotoPicker(mPhotoPicker);
        mOrientationManager = new OrientationManager(this);
        toggleStatusBarByOrientation();
        getWindow().setBackgroundDrawable(null);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        mGLRootView.lockRenderThread();
        try {
            super.onSaveInstanceState(outState);
            getStateManager().saveState(outState);
        } finally {
            mGLRootView.unlockRenderThread();
        }
    }

    @Override
    public void onConfigurationChanged(Configuration config) {
        super.onConfigurationChanged(config);
        mStateManager.onConfigurationChange(config);
        toggleStatusBarByOrientation();
    }

    public Context getAndroidContext() {
        return this;
    }

    public DataManager getDataManager() {
        return ((AlbumAppImpl) getApplication()).getDataManager();
    }

    public ThreadPool getThreadPool() {
        return ((AlbumAppImpl) getApplication()).getThreadPool();
    }

    public synchronized StateManager getStateManager() {
        if (mStateManager == null) {
            mStateManager = new StateManager(this);
        }
        return mStateManager;
    }

    public GLRoot getGLRoot() {
        return mGLRootView;
    }

    public OrientationManager getOrientationManager() {
        return mOrientationManager;
    }

    @Override
    public void setContentView(int resId) {
        super.setContentView(resId);
        mGLRootView = (GLRootView) findViewById(R.id.gl_root_view);
    }

    protected void onStorageReady() {
        if (mAlertDialog != null) {
            mAlertDialog.dismiss();
            mAlertDialog = null;
            unregisterReceiver(mMountReceiver);
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (getExternalCacheDir() == null) {
            OnCancelListener onCancel = new OnCancelListener() {

                @Override
                public void onCancel(DialogInterface dialog) {
                    finish();
                }
            };
            OnClickListener onClick = new OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.cancel();
                }
            };
            mAlertDialog = new AlertDialog.Builder(this).setTitle("No Storage")
                    .setMessage("No external storage available.").setNegativeButton(android.R.string.cancel, onClick)
                    .setOnCancelListener(onCancel).show();
            registerReceiver(mMountReceiver, mMountFilter);
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (mAlertDialog != null) {
            unregisterReceiver(mMountReceiver);
            mAlertDialog.dismiss();
            mAlertDialog = null;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        mGLRootView.lockRenderThread();
        try {
            getStateManager().resume();
        } finally {
            mGLRootView.unlockRenderThread();
        }
        mGLRootView.onResume();
        mOrientationManager.resume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        mOrientationManager.pause();
        mGLRootView.onPause();
        mGLRootView.lockRenderThread();
        try {
            getStateManager().pause();
        } finally {
            mGLRootView.unlockRenderThread();
        }
        MediaItem.getMicroThumbPool().clear();
        MediaItem.getThumbPool().clear();
        MediaItem.getBytesBufferPool().clear();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mGLRootView.lockRenderThread();
        try {
            getStateManager().destroy();
        } finally {
            mGLRootView.unlockRenderThread();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        mGLRootView.lockRenderThread();
        try {
            getStateManager().notifyActivityResult(requestCode, resultCode, data);
        } finally {
            mGLRootView.unlockRenderThread();
        }
    }

    @Override
    public void onBackPressed() {
        // send the back event to the top sub-state
        GLRoot root = getGLRoot();
        root.lockRenderThread();
        try {
            getStateManager().onBackPressed();
        } finally {
            root.unlockRenderThread();
        }
    }

    protected void disableToggleStatusBar() {
        mDisableToggleStatusBar = true;
    }

    // Shows status bar in portrait view, hide in landscape view
    private void toggleStatusBarByOrientation() {
        if (mDisableToggleStatusBar)
            return;
        Window win = getWindow();
        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
            win.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        } else {
            win.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }
    }

    @Override
    public TransitionStore getTransitionStore() {
        return mTransitionStore;
    }

    @Override
    public AlbumActionBar getTopActionBar() {
        return mAlbumActionBar;
    }

    @Override
    public PhotoPicker getPhotoPicker() {
        return mPhotoPicker;
    }

    @Override
    public void onPickerModeChange(int mode) {
        ActivityState activitystate = getStateManager().getTopState();
        if (activitystate == null)
            return;
        switch (mode) {
            case PhotoPicker.ENTER_PICKER_MODE: {
                if (activitystate.getData().getInt(DataManager.MEDIA_TYPE) == DataManager.MEDIA_TYPE_SYSTEM_ALBUM) {
                    getTopActionBar().setActionBarMode(
                            AlbumActionBar.ACION_MODE_ALBUM_BROWSE | AlbumActionBar.ACION_MODE_PUZZLE_PICK);
                } else {
                    getTopActionBar().setActionBarMode(
                            AlbumActionBar.ACION_MODE_NAVIGATION | AlbumActionBar.ACION_MODE_PUZZLE_PICK);
                }
                activitystate.invalidate();
                break;
            }
            case PhotoPicker.LEAVE_PICKER_MODE: {
                if (activitystate.getData().getInt(DataManager.MEDIA_TYPE) == DataManager.MEDIA_TYPE_SYSTEM_ALBUM) {
                    getTopActionBar().setActionBarMode(
                            AlbumActionBar.ACION_MODE_ALBUM_BROWSE | AlbumActionBar.ACION_MODE_OPERATIONS);
                } else {
                    getTopActionBar().setActionBarMode(
                            AlbumActionBar.ACION_MODE_NAVIGATION | AlbumActionBar.ACION_MODE_OPERATIONS);
                }
                getTopActionBar().clearPuzzleList();
                activitystate.invalidate();
                break;
            }
        }
    }

    @Override
    public void onPickerChange(Path path, boolean picked) {
        getTopActionBar().setPuzzleList();;
    }
}
