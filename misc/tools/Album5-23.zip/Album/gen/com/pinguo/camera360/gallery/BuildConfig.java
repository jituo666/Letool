/** Automatically generated file. DO NOT MODIFY */
package com.pinguo.camera360.gallery;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}