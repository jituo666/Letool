
package com.dianxinos.cms.front.client.model;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.*;

/**
 * Tab数据结构
 * 
 * @author : wangweiwei Date: 3/31/12 Time: 2:44 PM
 */
public class Tab extends AbstractModel {
    public long pid;

    /**
     * tab的标签或者说分类
     */
    public String category;

    /**
     * tab对应的辅助物料信息，辅助物料类型->辅助物料列表
     */
    public HashMap<Integer, List<MaterialGroupPrimitive>> datas;

    /**
     * 是否是主页
     */
    public boolean home;


    public Tab(JSONObject jsonObject, long pid) throws JSONException {
        super(jsonObject);
        this.pid = pid;
        this.category = jsonObject.optString("type", null);
        this.home = jsonObject.optBoolean("home");
        datas = getDatas(jsonObject.optJSONObject("datas"));
    }

    private static HashMap<Integer, List<MaterialGroupPrimitive>> getDatas(JSONObject jsonObject) throws JSONException {
        if (null == jsonObject) {
            return null;
        }
        Iterator<String> iterator = jsonObject.keys();
        HashMap<Integer, List<MaterialGroupPrimitive>> datas = new HashMap<Integer, List<MaterialGroupPrimitive>>();
        while (iterator.hasNext()) {
            String key = iterator.next();
            JSONArray jsonArray = jsonObject.getJSONArray(key);
            int len = jsonArray.length();
            List<MaterialGroupPrimitive> list = new ArrayList<MaterialGroupPrimitive>();
            datas.put(Integer.parseInt(key), list);
            for (int i = 0; i < len; i++) {
                list.add(getMaterialGroupBasic(jsonArray.getJSONObject(i)));
            }
        }
        return datas;
    }

    private static MaterialGroupPrimitive getMaterialGroupBasic(JSONObject jsonObject) throws JSONException {
        long id = jsonObject.getLong("id");
        long sort = jsonObject.optLong("sort",0);
        List<Long> ad = getAdGroupIds(jsonObject.optJSONArray("ad"));
        return new MaterialGroupPrimitive(id, sort, ad);
    }

    private static List<Long> getAdGroupIds(JSONArray jsonArray) throws JSONException {
        if (null == jsonArray || jsonArray.length() == 0) {
            return null;
        }
        int len = jsonArray.length();
        List<Long> list = new ArrayList<Long>(len);
        for (int i = 0; i < len; i++) {
            list.add(jsonArray.getLong(i));
        }
        return list;
    }

    public long[] getAllSubIDs(int type) {
        List<MaterialGroupPrimitive> list = datas.get(type);
        if (list == null) {
            return null;
        }

        final int size = list.size();
        long[] ids = new long[size];
        int count = 0;

        for (MaterialGroupPrimitive mgp : list) {
            ids[count++] = mgp.id;
        }

        return ids;
    }
}
