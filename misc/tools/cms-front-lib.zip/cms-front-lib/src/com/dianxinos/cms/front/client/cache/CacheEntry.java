package com.dianxinos.cms.front.client.cache;

/**
 * Cache的value内容数据结构
 * @author  wangweiwei
 * Date: 4/5/12
 * Time: 2:19 PM
 */

public class CacheEntry {
    /**
     * cache的字符串之
     */
    public String value;
    /**
     * 最后修改时间
     */
    public long lastModified;
    /**
     * 访问次数
     */
    public int visitCount;

    @Override
    public String toString() {
        return this.getClass().getSimpleName() + "[value=" + value + "]";
    }
}
