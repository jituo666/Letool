package com.dianxinos.cms.front.client.model;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author wangweiwei
 *         Date: 4/4/12
 *         Time: 12:06 PM
 */
public abstract class AbstractModel {
    /**
     * 辅助物料类型 ： 榜单
     */
    public static final int MATERIAL_GROUP_TYPE_CATEGORY = 100;
    /**
     * 辅助物料类型 ： 专题
     */
    public static final int MATERIAL_GROUP_TYPE_TOPICS = 101;
    /**
     * 辅助物料类型 ： 广告
     */
    public static final int MATERIAL_GROUP_TYPE_AD = 102;
    /**
     * 辅助物料类型 ：推荐
     */
    public static final int MATERIAL_GROUP_TYPE_RECOMMEND = 103;
    /**
     * 基础物料类型 ：APK
     */
    public static final int BASE_MATERIAL_TYPE_APK = 1;
    /**
     * 基础物料类型 ：广告
     */
    public static final int BASE_MATERIAL_TYPE_AD = 2;
    /**
     * 基础物料类型 ：壁纸
     */
    public static final int BASE_MATERIAL_WALLPAPER = 3;
    /**
     * 基础物料类型 ：图片
     */
    public static final int BASE_MATERIAL_TYPE_IMAGE = 4;
    /**
     * 基础物料类型 ： 杂类
     */
    public static final int BASE_MATERIAL_MIX = 5;

/*****************************图片类型*************************************
 *  图片类型最大支持 99 大类，如果图片区分多语音 从第三位递增
 *  如：
 *   public static int IMAGE_TYPE_APK_ICON_EN=101;
 *   public static int IMAGE_TYPE_APK_ICON_TW=102;....
 *
 *************************************************************************/
    /**
     * 图片物料分辨率 ：72_72
     */
    public static final String IMAGE_RESOLUTION_72_72 = "72*72";
    /**
     * 图片物料分辨率 ：480*800
     */
    public static final String IMAGE_RESOLUTION_580_800 = "480*800";
    /**
     * 图片物料分辨率 ：162*243
     */
    public static final String IMAGE_RESOLUTION_162_243 = "162*243";
    /**
     * 图片辅助物料banner分辨率 ：480*204
     */
    public static final String IMAGE_RESOLUTION_480_204 = "480*204";

    /**
     * 图片类型： 图标
     */
    public static final int IMAGE_RESOLUTION_TYPE_ICON = 1;
    /**
     * 图片类型： 截图
     */
    public static final int IMAGE_RESOLUTION_TYPE_SNAPSHOTS = 2;
    /**
     * 图片类型： banner
     */
    public static final int IMAGE_RESOLUTION_TYPE_BANNER = 3;
    /**
     * 图片类型：其他
     */
    public static final int IMAGE_RESOLUTION_TYPE_OTHER = 4;


    /**
     * 广告类型 ：APK
     */
    public static final int AD_TYPE_APK = 1;
    /**
     * 广告类型  ：壁纸
     */
    public static final int AD_TYPE_WALLPAPER = 2;
    /**
     * 广告类型  ：自定义
     */
    public static final int AD_TYPE_CUSTOM = 3;


    public static List<MaterialGroup> parseMaterialGroups(JSONArray jsonArray, long pid, long tid) throws JSONException {
        List<MaterialGroup> list = new ArrayList<MaterialGroup>();
        int len = jsonArray.length();
        for (int i = 0; i < len; i++) {
            list.add(new MaterialGroup(jsonArray.getJSONObject(i), pid, tid));
        }
        return list;
    }

    public static AbstractModel parseDetail(JSONObject jsonObject) throws JSONException {
        if (jsonObject.length() < 1) {
            return null;
        }
        int type = jsonObject.getInt("type");
        if (type == AbstractModel.BASE_MATERIAL_TYPE_AD) {
            return new Ad(jsonObject);
        } else if (type == AbstractModel.BASE_MATERIAL_TYPE_APK) {
            return new Apk(jsonObject);
        } else if (type == AbstractModel.BASE_MATERIAL_WALLPAPER) {
            return new Wallpaper(jsonObject);
        } else {
            throw new IllegalArgumentException("unknown model:" + jsonObject);
        }
    }

    public static List<AbstractModel> parseMaterials(JSONArray jsonArray) throws JSONException {
        List<AbstractModel> list = new ArrayList<AbstractModel>();
        if (null != jsonArray) {
            int len = jsonArray.length();
            for (int i = 0; i < len; i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                list.add(parseDetail(jsonObject));
            }
        }
        return list;
    }


    public static Map<Integer, List<Image>> parseImages(JSONArray jsonArray) throws JSONException {
        if (null == jsonArray || jsonArray.length() == 0) {
            return null;
        }
        Map<Integer, List<Image>> images = new HashMap<Integer, List<Image>>();
        int len = jsonArray.length();
        for (int i = 0; i < len; i++) {
            JSONObject jsonObject = jsonArray.getJSONObject(i);
            Image image = new Image(jsonObject);
            List<Image> list = images.get(image.type);
            if (null == list) {
                list = new ArrayList<Image>();
                images.put(image.type, list);
            }
            list.add(image);
        }
        return images;
    }


    public long id;
    public int type;
    public String title;
    public String description;
    public String ext;
    public JSONObject json;

    public AbstractModel(JSONObject jsonObject) throws JSONException {
        this.json = jsonObject;
        this.id = jsonObject.getLong("id");
        this.title = jsonObject.optString("title", null);
        this.description = jsonObject.optString("description", null);
        this.ext = jsonObject.optString("ext", null);
        this.type = jsonObject.optInt("type", -1);
    }
}
