package com.dianxinos.cms.front.client.model;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * 图片
 * @author  wangweiwei
 * Date: 3/31/12
 * Time: 5:16 PM
 */
public class Image extends  AbstractModel{
    public String resolution;
    public String url;
    public long size;

    public Image(JSONObject jsonObject) throws JSONException {
        super(jsonObject);
        this.size = jsonObject.optLong("size",-1);
        this.url = jsonObject.getString("url");
        this.resolution = jsonObject.getString("resolution");
    }

}
