package com.dianxinos.cms.front.client.model;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;
import java.util.Map;

/**
 * 物料组
 * @author  wangweiwei
 * Date: 3/30/12
 * Time: 8:05 PM
 */
public class MaterialGroup  extends AbstractModel{
    public long pid;
    public long tid;
    public int contentType;
    public int total;
    public Map<Integer, List<Image>> images;
    public List<AbstractModel> datas;

    public MaterialGroup(JSONObject jsonObject, long pid, long tid) throws JSONException {
        super(jsonObject);
        this.json = jsonObject;
        this.pid = pid;
        this.tid = tid;
        this.contentType = jsonObject.getInt("contentType");
        this.total = jsonObject.getInt("total");
        this.images = parseImages(jsonObject.optJSONArray("images"));
        this.datas = parseMaterials(jsonObject.optJSONArray("datas"));
    }
}
