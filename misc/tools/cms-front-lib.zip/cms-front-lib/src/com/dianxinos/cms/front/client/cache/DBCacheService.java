package com.dianxinos.cms.front.client.cache;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;

import android.text.TextUtils;
import android.util.Log;
import com.dianxinos.cms.front.client.log.Logger;
import com.dianxinos.cms.front.client.provider.Record.RecordColumns;
import com.dianxinos.cms.front.client.provider.RecordDatabaseHelper;
import com.dianxinos.cms.front.client.provider.RecordProvider;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.*;

/**
 * @author wangweiwei
 *         Date: 4/4/12
 *         Time: 4:28 PM
 */
public class DBCacheService implements CacheService {

    private static final String TAG = DBCacheService.class.getName();

    public static long INITIAL_DELAY = 60;
    public static long PERIOD = 600;

    private static final String[] RECORD_PROJECTION = new String[]{
            RecordColumns.VALUE,
            RecordColumns.LAST_MODIFIED,
            RecordColumns.VISIT_COUNT,
    };


    private static final int RECORD_VALUE_COLUMN_INDEX = 0;
    private static final int RECORD_LAST_MODIFIED_COLUMN_INDEX = 1;
    private static final int RECORD_VISIT_COUNT_COLUMN_INDEX = 2;

    private static DBCacheService INSTANCE = null;

    public synchronized static DBCacheService getInstance(Context context) {
        if (INSTANCE == null) {
            INSTANCE = new DBCacheService(context);
        }
        return INSTANCE;
    }

    private Context context;
    private int maximumCapacity = 3000;
    private ScheduledThreadPoolExecutor executorService;

    private DBCacheService(Context context) {
        this(context, null);
    }

    private DBCacheService(Context context, ScheduledThreadPoolExecutor scheduledThreadPoolExecutor) {
        this.context = context;
        if (scheduledThreadPoolExecutor != null) {
            executorService = scheduledThreadPoolExecutor;
        } else {
            executorService = new ScheduledThreadPoolExecutor(1);
        }
        executorService.scheduleAtFixedRate(new EvictTask(), INITIAL_DELAY, PERIOD, TimeUnit.SECONDS);
    }

    @Override
    public int getMaximumCapacity() {
        return maximumCapacity;
    }

    public void setMaximumCapacity(int maximumCapacity) {
        this.maximumCapacity = maximumCapacity;
    }

    @Override
    public CacheEntry get(String key) {
        Map<String, Object> record = queryRecord(context, key);
        CacheEntry cacheEntry = null;

        if (record != null) {
            Log.v(TAG, "hit cache:" + record);
            cacheEntry = new CacheEntry();
            cacheEntry.visitCount = (Integer) record.get("visitCount");
            updateRecordCount(context, key, cacheEntry.visitCount + 1);
            cacheEntry.value = (String) record.get("value");
            cacheEntry.lastModified = (Long) record.get("lastModified");
        }

        return cacheEntry;
    }

    @Override
    public boolean set(String key, CacheEntry newEntry) {
        if (newEntry == null || TextUtils.isEmpty(newEntry.value)) {
            Logger.v(TAG, "empty newEntry:" + newEntry);
            return false;
        }
        String selection = RecordColumns.KEY + "=?";
        String[] selectionArgs = new String[]{
                key,
        };

        Map<String, Object> record = queryRecord(context, key);

        ContentValues values = new ContentValues();

        values.put(RecordColumns.LAST_MODIFIED, newEntry.lastModified);
        values.put(RecordColumns.VALUE, newEntry.value);

        try {
            if (record == null) {
                values.put(RecordColumns.KEY, key);
                values.put(RecordColumns.VISIT_COUNT, "1");
                Uri uri = RecordProvider.getInstance(context).insert(RecordColumns.CONTENT_URI, values);
                if (uri != null)
                    return true;
            } else {
                int result = RecordProvider.getInstance(context).update(RecordColumns.CONTENT_URI, values, selection, selectionArgs);
                if (result > 0)
                    return true;
            }
        } catch (Exception e) {
            Logger.d(TAG, "failed to insert or update record", e);
        }

        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public boolean delete(String key) {
        String selection = RecordColumns.KEY + "=?";
        String[] selectionArgs = new String[]{
                key,
        };

        int count = RecordProvider.getInstance(context).delete(RecordColumns.CONTENT_URI, selection, selectionArgs);

        return count > 0;
    }

    @Override
    public void shutdown() {
        executorService.shutdownNow();
        RecordDatabaseHelper.getInstance(context).close();
    }

    private Map<String, Object> queryRecord(Context context, String key) {
        Cursor cursor = null;
        Map<String, Object> result = null;
        try {
            String selection = RecordColumns.KEY + "=?";
            String[] selectionArgs = new String[]{
                    key,
            };

            cursor = RecordProvider.getInstance(context).query(
                    RecordColumns.CONTENT_URI, RECORD_PROJECTION, selection,
                    selectionArgs, null);
            if (cursor != null && cursor.moveToFirst()) {
                result = new HashMap<String, Object>();
                result.put("value", cursor.getString(RECORD_VALUE_COLUMN_INDEX));
                result.put("lastModified", cursor.getLong(RECORD_LAST_MODIFIED_COLUMN_INDEX));
                result.put("visitCount", cursor.getInt(RECORD_VISIT_COUNT_COLUMN_INDEX));
            }
        } catch (Exception e) {
            Logger.d(TAG, "failed to query record", e);
        } finally {
            if (cursor != null)
                cursor.close();
        }

        return result;
    }

    private int updateRecordCount(Context context, String key, int count) {
        String selection = RecordColumns.KEY + "=?";
        String[] selectionArgs = new String[]{
                key,
        };

        ContentValues values = new ContentValues();
        values.put(RecordColumns.VISIT_COUNT, count);
        return RecordProvider.getInstance(context).update(RecordColumns.CONTENT_URI, values, selection, selectionArgs);
    }


    final class EvictTask implements Runnable {
        public EvictTask() {
        }

        @Override
        public void run() {
            int count = RecordProvider.getInstance(context).count();
            long start = System.currentTimeMillis();
            Logger.d(TAG, "evict,count=" + count + ",capacity=" + maximumCapacity);
            if (count > maximumCapacity) {
                SQLiteDatabase db = RecordDatabaseHelper.getInstance(context).getWritableDatabase();
                int limit = count - maximumCapacity + 50;//多删除50个cache项，避免evict频繁触发
                Cursor cursor = db.rawQuery("select " + RecordColumns._ID + "," + RecordColumns.VALUE + " from " + RecordDatabaseHelper.RECORD_TABLE_NAME +
                        " order by " + RecordColumns.LAST_ACCESS + " ASC," + RecordColumns.VISIT_COUNT + " ASC limit " + limit, null);
                Logger.d(TAG, "evict query time used:" + (System.currentTimeMillis() - start));
                if (cursor != null) {
                    StringBuilder commaSeperatedIds = new StringBuilder();
                    while (cursor.moveToNext()) {
                        String id = cursor.getString(0);
                        String value = cursor.getString(1);
                        boolean shouldDelete = true; //如果是文件没有正常删除成功的话，那么也不清除cache，以免留下dead file在sd卡上无法清除
                        if (value.endsWith("png")) {
                            File file = new File(CacheService.IMAGE_CACHE_BASE_DIR, value);
                            if (file.exists()) {
                                shouldDelete = file.delete();
                            }
                        }
                        if (shouldDelete) {
                            commaSeperatedIds.append(id).append(',');
                        }
                    }
                    if (commaSeperatedIds.length() > 0) {
                        String ids = commaSeperatedIds.substring(0, commaSeperatedIds.length() - 1);
                        int sum = db.delete(RecordDatabaseHelper.RECORD_TABLE_NAME, RecordColumns._ID + " in (" + ids + ")", null);
                        if (sum < limit) {
                            Logger.d(TAG, "evict,deleted:" + sum + ",limit:" + limit);
                        }
                    }
                    cursor.close();
                }
            }
            Logger.d(TAG, "evict time used:" + (System.currentTimeMillis() - start));
        }
    }
}