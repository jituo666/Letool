package com.dianxinos.cms.front.client.provider;

import com.dianxinos.DXStatService.utils.BaseInfoHelper;
import com.dianxinos.cms.front.client.provider.Record.RecordColumns;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * 数据库Helper
 */
public class RecordDatabaseHelper extends SQLiteOpenHelper {
    private static final String TAG = RecordDatabaseHelper.class.getName();

    private static final int DATABASE_VERSION = 2;
    public static final String RECORD_TABLE_NAME = "records";
    private static SQLiteOpenHelper INSTANCE = null;

    public synchronized static SQLiteOpenHelper getInstance(Context context) {
        if (INSTANCE == null) {
            INSTANCE = new RecordDatabaseHelper(context);
        }
        return INSTANCE;
    }

    private RecordDatabaseHelper(Context context) {
        super(context, BaseInfoHelper.getPkgName(context) + "_cms.db", null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + RECORD_TABLE_NAME + " ("
                + RecordColumns._ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + RecordColumns.KEY + " TEXT UNIQUE,"    /*unique index to enhance performance*/
                + RecordColumns.VALUE + " TEXT,"
                + RecordColumns.LAST_ACCESS + " INTEGER,"
                + RecordColumns.LAST_MODIFIED + " INTEGER,"
                + RecordColumns.VISIT_COUNT + " INTEGER"
                + ");");
        //增加索引来提高order by的效率
        db.execSQL("CREATE INDEX lurIndex on "+RECORD_TABLE_NAME+ "("+ RecordColumns.LAST_ACCESS + " ASC," + RecordColumns.VISIT_COUNT + " ASC)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        Log.w(TAG, "Upgrading database from version " + oldVersion + " to "
                + newVersion + ", which will destroy all old data");
        db.execSQL("DROP TABLE IF EXISTS " + RECORD_TABLE_NAME);
        onCreate(db);
    }

}