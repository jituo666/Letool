package com.dianxinos.cms.front.client.model;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;
import java.util.Map;


/**
 * Apk
 */
public class Apk extends AbstractModel {
    public String pkg;
    public String versionName;
    public int versionCode;
    public long size;
    public String author;
    public String shortDesc;
    public int downloadCount;
    public String downloadUrl;
    public String language;
    public String tags;
    public String categories;
    public double rating;
    public int ratingCount;
    public long modifiedTime;
    public String supportUrl;
    public Map<Integer, List<Image>> images;


    public Apk(JSONObject jsonObject) throws JSONException {
        super(jsonObject);
        this.pkg = jsonObject.getString("pkg");
        this.versionName = jsonObject.getString("versionName");
        this.versionCode = jsonObject.getInt("versionCode");
        this.size = jsonObject.getLong("size");
        this.author = jsonObject.optString("author", null);
        this.shortDesc = jsonObject.optString("shortDesc", null);
        this.downloadCount = jsonObject.optInt("downloadCount");
        this.downloadUrl = jsonObject.getString("downloadUrl");
        this.language = jsonObject.optString("language", null);
        this.tags = jsonObject.optString("tags", null);
        this.categories = jsonObject.optString("categories", null);
        this.rating = jsonObject.optDouble("rating");
        this.ratingCount=jsonObject.optInt("ratingCount");
        this.modifiedTime = jsonObject.optLong("modifiedTime");
        this.supportUrl = jsonObject.optString("supportUrl", null);
        this.images = parseImages(jsonObject.optJSONArray("images"));
    }
}
