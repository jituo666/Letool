package com.dianxinos.cms.front.client;

import android.content.Context;
import android.os.Environment;
import android.util.Log;
import com.dianxinos.DXStatService.stat.DXStatService;
import com.dianxinos.DXStatService.stat.TokenManager;
import com.dianxinos.cms.front.client.cache.CacheEntry;
import com.dianxinos.cms.front.client.cache.CacheService;
import com.dianxinos.cms.front.client.cache.DBCacheService;
import com.dianxinos.cms.front.client.callback.CMSFrontRestCallBack;
import com.dianxinos.cms.front.client.log.Logger;
import com.dianxinos.cms.front.client.model.*;
import com.dianxinos.cms.front.client.utils.*;
import org.apache.http.*;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URIUtils;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicHeader;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.CharArrayBuffer;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.io.*;
import java.net.URI;
import java.net.URISyntaxException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.text.ParseException;
import java.util.*;
import java.util.concurrent.*;
import java.util.zip.GZIPInputStream;

/**
 * 对cms front接口的封装类
 *
 * @author wangweiwei
 *         Date: 3/30/12
 *         Time: 8:05 PM
 */
public class CMSFrontRestService {

    public static enum Sort {
        DEFAULT("sort"),
        UPDATE("modifiedTime"),
        DOWNLOAD("downloadCount");
        private String field;

        Sort(String f) {
            field = f;
        }


        public String getField() {
            return field;
        }

        public void setField(String field) {
            this.field = field;
        }

        @Override
        public String toString() {
            return field;
        }
    }

    private static final String TAG = CMSFrontRestService.class.getName();
    /**
     * 请求返回错误状态时候的错误信息
     */
    public static final String MSG_NETWORK_ERROR = "NETWORK_FAIL";

    /**
     * cms接口的协议版本号
     */
    public static final String CMS_FRONT_PROTOCOL_VERSION = "1.0";


    /**
     * 图片的请求优先级
     */
    private static final int IMAGE_PRIORITY = 0;
    /**
     * Api的请求优先级
     */
    private static final int API_PRIORITY = 1;
    /**
     * 最深递归层次
     */
    private static final int MAX_RECURSIVE_DEPTH = 2;
    /**
     * 超时
     */
    private static final int SOCKET_TIME_OUT = 20000;
    /**
     * 检查更新在命中cache情况下的检查间隔默认值
     */
    private static final int CHECK_UPDATE_HIT_CACHE_DEFAULT_INTERVAL = 1000 * 60 * 60 * 24;
    /**
     * 公钥
     */
    private final static String MODULUS = "91984037215497453715695537150101136180891052789697033543194092619618648264321686995125910645918307527361902207937849374278999247610081485346792920961341041235187112556183400885916498929543480156108595411929206248207390582439108464025592253754008974647620342386179132598251271296121068499378920392705867355039";
    private final static String PUBLIC_EXPONENT = "65537";
    private static final PublicKey PUBLIC_KEY = SecurityUtils.getPublicKey(MODULUS, PUBLIC_EXPONENT);


    private static final String DEV_HOST = "10.18.102.104";
    private static final int DEV_PORT = 3724;
    private static final String DEV_PATH = "cms";
    private static final String TEST_HOST = "t1.tira.cn";
    private static final int TEST_PORT = 8125;
    private static final String TEST_PATH = "cms";
    private static final String PROD_HOST = "mk.jccjd.com";
    private static final int PROD_PORT = 80;
    private static final String PROD_PATH = "cf";

    private static final Header HEADER_CONTENT_GZIP = new BasicHeader("Content-Encoding", "gzip");
    private static final Header HEADER_ACCEPT_GZIP = new BasicHeader("Accept-Encoding", "gzip");


    /**
     * 请求服务的地址
     */
    public static String host = DEV_HOST;
    /**
     * 服务端口
     */
    public static int port = DEV_PORT;
    /**
     * 服务路径
     */
    public static String path = DEV_PATH;

    private static CMSFrontRestService INSTANCE = null;
    private CacheService cacheService;
    private String sid = "862fe64a3f627a61727cd443ca79f1bf";
    private Context context;
    private String urlSuffix;
    /**
     * 用来执行请求
     */
    private XThreadPoolExecutor threadPool;
    /**
     * * 检查更新在命中cache情况下的检查间隔
     */
    private long checkUpdateHitCacheInterval = CHECK_UPDATE_HIT_CACHE_DEFAULT_INTERVAL;

    /**
     * 用来设置运行环境，dev,test,prod
     *
     * @param env
     */
    public static void setEnvironment(String env) {
        if ("dev".equals(env)) {
            host = DEV_HOST;
            port = DEV_PORT;
            path = DEV_PATH;
            Logger.LEVEL = Log.VERBOSE;
        } else if ("test".equals(env)) {
            host = TEST_HOST;
            port = TEST_PORT;
            path = TEST_PATH;
            Logger.LEVEL = Log.VERBOSE;
        } else if ("prod".equals(env)) {
            host = PROD_HOST;
            port = PROD_PORT;
            path = PROD_PATH;
            Logger.LEVEL = Log.WARN;
        } else {
            throw new IllegalArgumentException("bad env:" + env);
        }
    }

    /**
     * 获取cache service实例
     *
     * @return @see CacheService  CacheService接口
     */
    public CacheService getCacheService() {
        return cacheService;
    }

    /**
     * 设置cache service实例
     */
    public void setCacheService(CacheService cacheService) {
        this.cacheService = cacheService;
    }

    /**
     * 获取session id
     *
     * @return session id
     */
    public String getSid() {
        return sid;
    }

    /**
     * 设置session id
     *
     * @param sid
     */
    public void setSid(String sid) {
        this.sid = sid;
    }

    public long getCheckUpdateHitCacheInterval() {
        return checkUpdateHitCacheInterval;
    }

    public void setCheckUpdateHitCacheInterval(long checkUpdateHitCacheInterval) {
        this.checkUpdateHitCacheInterval = checkUpdateHitCacheInterval;
    }

    /**
     * 获取CMSFrontRestService实例
     *
     * @param context
     * @return CMSFrontRestService实例
     */
    public synchronized static CMSFrontRestService getInstance(Context context) {
        if (INSTANCE == null) {
            INSTANCE = new CMSFrontRestService(context);
        }
        return INSTANCE;
    }

    private CMSFrontRestService(Context context) {
        this(DBCacheService.getInstance(context), context);
    }

    private CMSFrontRestService(CacheService cacheService, Context context) {
        this.cacheService = cacheService;
        this.context = context;
        this.urlSuffix = DXStatService.getUrlSuffix(context);
        threadPool = new XThreadPoolExecutor(2, 4, 60L, TimeUnit.SECONDS,
                new PriorityBlockingQueue<Runnable>(100), new ThreadPoolExecutor.DiscardOldestPolicy());
        HttpClientFactory.setProxy(HttpClientFactory.getThreadSafeClient(), HttpClientFactory.getProxyInfo(context));
    }


    public String getUrlSuffix() {
        return urlSuffix;
    }

    public void setUrlSuffix(String urlSuffix) {
        this.urlSuffix = urlSuffix;
    }

    /**
     * 获取图片
     *
     * @param url      图片url
     * @param callBack callback，不能为null
     */
    public void getImage(final String url, final CMSFrontRestCallBack<InputStream> callBack) {
        callBack.onSubmit(threadPool.submit(new PriorityTask(IMAGE_PRIORITY) {
            @Override
            public void run() {
                int status;
                //sd卡可写
                boolean mExternalStorageWriteable;
                //sd卡可读
                boolean mExternalStorageAvailable;
                String state = Environment.getExternalStorageState();
                if (Environment.MEDIA_MOUNTED.equals(state)) {
                    mExternalStorageAvailable = mExternalStorageWriteable = true;
                } else if (Environment.MEDIA_MOUNTED_READ_ONLY.equals(state)) {
                    mExternalStorageAvailable = true;
                    mExternalStorageWriteable = false;
                } else {
                    mExternalStorageAvailable = mExternalStorageWriteable = false;
                }
                CacheEntry cacheEntry = null;
                try {
                    String key = Utils.getMD5(url);
                    cacheEntry = cacheService.get(key);

                    // ensure target dir exists
                    if (mExternalStorageWriteable) {
                        File dir = new File(CacheService.IMAGE_CACHE_BASE_DIR, key.substring(0,2));
                        if (!dir.exists()) {
                            dir.mkdirs();
                        }
                    }

                    // reload from network if file lost
                    if (null != cacheEntry) {
                        File imgFile = new File(CacheService.IMAGE_CACHE_BASE_DIR, cacheEntry.value);
                        if (!imgFile.exists()) {
                            cacheEntry = null;
                        }
                    }

                    if (null == cacheEntry) {
                        cacheEntry = new CacheEntry();
                        cacheEntry.value = generateImageFileName(key);
                        status = requestImage(new URI(url), null, callBack, cacheEntry, mExternalStorageWriteable);
                        if (HttpStatus.SC_OK == status && mExternalStorageWriteable) {//首次访问并且sd卡可写，则缓存并告知回调成功
                            cacheService.set(key, cacheEntry);
                            callBack.onSuccess(status, new FileInputStream(new File(CacheService.IMAGE_CACHE_BASE_DIR, cacheEntry.value)));
                        }
                        //sd卡不可写但状态为200的情况下已经正常通知成功，其他情况都是失败，在requestImage中已经通知失败
                    } else {
                        List<Header> headers = new ArrayList<Header>(1);
                        if (mExternalStorageAvailable) { //如果sd还可读，那么可以用cache
                            headers.add(getIfModifiedSinceHeader(cacheEntry.lastModified));
                        }
                        status = requestImage(new URI(url), headers, callBack, cacheEntry, mExternalStorageWriteable);
                        if (HttpStatus.SC_OK == status && mExternalStorageWriteable) {  //200并且sd卡可写，cache并通知回调成功
                            cacheService.set(key, cacheEntry);
                            callBack.onSuccess(status, new FileInputStream(new File(CacheService.IMAGE_CACHE_BASE_DIR, cacheEntry.value)));
                        }
                        if (mExternalStorageAvailable && status == HttpStatus.SC_NOT_MODIFIED) {//304并且sd卡可读，通知回调成功
                            try {
                                InputStream is = new FileInputStream(new File(CacheService.IMAGE_CACHE_BASE_DIR, cacheEntry.value));
                                callBack.onSuccess(status, is);
                            } catch (Exception e) {
                                Logger.w("TAG", "file lost, reload from network: val=" + cacheEntry.value + ", url=" + url);
                                // file is lost or read failed, reload from network
                                cacheEntry.value = generateImageFileName(key);
                                status = requestImage(new URI(url), null, callBack, cacheEntry, mExternalStorageWriteable);
                                if (HttpStatus.SC_OK == status && mExternalStorageWriteable) {//首次访问并且sd卡可写，则缓存并告知回调成功
                                    cacheService.set(key, cacheEntry);
                                    callBack.onSuccess(status, new FileInputStream(new File(CacheService.IMAGE_CACHE_BASE_DIR, cacheEntry.value)));
                                }
                            }
                        }
                        //200/304之外，已经在requestImage中通知失败，sd卡不可写的情况下分
                        // 1.可读，200已经正常通知成功，304也会通知成功。
                        // 2.不可读，200会通知成功，其他都认为失败(这种情况下不会304,因为没有设置请求header）
                    }
                } catch (Exception e) {
                    InputStream inputStream = null;
                    try {
                        if (cacheEntry != null && cacheEntry.value != null && mExternalStorageAvailable) {
                            inputStream = new FileInputStream(new File(CacheService.IMAGE_CACHE_BASE_DIR, cacheEntry.value));
                        }
                    } catch (FileNotFoundException e1) {
                        Logger.d(TAG, "file not found", e1);
                    }
                    callBack.onException(e, inputStream);
                    Logger.d(TAG, "failed to get image", e);
                }
            }
        }));
    }

    private int requestImage(URI uri, List<Header> headers, CMSFrontRestCallBack<InputStream> callBack, CacheEntry cacheEntry, boolean mExternalStorageWriteable) throws IOException, ParseException {
        HttpResponse httpResponse = executeGetRequest(uri, headers, false);
        try {
            int status = httpResponse.getStatusLine().getStatusCode();
            if (status != HttpStatus.SC_OK && status != HttpStatus.SC_NOT_MODIFIED) {
                callBack.onFail(status, MSG_NETWORK_ERROR);
            } else if (status == HttpStatus.SC_OK) {
                cacheEntry.lastModified = getLastModified(httpResponse);
                HttpEntity entity = httpResponse.getEntity();
                if (mExternalStorageWriteable) { //sd卡可写，则用sdk缓存
                    FileOutputStream out = null;
                    InputStream in = null;
                    try {
                        File file = new File(CacheService.IMAGE_CACHE_BASE_DIR, cacheEntry.value);
                        File parent = file.getParentFile();
                        if (!parent.exists()) {
                            file.getParentFile().mkdirs();
                        }
                        out = new FileOutputStream(file);
                        in = entity.getContent();
                        Header encodingHeader = entity.getContentEncoding();
                        if (encodingHeader != null && encodingHeader.getValue().indexOf("gzip") != -1) {
                            in = new GZIPInputStream(in);
                        }
                        Utils.copyLarge(in, out);
                    } finally {
                        Utils.closeQuietly(in);
                        Utils.closeQuietly(out);
                    }
                } else {       //sd卡不可写，直接返回inputstream流
                    callBack.onSuccess(status, entity.getContent());
                }
            }
            return status;
        } finally {
            consumEntity(httpResponse);
        }
    }

    private String generateImageFileName(String key) {
        return key.substring(0, 2) + "/" + key.substring(2) + ".png";
    }

    /**
     * 获取项目信息
     *
     * @param child    子类，比如dxhot
     * @param callBack 不能为null
     */
    public void getProject(final String child, final CMSFrontRestCallBack<Project> callBack) {
        callBack.onSubmit(threadPool.submit(new PriorityTask() {
            @Override
            public void run() {
                int status;
                CacheEntry cacheEntry = null;
                try {
                    List<NameValuePair> params = new ArrayList<NameValuePair>();
                    params.add(new BasicNameValuePair("child", child));
                    URI uri = URIUtils.createURI("http", host, port, path + "/project",
                            urlSuffix + "&" + URLEncodedUtils.format(params, HTTP.UTF_8), null);
                    String key = Utils.getMD5(uri.toString());
                    cacheEntry = cacheService.get(key);
                    JsonResponse jsonResponse = new JsonResponse();
                    if (null == cacheEntry) {   //never visited
                        cacheEntry = new CacheEntry();
                        status = requestProject(uri, null, callBack, jsonResponse, 1);
                        if (HttpStatus.SC_OK == status) {
                            cacheEntry.lastModified = jsonResponse.lastModified;
                            cacheEntry.value = jsonResponse.response.toString();
                            cacheService.set(key, cacheEntry);
                            callBack.onSuccess(status, new Project(jsonResponse.response));
                        }
                    } else {
                        List<Header> headers = new ArrayList<Header>(1);
                        headers.add(getIfModifiedSinceHeader(cacheEntry.lastModified));
                        status = requestProject(uri, headers, callBack, jsonResponse, 1);
                        if (status == HttpStatus.SC_OK) {
                            cacheEntry.lastModified = jsonResponse.lastModified;
                            cacheEntry.value = jsonResponse.response.toString();
                            cacheService.set(key, cacheEntry);
                            callBack.onSuccess(status, new Project(jsonResponse.response));
                        } else if (status == HttpStatus.SC_NOT_MODIFIED) {
                            callBack.onSuccess(status, new Project(new JSONObject(cacheEntry.value)));
                        }
                    }
                } catch (Exception e) {
                    Project project = null;
                    try {
                        if (cacheEntry != null && cacheEntry.value != null) {
                            project = new Project(new JSONObject(cacheEntry.value));
                        }
                    } catch (JSONException e1) {
                        Logger.d(TAG, "failed to parse project", e1);
                    }
                    callBack.onException(e, project);
                    Logger.d(TAG, "failed to get project", e);
                }
            }
        }));
    }

    private int requestProject(URI uri, List<Header> headers, CMSFrontRestCallBack<Project> callBack, JsonResponse jsonResponse, int depth) throws IOException, JSONException, IllegalBlockSizeException, InvalidKeyException, NoSuchAlgorithmException, InvalidKeySpecException, NoSuchPaddingException, URISyntaxException, BadPaddingException, ParseException {
        if (depth > MAX_RECURSIVE_DEPTH) {
            throw new IOException("Too much recursion:" + MAX_RECURSIVE_DEPTH);
        }
        HttpResponse httpResponse = executeGetRequest(uri, headers, true);
        try {
            int status = httpResponse.getStatusLine().getStatusCode();
            if (status != HttpStatus.SC_OK && status != HttpStatus.SC_NOT_MODIFIED) {
                callBack.onFail(status, MSG_NETWORK_ERROR);
            } else if (status == HttpStatus.SC_OK) {
                JSONObject jsonObject = toJSONObject(httpResponse);
                JSONObject responseHeader = jsonObject.getJSONObject("responseHeader");
                jsonResponse.responseHeader = responseHeader;
                status = responseHeader.getInt("status");
                if (status == HttpStatus.SC_OK) {
                    jsonResponse.response = jsonObject.getJSONObject("response");
                    jsonResponse.lastModified = getLastModified(httpResponse);
                } else if (status == HttpStatus.SC_FORBIDDEN)     //invalid sid
                {
                    getSessionId();
                    return requestProject(uri, headers, callBack, jsonResponse, depth++);
                } else {
                    callBack.onFail(status, responseHeader.optString("msg"));
                }
            }
            return status;
        } finally {
            consumEntity(httpResponse);
        }
    }

    private void consumEntity(HttpResponse httpResponse) {
        if (httpResponse == null || httpResponse.getEntity() == null) {
            return;
        }
        try {
            HttpEntity entity = httpResponse.getEntity();
            entity.consumeContent();
        } catch (Exception e) {
            Logger.v(TAG, "failed to cosume entity", e);
        }
    }

    /**
     * @param pid      project id
     * @param tid      tab id
     * @param ids      material group ids
     * @param callBack 不能为null
     */
    public void getMaterialGroup(final long pid, final long tid, final long[] ids, final CMSFrontRestCallBack<List<MaterialGroup>> callBack) {
        getMaterialGroup(pid, tid, ids, 0, callBack);
    }

    /**
     * 获取辅助物料
     *
     * @param pid      project id
     * @param tid      tab id
     * @param ids      group ids
     * @param top      also get the top n materials in all the material groups
     * @param callBack 不能为null
     */
    public void getMaterialGroup(final long pid, final long tid, final long[] ids, final int top, final CMSFrontRestCallBack<List<MaterialGroup>> callBack) {
        callBack.onSubmit(threadPool.submit(new PriorityTask() {
            @Override
            public void run() {
                int status;
                CacheEntry cacheEntry = null;
                try {
                    List<NameValuePair> params = new ArrayList<NameValuePair>();
                    params.add(new BasicNameValuePair("pid", String.valueOf(pid)));
                    params.add(new BasicNameValuePair("tid", String.valueOf(tid)));
                    params.add(new BasicNameValuePair("top", String.valueOf(top)));
                    for (int i = 0; i < ids.length; i++) {
                        params.add(new BasicNameValuePair("ids", String.valueOf(ids[i])));
                    }
                    URI uri = URIUtils.createURI("http", host, port, path + "/materialGroup",
                            urlSuffix + "&" + URLEncodedUtils.format(params, HTTP.UTF_8), null);
                    String key = Utils.getMD5(uri.toString());
                    cacheEntry = cacheService.get(key);
                    JsonResponse jsonResponse = new JsonResponse();
                    if (null == cacheEntry) {   //never visited
                        cacheEntry = new CacheEntry();
                        status = requestMaterialGroup(uri, null, callBack, jsonResponse, 1);
                        if (HttpStatus.SC_OK == status) {
                            JSONArray datas = jsonResponse.response.getJSONArray("datas");
                            cacheEntry.lastModified = jsonResponse.lastModified;
                            cacheEntry.value = datas.toString();
                            cacheService.set(key, cacheEntry);
                            callBack.onSuccess(status, AbstractModel.parseMaterialGroups(datas, pid, tid));
                        }
                    } else {  //visited
                        List<Header> headers = new ArrayList<Header>(1);
                        headers.add(getIfModifiedSinceHeader(cacheEntry.lastModified));
                        status = requestMaterialGroup(uri, headers, callBack, jsonResponse, 1);
                        if (status == HttpStatus.SC_OK) {
                            JSONArray datas = jsonResponse.response.getJSONArray("datas");
                            cacheEntry.lastModified = jsonResponse.lastModified;
                            cacheEntry.value = datas.toString();
                            cacheService.set(key, cacheEntry);
                            callBack.onSuccess(status, AbstractModel.parseMaterialGroups(datas, pid, tid));
                        } else if (status == HttpStatus.SC_NOT_MODIFIED) {
                            callBack.onSuccess(status, AbstractModel.parseMaterialGroups(new JSONArray(cacheEntry.value), pid, tid));
                        }
                    }
                } catch (Exception e) {
                    List<MaterialGroup> list = null;
                    try {
                        if (cacheEntry != null && cacheEntry.value != null) {
                            list = AbstractModel.parseMaterialGroups(new JSONArray(cacheEntry.value), pid, tid);
                        }
                    } catch (JSONException e1) {
                        Logger.d(TAG, "failed to parse material groups", e1);
                    }
                    callBack.onException(e, list);
                    Logger.d(TAG, "failed to get material group", e);
                }
            }
        }));

    }

    private int requestMaterialGroup(URI uri, List<Header> headers, CMSFrontRestCallBack<List<MaterialGroup>> callBack, JsonResponse jsonResponse, int depth) throws IOException, JSONException, IllegalBlockSizeException, InvalidKeyException, NoSuchAlgorithmException, InvalidKeySpecException, NoSuchPaddingException, URISyntaxException, BadPaddingException, ParseException {
        if (depth > MAX_RECURSIVE_DEPTH) {
            throw new IOException("Too much recursion:" + MAX_RECURSIVE_DEPTH);
        }
        HttpResponse httpResponse = executeGetRequest(uri, headers, true);
        try {
            int status = httpResponse.getStatusLine().getStatusCode();
            if (status != HttpStatus.SC_OK && status != HttpStatus.SC_NOT_MODIFIED) {
                callBack.onFail(status, MSG_NETWORK_ERROR);
            } else if (status == HttpStatus.SC_OK) {
                JSONObject jsonObject = toJSONObject(httpResponse);
                JSONObject responseHeader = jsonObject.getJSONObject("responseHeader");
                jsonResponse.responseHeader = responseHeader;
                status = responseHeader.getInt("status");
                if (status == HttpStatus.SC_OK) {
                    jsonResponse.response = jsonObject.getJSONObject("response");
                    jsonResponse.lastModified = getLastModified(httpResponse);
                } else if (status == HttpStatus.SC_FORBIDDEN)     //invalid sid
                {
                    getSessionId();
                    return requestMaterialGroup(uri, headers, callBack, jsonResponse, depth++);
                } else {
                    callBack.onFail(status, responseHeader.optString("msg"));
                }
            }
            return status;
        } finally {
            consumEntity(httpResponse);
        }
    }

    /**
     * 获取物料列表
     *
     * @param pid      project id
     * @param tid      tab id
     * @param id       辅助物料id
     * @param pn       page number
     * @param ps       page size
     * @param callBack 不能为null
     */
    public void getMaterials(final long pid, final long tid, final long id, final int pn, final int ps, final Sort sort, final CMSFrontRestCallBack<List<AbstractModel>> callBack) {
        callBack.onSubmit(threadPool.submit(new PriorityTask() {
            @Override
            public void run() {
                int status;
                CacheEntry cacheEntry = null;
                try {
                    List<NameValuePair> params = new ArrayList<NameValuePair>();
                    params.add(new BasicNameValuePair("pid", String.valueOf(pid)));
                    params.add(new BasicNameValuePair("tid", String.valueOf(tid)));
                    params.add(new BasicNameValuePair("id", String.valueOf(id)));
                    params.add(new BasicNameValuePair("pn", String.valueOf(pn)));
                    params.add(new BasicNameValuePair("ps", String.valueOf(ps)));
                    params.add(new BasicNameValuePair("sort", sort.toString()));
                    URI uri = URIUtils.createURI("http", host, port, path + "/materials",
                            urlSuffix + "&" + URLEncodedUtils.format(params, HTTP.UTF_8), null);
                    String key = Utils.getMD5(uri.toString());
                    cacheEntry = cacheService.get(key);
                    JsonResponse jsonResponse = new JsonResponse();
                    if (null == cacheEntry) {   //never visited
                        cacheEntry = new CacheEntry();
                        status = requestMaterials(uri, null, callBack, jsonResponse, 1);
                        if (HttpStatus.SC_OK == status) {
                            JSONArray datas = jsonResponse.response.getJSONArray("datas");
                            cacheEntry.lastModified = jsonResponse.lastModified;
                            cacheEntry.value = datas.toString();
                            cacheService.set(key, cacheEntry);
                            callBack.onSuccess(status, AbstractModel.parseMaterials(datas));
                        }
                    } else {  //visited
                        List<Header> headers = new ArrayList<Header>(1);
                        headers.add(getIfModifiedSinceHeader(cacheEntry.lastModified));
                        status = requestMaterials(uri, headers, callBack, jsonResponse, 1);
                        if (status == HttpStatus.SC_OK) {
                            JSONArray datas = jsonResponse.response.getJSONArray("datas");
                            cacheEntry.lastModified = jsonResponse.lastModified;
                            cacheEntry.value = datas.toString();
                            cacheService.set(key, cacheEntry);
                            callBack.onSuccess(status, AbstractModel.parseMaterials(datas));
                        } else if (status == HttpStatus.SC_NOT_MODIFIED) {
                            callBack.onSuccess(status, AbstractModel.parseMaterials(new JSONArray(cacheEntry.value)));
                        }
                    }
                } catch (Exception e) {
                    List<AbstractModel> list = null;
                    try {
                        if (cacheEntry != null && cacheEntry.value != null) {
                            list = AbstractModel.parseMaterials(new JSONArray(cacheEntry.value));
                        }
                    } catch (JSONException e1) {
                        Logger.d(TAG, "failed to parse materials", e1);
                    }
                    callBack.onException(e, list);
                    Logger.d(TAG, "failed to get materials", e);
                }
            }
        }));
    }


    /**
     * 搜索
     *
     * @param pid      project id
     * @param query    query
     * @param pn       page number
     * @param ps       page size
     * @param callBack 不能为null
     */
    public void search(final long pid, final String query, final int pn, final int ps, final CMSFrontRestCallBack<List<AbstractModel>> callBack) {
        callBack.onSubmit(threadPool.submit(new PriorityTask() {
            @Override
            public void run() {
                int status;
                CacheEntry cacheEntry = null;
                try {
                    List<NameValuePair> params = new ArrayList<NameValuePair>();
                    params.add(new BasicNameValuePair("pid", String.valueOf(pid)));
                    params.add(new BasicNameValuePair("q", query));
                    params.add(new BasicNameValuePair("pn", String.valueOf(pn)));
                    params.add(new BasicNameValuePair("ps", String.valueOf(ps)));
                    URI uri = URIUtils.createURI("http", host, port, path + "/search",
                            urlSuffix + "&" + URLEncodedUtils.format(params, HTTP.UTF_8), null);
                    String key = Utils.getMD5(uri.toString());
                    cacheEntry = cacheService.get(key);
                    JsonResponse jsonResponse = new JsonResponse();
                    if (null == cacheEntry) {   //never visited
                        cacheEntry = new CacheEntry();
                        status = requestMaterials(uri, null, callBack, jsonResponse, 1);
                        if (HttpStatus.SC_OK == status) {
                            JSONArray datas = jsonResponse.response.getJSONArray("datas");
                            cacheEntry.lastModified = jsonResponse.lastModified;
                            cacheEntry.value = datas.toString();
                            cacheService.set(key, cacheEntry);
                            callBack.onSuccess(status, AbstractModel.parseMaterials(datas));
                        }
                    } else {  //visited
                        List<Header> headers = new ArrayList<Header>(1);
                        headers.add(getIfModifiedSinceHeader(cacheEntry.lastModified));
                        status = requestMaterials(uri, headers, callBack, jsonResponse, 1);
                        if (status == HttpStatus.SC_OK) {
                            JSONArray datas = jsonResponse.response.getJSONArray("datas");
                            cacheEntry.lastModified = jsonResponse.lastModified;
                            cacheEntry.value = datas.toString();
                            cacheService.set(key, cacheEntry);
                            callBack.onSuccess(status, AbstractModel.parseMaterials(datas));
                        } else if (status == HttpStatus.SC_NOT_MODIFIED) {
                            callBack.onSuccess(status, AbstractModel.parseMaterials(new JSONArray(cacheEntry.value)));
                        }
                    }
                } catch (Exception e) {
                    List<AbstractModel> list = null;
                    try {
                        if (cacheEntry != null && cacheEntry.value != null) {
                            list = AbstractModel.parseMaterials(new JSONArray(cacheEntry.value));
                        }
                    } catch (JSONException e1) {
                        Logger.d(TAG, "failed to parse materials", e1);
                    }
                    callBack.onException(e, list);
                    Logger.d(TAG, "failed to get materials", e);
                }
            }
        }));
    }


    private int requestMaterials(URI uri, List<Header> headers, CMSFrontRestCallBack<List<AbstractModel>> callBack, JsonResponse jsonResponse, int depth) throws IOException, JSONException, IllegalBlockSizeException, InvalidKeyException, NoSuchAlgorithmException, InvalidKeySpecException, NoSuchPaddingException, URISyntaxException, BadPaddingException, ParseException {
        if (depth > MAX_RECURSIVE_DEPTH) {
            throw new IOException("Too much recursion:" + MAX_RECURSIVE_DEPTH);
        }
        HttpResponse httpResponse = executeGetRequest(uri, headers, true);
        try {
            int status = httpResponse.getStatusLine().getStatusCode();
            if (status != HttpStatus.SC_OK && status != HttpStatus.SC_NOT_MODIFIED) {
                callBack.onFail(status, MSG_NETWORK_ERROR);
            } else if (status == HttpStatus.SC_OK) {
                JSONObject jsonObject = toJSONObject(httpResponse);
                JSONObject responseHeader = jsonObject.getJSONObject("responseHeader");
                jsonResponse.responseHeader = responseHeader;
                status = responseHeader.getInt("status");
                if (status == HttpStatus.SC_OK) {
                    jsonResponse.response = jsonObject.getJSONObject("response");
                    jsonResponse.lastModified = getLastModified(httpResponse);
                } else if (status == HttpStatus.SC_FORBIDDEN)     //invalid sid
                {
                    getSessionId();
                    return requestMaterials(uri, headers, callBack, jsonResponse, depth++);
                } else {
                    callBack.onFail(status, responseHeader.optString("msg"));
                }
            }
            return status;
        } finally {
            consumEntity(httpResponse);
        }
    }


    /**
     * 检查更新
     *
     * @param pkgs     待更新的pkg map(pkgname->versionCode)
     * @param callBack 不能为null
     */
    public void checkUpdates(final Map<String, Integer> pkgs, final CMSFrontRestCallBack<List<AbstractModel>> callBack) {
        callBack.onSubmit(threadPool.submit(new PriorityTask() {
            @Override
            public void run() {
                int status;
                CacheEntry cacheEntry = null;
                try {
                    URI uri = URIUtils.createURI("http", host, port, path + "/checkUpdate",
                            urlSuffix, null);
                    String key = Utils.getMD5(uri.toString() + "->" + pkgs.toString());
                    cacheEntry = cacheService.get(key);
                    JsonResponse jsonResponse = new JsonResponse();
                    if (null == cacheEntry) {   //never visited
                        cacheEntry = new CacheEntry();
                        status = requestUpdates(uri, pkgs, null, callBack, jsonResponse, 1);
                        if (HttpStatus.SC_OK == status) {
                            JSONArray datas = jsonResponse.response.getJSONArray("datas");
                            cacheEntry.lastModified = jsonResponse.lastModified;
                            cacheEntry.value = datas.toString();
                            cacheService.set(key, cacheEntry);
                            callBack.onSuccess(status, AbstractModel.parseMaterials(datas));
                        }
                    } else {  //visited
                        if (System.currentTimeMillis() - cacheEntry.lastModified <= checkUpdateHitCacheInterval) {
                            /**
                             * TODO need review
                             * 如果命中cache并且上次内容的修改时间(参看requestUpdates函数，这个时间就是上次请求时间)距离当前时间
                             * 小于CHECK_UPDATE_HIT_CACHE_INTERVAL，那么直接使用cache中的内容，否在进行一次检查
                             */
                            callBack.onSuccess(HttpStatus.SC_OK, AbstractModel.parseMaterials(new JSONArray(cacheEntry.value)));
                            Logger.d(TAG, "hit cache and less than CHECK_UPDATE_HIT_CACHE_INTERVAL");
                        } else {
                            status = requestUpdates(uri, pkgs, null, callBack, jsonResponse, 1);
                            if (status == HttpStatus.SC_OK) {
                                JSONArray datas = jsonResponse.response.getJSONArray("datas");
                                cacheEntry.lastModified = jsonResponse.lastModified;
                                cacheEntry.value = datas.toString();
                                cacheService.set(key, cacheEntry);
                                callBack.onSuccess(status, AbstractModel.parseMaterials(datas));
                            } else if (status == HttpStatus.SC_NOT_MODIFIED) {
                                callBack.onSuccess(status, AbstractModel.parseMaterials(new JSONArray(cacheEntry.value)));
                            }
                        }
                    }
                } catch (Exception e) {
                    List<AbstractModel> list = null;
                    try {
                        if (cacheEntry != null && cacheEntry.value != null) {
                            list = AbstractModel.parseMaterials(new JSONArray(cacheEntry.value));
                        }
                    } catch (JSONException e1) {
                        Logger.d(TAG, "failed to parse materials", e1);
                    }
                    callBack.onException(e, list);
                    Logger.d(TAG, "failed to get materials", e);
                }
            }
        }));
    }

    private int requestUpdates(URI uri, Map<String, Integer> pkgs, List<Header> headers, CMSFrontRestCallBack<List<AbstractModel>> callBack, JsonResponse jsonResponse, int depth) throws IOException, JSONException, IllegalBlockSizeException, InvalidKeyException, NoSuchAlgorithmException, InvalidKeySpecException, NoSuchPaddingException, URISyntaxException, BadPaddingException, ParseException {
        if (depth > MAX_RECURSIVE_DEPTH) {
            throw new IOException("Too much recursion:" + MAX_RECURSIVE_DEPTH);
        }
        HttpResponse httpResponse = executePostRequest(uri, new JSONObject(pkgs).toString(), headers);
        try {
            int status = httpResponse.getStatusLine().getStatusCode();
            if (status != HttpStatus.SC_OK && status != HttpStatus.SC_NOT_MODIFIED) {
                callBack.onFail(status, MSG_NETWORK_ERROR);
            } else if (status == HttpStatus.SC_OK) {
                JSONObject jsonObject = toJSONObject(httpResponse);
                JSONObject responseHeader = jsonObject.getJSONObject("responseHeader");
                jsonResponse.responseHeader = responseHeader;
                status = responseHeader.getInt("status");
                if (status == HttpStatus.SC_OK) {
                    jsonResponse.response = jsonObject.getJSONObject("response");
                    /**
                     * 此处是post请求，无法304,所以此处的lastModified使用本地的请求时间
                     */
                    jsonResponse.lastModified = System.currentTimeMillis();
                } else if (status == HttpStatus.SC_FORBIDDEN)     //invalid sid
                {
                    getSessionId();
                    return requestUpdates(uri, pkgs, headers, callBack, jsonResponse, depth++);
                } else {
                    callBack.onFail(status, responseHeader.optString("msg"));
                }
            }

            return status;
        } finally {
            consumEntity(httpResponse);
        }
    }

    /**
     * 获取物料详情
     *
     * @param pid      project id
     * @param tid      tab id
     * @param gid      辅助物料id
     * @param id       物料id
     * @param type     物料类型
     * @param callBack 不能为null
     */
    public void getDetail(final long pid, final long tid, final long gid, final long id, final int type, final CMSFrontRestCallBack<AbstractModel> callBack) {
        getDetail(pid, tid, gid, id, type, null, callBack);
    }


        /**
        * 获取物料详情
        *
        * @param pid      project id
        * @param tid      tab id
        * @param gid      辅助物料id
        * @param id       物料id
        * @param type     物料类型
        * @param  source  区分来源，在搜索结果取详情的时候需要传递这个source字段，比如baidu搜索传递字符串baidu，以后切换为点心搜索服务后就不再需要此参数
        * @param callBack 不能为null
        */
    public void getDetail(final long pid, final long tid, final long gid, final long id, final int type, final String source, final CMSFrontRestCallBack<AbstractModel> callBack) {
        callBack.onSubmit(threadPool.submit(new PriorityTask() {
            @Override
            public void run() {
                int status;
                CacheEntry cacheEntry = null;
                try {
                    List<NameValuePair> params = new ArrayList<NameValuePair>();
                    params.add(new BasicNameValuePair("pid", String.valueOf(pid)));
                    params.add(new BasicNameValuePair("tid", String.valueOf(tid)));
                    params.add(new BasicNameValuePair("gid", String.valueOf(gid)));
                    params.add(new BasicNameValuePair("id", String.valueOf(id)));
                    params.add(new BasicNameValuePair("type", String.valueOf(type)));
                    if (source != null) {
                        params.add(new BasicNameValuePair("source", source));
                    }

                    URI uri = URIUtils.createURI("http", host, port, path + "/detail",
                            urlSuffix + "&" + URLEncodedUtils.format(params, HTTP.UTF_8), null);
                    String key = Utils.getMD5(uri.toString());
                    cacheEntry = cacheService.get(key);
                    JsonResponse jsonResponse = new JsonResponse();
                    if (null == cacheEntry) {   //never visited
                        cacheEntry = new CacheEntry();
                        status = requestDetail(uri, null, callBack, jsonResponse, 1);
                        if (HttpStatus.SC_OK == status) {
                            JSONArray datas = jsonResponse.response.getJSONArray("datas");
                            if (datas.length() > 0) {
                                cacheEntry.lastModified = jsonResponse.lastModified;
                                cacheEntry.value = datas.getJSONObject(0).toString();
                                cacheService.set(key, cacheEntry);
                                callBack.onSuccess(status, AbstractModel.parseDetail(datas.getJSONObject(0)));
                            } else {
                                callBack.onSuccess(status, null);
                            }
                        }
                    } else {  //visited
                        List<Header> headers = new ArrayList<Header>(1);
                        headers.add(getIfModifiedSinceHeader(cacheEntry.lastModified));
                        status = requestDetail(uri, headers, callBack, jsonResponse, 1);
                        if (status == HttpStatus.SC_OK) {
                            JSONArray datas = jsonResponse.response.getJSONArray("datas");
                            if (datas.length() > 0) {
                                cacheEntry.lastModified = jsonResponse.lastModified;
                                cacheEntry.value = datas.getJSONObject(0).toString();
                                cacheService.set(key, cacheEntry);
                                callBack.onSuccess(status, AbstractModel.parseDetail(datas.getJSONObject(0)));
                            } else {
                                callBack.onSuccess(status, null);
                            }
                        } else if (status == HttpStatus.SC_NOT_MODIFIED) {
                            callBack.onSuccess(status, AbstractModel.parseDetail(new JSONObject(cacheEntry.value)));
                        }
                    }
                } catch (Exception e) {
                    AbstractModel abstractModel = null;
                    try {
                        if (cacheEntry != null && cacheEntry.value != null) {
                            abstractModel = AbstractModel.parseDetail(new JSONObject(cacheEntry.value));
                        }
                    } catch (JSONException e1) {
                        Logger.d(TAG, "failed to parse detail", e1);
                    }
                    callBack.onException(e, abstractModel);
                    Logger.d(TAG, "failed to get detail", e);
                }
            }
        }));
    }


    /**
     * 获取物料详情
     *
     * @param pid      project id
     * @param pkg      包名
     * @param callBack 不能为null
     */
    public void getDetail(final long pid, final String pkg, final CMSFrontRestCallBack<AbstractModel> callBack) {
        callBack.onSubmit(threadPool.submit(new PriorityTask() {
            @Override
            public void run() {
                int status;
                CacheEntry cacheEntry = null;
                try {
                    List<NameValuePair> params = new ArrayList<NameValuePair>();
                    params.add(new BasicNameValuePair("pid", String.valueOf(pid)));
                    params.add(new BasicNameValuePair("pkgName", pkg));


                    URI uri = URIUtils.createURI("http", host, port, path + "/detailByPkg",
                            urlSuffix + "&" + URLEncodedUtils.format(params, HTTP.UTF_8), null);
                    String key = Utils.getMD5(uri.toString());
                    cacheEntry = cacheService.get(key);
                    JsonResponse jsonResponse = new JsonResponse();
                    if (null == cacheEntry) {   //never visited
                        cacheEntry = new CacheEntry();
                        status = requestDetail(uri, null, callBack, jsonResponse, 1);
                        if (HttpStatus.SC_OK == status) {
                            JSONArray datas = jsonResponse.response.getJSONArray("datas");
                            if (datas.length() > 0) {
                                cacheEntry.lastModified = jsonResponse.lastModified;
                                cacheEntry.value = datas.getJSONObject(0).toString();
                                cacheService.set(key, cacheEntry);
                                callBack.onSuccess(status, AbstractModel.parseDetail(datas.getJSONObject(0)));
                            } else {
                                callBack.onSuccess(status, null);
                            }
                        }
                    } else {  //visited
                        List<Header> headers = new ArrayList<Header>(1);
                        headers.add(getIfModifiedSinceHeader(cacheEntry.lastModified));
                        status = requestDetail(uri, headers, callBack, jsonResponse, 1);
                        if (status == HttpStatus.SC_OK) {
                            JSONArray datas = jsonResponse.response.getJSONArray("datas");
                            if (datas.length() > 0) {
                                cacheEntry.lastModified = jsonResponse.lastModified;
                                cacheEntry.value = datas.getJSONObject(0).toString();
                                cacheService.set(key, cacheEntry);
                                callBack.onSuccess(status, AbstractModel.parseDetail(datas.getJSONObject(0)));
                            } else {
                                callBack.onSuccess(status, null);
                            }
                        } else if (status == HttpStatus.SC_NOT_MODIFIED) {
                            callBack.onSuccess(status, AbstractModel.parseDetail(new JSONObject(cacheEntry.value)));
                        }
                    }
                } catch (Exception e) {
                    AbstractModel abstractModel = null;
                    try {
                        if (cacheEntry != null && cacheEntry.value != null) {
                            abstractModel = AbstractModel.parseDetail(new JSONObject(cacheEntry.value));
                        }
                    } catch (JSONException e1) {
                        Logger.d(TAG, "failed to parse detail", e1);
                    }
                    callBack.onException(e, abstractModel);
                    Logger.d(TAG, "failed to get detail", e);
                }
            }
        }));
    }


    private int requestDetail(URI uri, List<Header> headers, CMSFrontRestCallBack<AbstractModel> callBack, JsonResponse jsonResponse, int depth) throws IOException, JSONException, IllegalBlockSizeException, InvalidKeyException, NoSuchAlgorithmException, InvalidKeySpecException, NoSuchPaddingException, URISyntaxException, BadPaddingException, ParseException {
        if (depth > MAX_RECURSIVE_DEPTH) {
            throw new IOException("Too much recursion:" + MAX_RECURSIVE_DEPTH);
        }
        HttpResponse httpResponse = executeGetRequest(uri, headers, true);
        try {
            int status = httpResponse.getStatusLine().getStatusCode();
            if (status != HttpStatus.SC_OK && status != HttpStatus.SC_NOT_MODIFIED) {
                callBack.onFail(status, MSG_NETWORK_ERROR);
            } else if (status == HttpStatus.SC_OK) {
                JSONObject jsonObject = toJSONObject(httpResponse);
                JSONObject responseHeader = jsonObject.getJSONObject("responseHeader");
                jsonResponse.responseHeader = responseHeader;
                status = responseHeader.getInt("status");
                if (status == HttpStatus.SC_OK) {
                    jsonResponse.response = jsonObject.getJSONObject("response");
                    jsonResponse.lastModified = getLastModified(httpResponse);
                } else if (status == HttpStatus.SC_FORBIDDEN)     //invalid sid
                {
                    getSessionId();
                    return requestDetail(uri, headers, callBack, jsonResponse, depth++);
                } else {
                    callBack.onFail(status, responseHeader.optString("msg"));
                }
            }
            return status;
        } finally {
            consumEntity(httpResponse);
        }
    }


    private synchronized void getSessionId() throws URISyntaxException, InvalidKeySpecException, NoSuchAlgorithmException, IllegalBlockSizeException, InvalidKeyException, NoSuchPaddingException, BadPaddingException, IOException, JSONException {
        URI uri = URIUtils.createURI("http", host, port, path + "/rs",
                urlSuffix, null);

        JSONObject object = new JSONObject();
        try {
            object.put("ms", System.currentTimeMillis());
            object.put("tk", TokenManager.getToken(context));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        String postData = new String(Base64.encode(SecurityUtils.RSAEncrypt(object.toString(), PUBLIC_KEY), Base64.DEFAULT));
        HttpResponse httpResponse = executePostRequest(uri, postData, null);
        try {
            int status = httpResponse.getStatusLine().getStatusCode();
            if (status == HttpStatus.SC_OK) {
                JSONObject jsonObject = toJSONObject(httpResponse);
                JSONObject responseHeader = jsonObject.getJSONObject("responseHeader");
                status = responseHeader.getInt("status");
                if (status == HttpStatus.SC_OK) {
                    String session = jsonObject.getJSONObject("response").getString("session");
                    String jsonContent = new String(SecurityUtils.RSADecrypt(Base64.decode(session, Base64.DEFAULT), PUBLIC_KEY));
                    this.sid = new JSONObject(jsonContent).getString("sid");
                } else {
                    throw new IOException("failed to get sid,status:" + status + ",msg:" + responseHeader.optString("msg"));
                }
            } else {
                throw new IOException("failed to get sid,status:" + status);
            }
        } finally {
            consumEntity(httpResponse);
        }
    }

    /**
     * 释放资源
     */
    public void shutdown() {
        HttpClientFactory.shutdown();
        threadPool.shutdownNow();
        cacheService.shutdown();
        dropInstance();
    }

    private static synchronized void dropInstance() {
        INSTANCE = null;
    }


    private static long getLastModified(HttpResponse httpResponse) throws java.text.ParseException {
        Header header = httpResponse.getFirstHeader("Last-Modified");
        if (null != header) {
            String gmt = header.getValue();
            return Utils.parseDateInGMT(gmt).getTime();
        }
        return 0;
    }

    private static Header getIfModifiedSinceHeader(long lastModified) {
        return new BasicHeader("If-Modified-Since", Utils.formatDateToGMT(new Date(lastModified)));
    }

    private static JSONObject toJSONObject(HttpResponse httpResponse) throws IOException, JSONException {
        HttpEntity entity = httpResponse.getEntity();
        InputStream is = entity.getContent();
        int contentLength = (int) entity.getContentLength();
        if (contentLength < 0) {
            contentLength = 1024;
        }
        Header encodingHeader = entity.getContentEncoding();
        if (encodingHeader != null && encodingHeader.getValue().indexOf("gzip") != -1) {
            is = new GZIPInputStream(is);
        }
        Reader reader = new InputStreamReader(is, HTTP.UTF_8);
        CharArrayBuffer buffer = new CharArrayBuffer(contentLength);
        char[] tmp = new char[1024];
        int l;
        while ((l = reader.read(tmp)) != -1) {
            buffer.append(tmp, 0, l);
        }
        return new JSONObject(buffer.toString());
    }


    private HttpResponse executePostRequest(URI uri, String body, List<Header> headers) throws IOException {
        String req = uri.toString();
        if (req.indexOf('?') > 0) {
            req += "&sid=" + sid + "&cv=" + CMS_FRONT_PROTOCOL_VERSION + "&cflv=" + VERSION_CmsFrontLib.getVersion();
        }
        HttpPost httpPost = new HttpPost(req);
        if (headers != null) {
            for (Header header : headers) {
                httpPost.addHeader(header);
            }
        }
        httpPost.addHeader(HEADER_CONTENT_GZIP);
        httpPost.addHeader(HEADER_ACCEPT_GZIP);
        httpPost.setEntity(new ByteArrayEntity(Utils.zip(body)));//压缩包体，减少传输
        Logger.v(TAG, "request uri:" + httpPost.getURI() + ",body:" + body + ",headers:" + Arrays.asList(httpPost.getAllHeaders()));
        httpPost.getParams().setParameter("http.socket.timeout", SOCKET_TIME_OUT);
        DefaultHttpClient defaultHttpClient = HttpClientFactory.getThreadSafeClient();
        try {
            return defaultHttpClient.execute(httpPost);
        } catch (IOException e) {
            httpPost.abort();
            throw e;
        }
    }

    private HttpResponse executeGetRequest(URI uri, List<Header> headers, boolean enableGZip) throws IOException {
        String req = uri.toString();
        if (req.indexOf('?') > 0) {
            req += "&sid=" + sid + "&cv=" + CMS_FRONT_PROTOCOL_VERSION + "&cflv=" + VERSION_CmsFrontLib.getVersion();
        }

        HttpGet httpget = new HttpGet(req);
        if (headers != null) {
            for (Header header : headers) {
                httpget.addHeader(header);
            }
        }
        if (enableGZip) {
            httpget.addHeader(HEADER_ACCEPT_GZIP);
        }
        Logger.v(TAG, "request uri: " + httpget.getURI() + ", headers: " + Arrays.asList(httpget.getAllHeaders()));
        httpget.getParams().setParameter("http.socket.timeout", SOCKET_TIME_OUT);
        DefaultHttpClient defaultHttpClient = HttpClientFactory.getThreadSafeClient();
        try {
            return defaultHttpClient.execute(httpget);
        } catch (IOException e) {
            httpget.abort();
            throw e;
        }
    }

    private abstract class PriorityTask implements Runnable, Comparable<PriorityTask> {
        public int priority = API_PRIORITY;

        public PriorityTask() {
            this(API_PRIORITY);
        }

        public PriorityTask(int priority) {
            this.priority = priority;
        }

        @Override
        public int compareTo(final PriorityTask o) {
            return this.priority - o.priority;
        }
    }


    private static class JsonResponse {
        public JSONObject response;
        public JSONObject responseHeader;
        public long lastModified;
    }
}

