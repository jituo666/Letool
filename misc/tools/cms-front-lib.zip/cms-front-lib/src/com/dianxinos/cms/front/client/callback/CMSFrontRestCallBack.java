package com.dianxinos.cms.front.client.callback;

import java.util.concurrent.Future;

/**
 * 请求调用的callback
 * @author  wangweiwei
 * Date: 4/4/12
 * Time: 5:05 PM
 */
public interface CMSFrontRestCallBack<T> {
    /**
     * 任务提交的回调函数
     * @param future  可以用来取消任务
     */
    public void onSubmit(Future<?> future);

    /**
     * 任务失败的回调
     * @param status
     * @param msg
     */
    public void onFail(int status, String msg);

    /**
     * 出现异常的回调,但也可能会返回数据
     * @param e  异常
     * @param data 如果cache中有合法数据，返回cache中数据，否在返回null
     */
    public void onException(Exception e, T data);

    /**
     * 成功调用
     * @param status 请求的状态码，一般情况可以忽略
     * @param data    请求的数据
     */
    public void onSuccess(int status, T data);

    /**
     * 进度回调，目前没有这样的回调，后续增加的接口有可能会回调这个函数
     * @param percent
     */
    public void onProgress(double percent);
}
