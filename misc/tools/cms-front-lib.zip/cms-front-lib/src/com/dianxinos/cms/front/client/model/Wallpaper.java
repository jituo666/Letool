package com.dianxinos.cms.front.client.model;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 壁纸
 * @author : wangweiwei
 * Date: 3/30/12
 * Time: 8:05 PM
 */
public class Wallpaper extends AbstractModel {
    /**
     * 描述
     */
    public String shortDesc;
    /**
     * 作者
     */
    public String author;
    /**
     * 下载次数
     */
    public int downloadCount;

    public String tags;
    public Map<Integer, List<Image>> images;


    /**
     * 扩展字段
     */
    public Wallpaper(JSONObject jsonObject) throws JSONException {
        super(jsonObject);
        this.shortDesc = jsonObject.optString("shortDesc", null);
        this.author = jsonObject.optString("author", null);
        this.downloadCount = jsonObject.getInt("downloadCount");
        this.tags = jsonObject.optString("tags", null);
        this.images = parseImages(jsonObject.optJSONArray("images"));
    }
}
