package com.dianxinos.cms.front.client.provider;

import java.util.HashMap;

import android.content.*;
import android.database.sqlite.SQLiteOpenHelper;
import com.dianxinos.cms.front.client.provider.Record.RecordColumns;

import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;
import android.text.TextUtils;

public class RecordProvider {

    private static final String TAG = RecordProvider.class.getName();

    private static HashMap<String, String> sRecordProjectionMap;

    private static final UriMatcher sUriMatcher;

    private static final int RECORDS = 1;
    private static final int RECORD_ID = 2;

    static {
        sUriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
        sUriMatcher.addURI(Record.AUTHORITY, "records", RECORDS);
        sUriMatcher.addURI(Record.AUTHORITY, "records/#", RECORD_ID);

        sRecordProjectionMap = new HashMap<String, String>();
        sRecordProjectionMap.put(RecordColumns._ID, RecordColumns._ID);
        sRecordProjectionMap.put(RecordColumns.KEY, RecordColumns.KEY);
        sRecordProjectionMap.put(RecordColumns.VALUE, RecordColumns.VALUE);
        sRecordProjectionMap.put(RecordColumns.LAST_ACCESS, RecordColumns.LAST_ACCESS);
        sRecordProjectionMap.put(RecordColumns.LAST_MODIFIED, RecordColumns.LAST_MODIFIED);
        sRecordProjectionMap.put(RecordColumns.VISIT_COUNT, RecordColumns.VISIT_COUNT);
    }

    private SQLiteOpenHelper mOpenHelper;
    private static RecordProvider INSTANCE = null;
    private RecordProvider(Context context)
    {
        mOpenHelper = RecordDatabaseHelper.getInstance(context);

    }
    public synchronized static RecordProvider getInstance(Context context)
    {
        if(INSTANCE==null)
        {
            INSTANCE = new RecordProvider(context);
        }
        return INSTANCE;
    }

//    @Override
//    public boolean onCreate() {
//        mOpenHelper = RecordDatabaseHelper.getInstance(getContext());
//        return true;
//    }

    public int count() {
        SQLiteDatabase db = mOpenHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("select count(*) from " + RecordDatabaseHelper.RECORD_TABLE_NAME, null);
        int retVal = 0;
        if (null != cursor && cursor.moveToFirst()) {
            retVal = cursor.getInt(0);
        }
        if (null != cursor) {
            cursor.close();
        }
        return retVal;
    }

    public int delete(Uri uri, String selection, String[] selectionArgs) {
        SQLiteDatabase db = mOpenHelper.getWritableDatabase();
        int count;
        switch (sUriMatcher.match(uri)) {
            case RECORDS:
                count = db.delete(RecordDatabaseHelper.RECORD_TABLE_NAME, selection, selectionArgs);
                break;
            case RECORD_ID:
                String recordId = uri.getPathSegments().get(1);
                count = db.delete(RecordDatabaseHelper.RECORD_TABLE_NAME, RecordColumns._ID + "=" + recordId
                        + (!TextUtils.isEmpty(selection) ? " AND (" + selection + ')' : ""), selectionArgs);
                break;
            default:
                throw new IllegalArgumentException("Unknown URI " + uri);
        }
//        getContext().getContentResolver().notifyChange(uri, null);
        return count;
    }

    public String getType(Uri uri) {
        switch (sUriMatcher.match(uri)) {
            case RECORDS:
                return RecordColumns.CONTENT_TYPE;
            case RECORD_ID:
                return RecordColumns.CONTENT_ITEM_TYPE;
            default:
                throw new IllegalArgumentException("Unknown URI " + uri);
        }
    }

    public Uri insert(Uri uri, ContentValues initialValues) {
        // Validate the requested uri
        if (sUriMatcher.match(uri) != RECORDS) {
            throw new IllegalArgumentException("Unknown URI " + uri);
        }

        ContentValues values;
        if (initialValues != null) {
            values = new ContentValues(initialValues);
        } else {
            values = new ContentValues();
        }

        Long now = System.currentTimeMillis();

        // Make sure that the fields are all set
        if (!values.containsKey(RecordColumns.LAST_MODIFIED)) {
            values.put(RecordColumns.LAST_MODIFIED, now);
        }

        if (!values.containsKey(RecordColumns.LAST_ACCESS)) {
            values.put(RecordColumns.LAST_ACCESS, now);
        }

        if (values.containsKey(RecordColumns.VALUE) == false) {
            values.put(RecordColumns.VALUE, "");
        }

        SQLiteDatabase db = mOpenHelper.getWritableDatabase();
        long rowId = db.insert(RecordDatabaseHelper.RECORD_TABLE_NAME, RecordColumns.KEY, values);
        if (rowId > 0) {
            Uri noteUri = ContentUris.withAppendedId(RecordColumns.CONTENT_URI, rowId);
//            getContext().getContentResolver().notifyChange(noteUri, null);
            return noteUri;
        }

        throw new SQLException("Failed to insert row into " + uri);
    }

    public Cursor query(Uri uri, String[] projection, String selection,
                        String[] selectionArgs, String sortOrder) {

        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();
        qb.setTables(RecordDatabaseHelper.RECORD_TABLE_NAME);

        switch (sUriMatcher.match(uri)) {
            case RECORDS:
                qb.setProjectionMap(sRecordProjectionMap);
                break;
            case RECORD_ID:
                qb.setProjectionMap(sRecordProjectionMap);
                qb.appendWhere(RecordColumns._ID + "=" + uri.getPathSegments().get(1));
                break;
            default:
                throw new IllegalArgumentException("Unknown URI " + uri);
        }

        // If no sort order is specified use the default
        String orderBy;
        if (TextUtils.isEmpty(sortOrder)) {
            orderBy = RecordColumns.DEFAULT_SORT_ORDER;
        } else {
            orderBy = sortOrder;
        }

        // Get the database and run the query
        SQLiteDatabase db = mOpenHelper.getReadableDatabase();
        Cursor c = qb.query(db, projection, selection, selectionArgs, null, null, orderBy);

        // Tell the cursor what uri to watch, so it knows when its source data changes
//        c.setNotificationUri(getContext().getContentResolver(), uri);
        return c;
    }

    public int update(Uri uri, ContentValues values, String selection,
                      String[] selectionArgs) {
        SQLiteDatabase db = mOpenHelper.getWritableDatabase();
        int count;
        if (null != values && !values.containsKey(RecordColumns.LAST_ACCESS)) {
            values.put(RecordColumns.LAST_ACCESS, System.currentTimeMillis());
        }
        switch (sUriMatcher.match(uri)) {
            case RECORDS:
                count = db.update(RecordDatabaseHelper.RECORD_TABLE_NAME, values, selection, selectionArgs);
                break;

            case RECORD_ID:
                String noteId = uri.getPathSegments().get(1);
                count = db.update(RecordDatabaseHelper.RECORD_TABLE_NAME, values, RecordColumns._ID + "=" + noteId
                        + (!TextUtils.isEmpty(selection) ? " AND (" + selection + ')' : ""), selectionArgs);
                break;

            default:
                throw new IllegalArgumentException("Unknown URI " + uri);
        }

//        getContext().getContentResolver().notifyChange(uri, null);
        return count;
    }
}