package com.dianxinos.cms.front.client.cache;

import android.content.Context;
import android.os.Environment;

import java.io.File;

/**
 * CacheService接口定义
 * @author  wangweiwei
 * Date: 4/4/12
 * Time: 4:28 PM
 */
public interface CacheService {
    /**
     * sd卡cache的根目录
     */
    public static final File CACHE_BASE_DIR = new File(Environment.getExternalStorageDirectory(), ".cms/cache");
    /**
     * 图片cache的目录
     */
    public static final File IMAGE_CACHE_BASE_DIR = new File(CACHE_BASE_DIR, "img");

    /**
     * 获取cache  value
     * @param key cache key
     * @return cache value,@see CacheEntry
     */
    public CacheEntry get(String key);

    /**
     * 设置cache
     * @param key cache key
     * @param entry   cache value
     * @return  true设置成，false设置失败
     */
    public boolean set(String key, CacheEntry entry);

    /**
     * 删除cache
     * @param key cache key
     * @return  true 成功删除,false删除失败或不存在
     */
    public boolean delete(String key);

    /**
     * 关闭cache，释放资源
     */
    public void shutdown();

    /**
     * 获取最大容量
     * @return  最大容量
     */
    int getMaximumCapacity();
}
