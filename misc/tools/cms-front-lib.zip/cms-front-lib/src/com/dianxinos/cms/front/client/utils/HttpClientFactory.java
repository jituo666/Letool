package com.dianxinos.cms.front.client.utils;

import android.content.Context;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.text.TextUtils;
import com.dianxinos.cms.front.client.log.Logger;
import org.apache.http.HttpHost;
import org.apache.http.NoHttpResponseException;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpRequestRetryHandler;
import org.apache.http.client.params.ClientPNames;
import org.apache.http.client.params.CookiePolicy;
import org.apache.http.client.params.HttpClientParams;
import org.apache.http.conn.params.ConnRoutePNames;
import org.apache.http.conn.routing.HttpRoute;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.DefaultHttpRequestRetryHandler;
import org.apache.http.impl.conn.SingleClientConnManager;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.params.HttpProtocolParams;
import org.apache.http.protocol.HttpContext;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * @author wangweiwei
 */
public class HttpClientFactory {
    private static final String TAG = HttpClientFactory.class.getName();
    private static DefaultHttpClient client;


    public synchronized static void shutdown() {
        if (client != null) {
            client.getConnectionManager().shutdown();
            client = null;
        }
    }

    public synchronized static DefaultHttpClient getThreadSafeClient() {
        if (client != null)
            return client;

        SchemeRegistry schemeRegistry = new SchemeRegistry();
        schemeRegistry.register(new Scheme("http", PlainSocketFactory.getSocketFactory(), 80));
        schemeRegistry.register(new Scheme("https", SSLSocketFactory.getSocketFactory(), 443));

        HttpParams params = new BasicHttpParams();
        ThreadSafeClientConnManager cm = new ThreadSafeClientConnManager(params, schemeRegistry);
        client = new DefaultHttpClient(cm, params);
        HttpConnectionParams.setSoTimeout(client.getParams(), 30000);
        HttpConnectionParams.setConnectionTimeout(client.getParams(),
                30000);
        client.getParams().setIntParameter(ClientPNames.MAX_REDIRECTS, 10);
        HttpClientParams.setCookiePolicy(client.getParams(), CookiePolicy.BROWSER_COMPATIBILITY);
        HttpProtocolParams
                .setUserAgent(
                        client.getParams(),
                        "Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.2.18) Gecko/20110628 Ubuntu/10.04 (lucid) Firefox/3.6.18");
        client.setHttpRequestRetryHandler(new DefaultHttpRequestRetryHandler(3, true));

        return client;
    }

    /**
     * 设置代理
     *
     * @param client
     * @param proxyInfo
     */
    public static void setProxy(DefaultHttpClient client, Map<String, Object> proxyInfo) {
        if (proxyInfo != null) {
            String proxyAddr = null;
            int proxyPort = -1;
            String proxyUser = null;
            String proxyPass = null;
            if (proxyInfo != null) {
                proxyAddr = (String) proxyInfo.get("host");
                proxyPort = proxyInfo.containsKey("port") ? ((Number) proxyInfo.get("port")).intValue() : -1;
                proxyUser = (String) proxyInfo.get("user");
                proxyPass = (String) proxyInfo.get("password");
            }

            if (!TextUtils.isEmpty(proxyAddr) && proxyPort > 0) {
                Logger.i(TAG, "connecting with proxy, addr:" + proxyAddr + ", port:" + proxyPort);
                HttpHost proxy = new HttpHost(proxyAddr, proxyPort, "http");
                client.getParams()
                        .setParameter(ConnRoutePNames.DEFAULT_PROXY, proxy);
                if (!TextUtils.isEmpty(proxyUser) && !TextUtils.isEmpty(proxyPass)) {
                    client.getCredentialsProvider().setCredentials(new AuthScope(proxyAddr, proxyPort),
                            new UsernamePasswordCredentials(proxyUser, proxyPass));
                } else {
                    client.getCredentialsProvider().clear();
                }
            } else {
                client.getParams()
                        .setParameter(ConnRoutePNames.DEFAULT_PROXY, null);
                client.getCredentialsProvider().clear();
            }
        }
    }

    /**
     * 获取代理信息
     *
     * @param mContext
     * @return 包含代理信息的Map
     */
    public static Map<String, Object> getProxyInfo(Context mContext) {
        final Uri PREFERRED_APN_URI = Uri.parse("content://telephony/carriers/preferapn");
        ConnectivityManager cm = (ConnectivityManager) mContext.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = cm.getActiveNetworkInfo();
        if (networkInfo != null) {
            if (networkInfo.getType() == ConnectivityManager.TYPE_MOBILE) {
                Cursor cursor = null;
                try {
                    cursor = mContext.getContentResolver().query(PREFERRED_APN_URI, null, null, null, null);
                    if (cursor != null && cursor.moveToFirst()) {
                        final String host = cursor.getString(cursor.getColumnIndex("proxy"));
                        final int port = cursor.getInt(cursor.getColumnIndex("port"));
                        final String user = cursor.getString(cursor.getColumnIndex("user"));
                        final String pass = cursor.getString(cursor.getColumnIndex("password"));
                        return new HashMap<String, Object>() {{
                            put("host", host);
                            put("port", port);
                            put("user", user);
                            put("password", pass);
                        }};
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    if (cursor != null) {
                        cursor.close();
                    }
                }
            }
        }
        return null;
    }
}