package com.dianxinos.cms.front.client.provider;

import android.net.Uri;
import android.provider.BaseColumns;

/**
 * 数据库Cache的Record
 */
public final class Record {
    public static final String AUTHORITY = "com.dianxinos.cms.front.client.provider.Record";

    // This class cannot be instantiated
    private Record() {
    }

    /**
     * records table
     */
    public static final class RecordColumns implements BaseColumns {
        // This class cannot be instantiated
        private RecordColumns() {
        }

        /**
         * The content:// style URL for this table
         */
        public static final Uri CONTENT_URI = Uri.parse("content://" + AUTHORITY + "/records");

        /**
         * The MIME type of {@link #CONTENT_URI} providing a directory of records.
         */
        public static final String CONTENT_TYPE = "vnd.android.cursor.dir/vnd.google.record";

        /**
         * The MIME type of a {@link #CONTENT_URI} sub-directory of a single note.
         */
        public static final String CONTENT_ITEM_TYPE = "vnd.android.cursor.item/vnd.google.record";

        /**
         * The default sort order for this table
         */
        public static final String DEFAULT_SORT_ORDER = "lastAccess DESC";

        /**
         * the key of the record
         * <P>Type: TEXT</P>
         */
        public static final String KEY = "key";

        /**
         * the value of the record
         * <P>Type: TEXT</P>
         */
        public static final String VALUE = "value";


        /**
         * The timestamp for when the record was last modified
         * <P>Type: INTEGER (long from System.curentTimeMillis())</P>
         */
        public static final String LAST_ACCESS = "lastAccess";

        /**
         * The timestamp for when the record was last modified
         * <P>Type: INTEGER (long from System.curentTimeMillis())</P>
         */
        public static final String LAST_MODIFIED = "lastModified";

        /**
         * The times of the record was visited.
         * <P>Type: INTEGER </P>
         */
        public static final String VISIT_COUNT = "visitCount";
    }

}