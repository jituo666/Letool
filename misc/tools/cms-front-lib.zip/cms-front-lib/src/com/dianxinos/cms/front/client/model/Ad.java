package com.dianxinos.cms.front.client.model;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;
import java.util.Map;

/**
 * 广告数据类型
 * @author  wangweiwei
 * Date: 3/30/12
 * Time: 8:05 PM
 */
public class Ad extends AbstractModel {
    /**
     * 广告类型
     */
    public int adType;
    /**
     * 广告内容
     */
    public String content;

    /**
     * 图片type->list of image of this type
     */
    public Map<Integer, List<Image>> images;



    public Ad(JSONObject jsonObject) throws JSONException {
        super(jsonObject);
        this.adType = jsonObject.getInt("adType");
        this.content = jsonObject.optString("content",null);
        this.images = parseImages(jsonObject.optJSONArray("images"));
    }
}
