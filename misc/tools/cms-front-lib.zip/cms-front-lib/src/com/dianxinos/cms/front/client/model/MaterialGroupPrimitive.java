package com.dianxinos.cms.front.client.model;

import java.util.List;

/**
 * Project接口tab下马的物料组信息(id,广告组id)
 * @author  wangweiwei
 * Date: 3/30/12
 * Time: 8:05 PM
 */
public class MaterialGroupPrimitive {
    public long id;
    public long sort;
    public List<Long> ad;
    public MaterialGroupPrimitive(long id, long sort, List<Long> ad)
    {
        this.id = id;
        this.sort = sort;
        this.ad = ad;
    }
}
