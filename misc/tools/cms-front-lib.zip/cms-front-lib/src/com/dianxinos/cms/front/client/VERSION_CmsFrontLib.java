package com.dianxinos.cms.front.client;

/**
 * Cms front lib版本
 * @author  wangweiwei
 * Date: 4/20/12
 * Time: 1:21 PM
 */
public class VERSION_CmsFrontLib {
    //TODO 提测时更新版本号
    public static final String VERSION = "VERSION-CmsFrontLib-1.1.2";

    public static String getVersion() {
        return VERSION.substring("VERSION-CmsFrontLib-".length());
    }
}
