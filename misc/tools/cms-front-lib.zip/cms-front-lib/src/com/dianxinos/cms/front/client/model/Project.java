package com.dianxinos.cms.front.client.model;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * 项目
 * @author  wangweiwei
 * Date: 3/30/12
 * Time: 8:04 PM
 */
public class Project  extends AbstractModel{
    public List<Tab> tabs;

    public Project(JSONObject json) throws JSONException {
        super(json);
        tabs = getTabs(json.optJSONArray("tabs"), id);
    }

    private static List<Tab> getTabs(JSONArray jsonArray, long pid) throws JSONException {
        if (null == jsonArray || jsonArray.length() == 0) {
            return null;
        }
        int len = jsonArray.length();
        List<Tab> tabs = new ArrayList<Tab>(len);
        for (int i = 0; i < len; i++) {
            JSONObject tab = jsonArray.getJSONObject(i);
            tabs.add(new Tab(tab, pid));
        }
        return tabs;
    }

    public int getHomeTab() {
        if (tabs == null)
            return -1;

        for (int i = 0; i < tabs.size(); i++) {
            Tab t = tabs.get(i);
            if (t.home)
                return i;
        }

        return 0;
    }

    public int getTabCount() {
        if (tabs != null) {
            return tabs.size();
        }
        return 0;
    }
}
