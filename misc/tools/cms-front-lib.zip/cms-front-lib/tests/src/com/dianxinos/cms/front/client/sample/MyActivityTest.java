package com.dianxinos.cms.front.client.sample;

import android.test.ActivityInstrumentationTestCase2;
import android.util.Log;
import com.dianxinos.cms.front.client.CMSFrontRestService;
import com.dianxinos.cms.front.client.cache.CacheEntry;
import com.dianxinos.cms.front.client.cache.CacheService;
import com.dianxinos.cms.front.client.cache.DBCacheService;
import com.dianxinos.cms.front.client.log.Logger;
import com.dianxinos.cms.front.client.model.*;
import com.dianxinos.cms.front.client.provider.Record;
import com.dianxinos.cms.front.client.provider.RecordProvider;
import com.dianxinos.cms.front.client.sample.callback.*;
import com.dianxinos.cms.front.client.utils.Utils;
import org.apache.http.HttpStatus;

import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

//import org.unitils.dbunit.annotation.DataSet;

/**
 * This is a simple framework for a test of an Application.  See
 * {@link android.test.ApplicationTestCase ApplicationTestCase} for more information on
 * how to write and extend Application tests.
 * <p/>
 * To run this test, you can type:
 * adb shell am instrument -w \
 * -e class com.dianxinos.cms.front.client.sample.MyActivityTest \
 * com.dianxinos.cms.front.client.sample.tests/android.test.InstrumentationTestRunner
 */

//@DataSet("full.xml")
public class MyActivityTest extends ActivityInstrumentationTestCase2<MyActivity> {
    private CMSFrontRestService cmsFrontRestService;
    //刷新cache时间,单位是秒
    int stepTims=5;
    public MyActivityTest() {
        super("com.dianxinos.cms.front.client.sample", MyActivity.class);
        setEnvironment();
    }

    @Override
    protected void setUp() throws Exception {
        super.setUp();
        DBCacheService.INITIAL_DELAY=stepTims;
        DBCacheService.PERIOD=stepTims;
        cmsFrontRestService = CMSFrontRestService.getInstance(getInstrumentation().getTargetContext());
        RecordProvider.getInstance(getInstrumentation().getTargetContext()).delete(Record.RecordColumns.CONTENT_URI, null, null);
    }

    @Override
    protected void tearDown() throws java.lang.Exception {
        //cmsFrontRestService.shutdown();
    }

    public void setEnvironment() {
        //设置测试环境
        CMSFrontRestService.host = "10.18.102.163";
        CMSFrontRestService.port = 3724;
        CMSFrontRestService.path = "cms";
        Logger.LEVEL = Log.VERBOSE;
    }

    public void testCMSFrontLibProject() throws InterruptedException {
        //第一次调用返回sc_ok
        Project project = getProject(HttpStatus.SC_OK);
        //再次调用返回sc_not_modified;请求已存在于cache中
        project = getProject(HttpStatus.SC_NOT_MODIFIED);

    }

    public void testCMSFrontMaterialGroups() throws InterruptedException {
        List<MaterialGroup> materialGroups = getMaterialGroups(HttpStatus.SC_OK);
        materialGroups = getMaterialGroups(HttpStatus.SC_NOT_MODIFIED);
    }

    public void testCMSFrontMaterials() throws InterruptedException {
        List<AbstractModel> materials = getMaterials(HttpStatus.SC_OK);
        materials = getMaterials(HttpStatus.SC_NOT_MODIFIED);
    }

    public void testCMSFrontDetail() throws InterruptedException {
        Apk apk = (Apk) getDetail(HttpStatus.SC_OK);
        apk = (Apk) getDetail(HttpStatus.SC_NOT_MODIFIED);
    }

    public void testCMSFrontImage() throws InterruptedException {
        getImage(HttpStatus.SC_OK);
        getImage(HttpStatus.SC_NOT_MODIFIED);
    }

//    public void testCMSFrontUpdate() throws InterruptedException {
//        checkUpdates(HttpStatus.SC_OK);
//        checkUpdates(HttpStatus.SC_OK);
//    }

    public void testCMSFrontNoneProject() throws InterruptedException {
        ProjectCallBackTest projectCallBackTest = new ProjectCallBackTest();
        cmsFrontRestService.getProject("lib-test-none", projectCallBackTest);
        utils.waitNotify(projectCallBackTest);

        assertEquals(HttpStatus.SC_NOT_FOUND, projectCallBackTest.status);
        assertNull(projectCallBackTest.project);
    }

    public void testCMSFrontNoneMaterialGroups() throws InterruptedException {
        MaterialGroupCallBackTest materialGroupCallBackTest = new MaterialGroupCallBackTest();
        long gid = 404L;
        cmsFrontRestService.getMaterialGroup(404, 1, new long[]{gid}, materialGroupCallBackTest);
        utils.waitNotify(materialGroupCallBackTest);

        assertEquals(HttpStatus.SC_OK, materialGroupCallBackTest.status);
        assertEquals(0, materialGroupCallBackTest.materialGroups.size());
    }

    public void testCMSFrontNoneMaterials() throws InterruptedException {
        MaterialsCallBackTest materialsCallBackTest = new MaterialsCallBackTest();
        cmsFrontRestService.getMaterials(404, 1, 404, 1, 10, CMSFrontRestService.Sort.DEFAULT,materialsCallBackTest);
        utils.waitNotify(materialsCallBackTest);

        assertEquals(HttpStatus.SC_BAD_REQUEST, materialsCallBackTest.status);
        assertNull(materialsCallBackTest.materials);
    }

    public void testCMSFrontNoneDetail() throws InterruptedException {
        DetailCallBackTest detailCallBackTest = new DetailCallBackTest();
        cmsFrontRestService.getDetail(404, 1, 5, 404, 1, detailCallBackTest);
        utils.waitNotify(detailCallBackTest);
        assertEquals(HttpStatus.SC_NOT_FOUND, detailCallBackTest.status);
    }

    public void testCMSFrontNoneImage() throws InterruptedException {
        ImageCallBackTest imageCallBackTest = new ImageCallBackTest();
        cmsFrontRestService.getImage("http://mk.cdn.jccjd.com/cms/test/upload/images/dianxinos_960_800nnnnnn_image_1fe4733f-d358-4063-bf29-a2f858fe700e.jpeg", imageCallBackTest);
        utils.waitNotify(imageCallBackTest);

        assertEquals(HttpStatus.SC_NOT_FOUND, imageCallBackTest.status);
        assertNull(imageCallBackTest.image);

    }

//    public void testCMSFrontNoneUpdate() throws InterruptedException {
//        MaterialsCallBackTest materialsCallBackTest = new MaterialsCallBackTest();
//        Map<String, Integer> pkgs = new HashMap<String, Integer>() {{
//            put("com.dianxinos.cms.none", 1);
//        }};
//        cmsFrontRestService.checkUpdates(pkgs, materialsCallBackTest);
//        utils.waitNotify(materialsCallBackTest);
//        List<AbstractModel> list = materialsCallBackTest.materials;
//        assertNotNull(list);
//        assertEquals(0, list.size());
//
//
//    }
    public void testCMSFrontAPKDetail() throws InterruptedException {
        getAPKDetail(HttpStatus.SC_OK);
        getAPKDetail(HttpStatus.SC_NOT_MODIFIED);
    }
    public void testCMSFrontNoneAPKDetail() throws InterruptedException {
        DetailCallBackTest detailCallBackTest = new DetailCallBackTest();
        cmsFrontRestService.getDetail(404, "com.dianxinos.cms.none.no", detailCallBackTest);
        utils.waitNotify(detailCallBackTest);
        assertEquals(HttpStatus.SC_NOT_FOUND, detailCallBackTest.status);
    }


    public void testCMSFrontSearch() throws InterruptedException {
        getSearch(HttpStatus.SC_OK);
        getSearch(HttpStatus.SC_NOT_MODIFIED);
    }

    public void testCMSFrontMaterialGroupWithTop() throws InterruptedException {
        List<MaterialGroup> materials = getMaterialGroupWithTop(HttpStatus.SC_OK);
        materials = getMaterialGroupWithTop(HttpStatus.SC_NOT_MODIFIED);
    }

    public void testCachePerformance() throws InterruptedException {
        Logger.d("test:", "evict start performance test .... ");
        CacheEntry cacheEntry = null;
        CacheService cacheService = DBCacheService.getInstance(getInstrumentation().getTargetContext());

        //清除数据,并重新加入3050条记录.
        RecordProvider.getInstance(getInstrumentation().getTargetContext()).delete(Record.RecordColumns.CONTENT_URI, null, null);
        sleepBySecond(stepTims);

        String json = "{\"id\":1,\"tabs\":[{\"id\":1,\"datas\":{\"102\":[{\"id\":1}],\"101\":[{\"id\":6}],\"100\":[{\"id\":5}],\"103\":[{\"id\":4}]},\"home\":false,\"title\":\"tab8453c0\",\"type\":\"APK\",\"description\":\"projectDescription8453c0\"}]}";
        for (int i = 0; i < 3050; i++) {
            String key = Utils.getMD5("pkg.name.index" + i);
            cacheEntry = new CacheEntry();
            cacheEntry.lastModified = 1334734178000L + i * 1000;
            cacheEntry.value = json;
            cacheService.set(key, cacheEntry);

        }
        Logger.d("test:", "evict setup data complete: 3050 ");
        //等待一段时间,查看性能变化；(大数据量,数据不变的时候)
        sleepBySecond(stepTims*2+1);

        //测试数据发生变化时的,响应时间;测试时间为5个更新周期
        for (int i = 0; i < stepTims*10*5; i++) {

            String key = Utils.getMD5("pkg.name.index.update" + i);
            cacheEntry = new CacheEntry();
            cacheEntry.lastModified = 1334734178000L + i * 1000;
            cacheEntry.value = json;
            cacheService.set(key, cacheEntry);
            //每秒加入10条记录;
            if(i%10 == 0) {
                Logger.d("test:", "evict update cache, insert 10 recorders");
                sleepBySecond(1);
            }
        }
        sleepBySecond(stepTims+1);
    }
    public static void sleepBySecond(int s){
        try {
            Thread.sleep(s*1000);
        } catch (InterruptedException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
    }

    private InputStream getImage(int expectedStatus) throws InterruptedException {

        ImageCallBackTest imageCallBackTest = new ImageCallBackTest();
        cmsFrontRestService.getImage("http://mk.cdn.jccjd.com/cms/test/upload/images/dianxinos_960_800_image_1fe4733f-d358-4063-bf29-a2f858fe700e.jpeg", imageCallBackTest);
        utils.waitNotify(imageCallBackTest);

        assertNotNull(imageCallBackTest.image);
        assertEquals(expectedStatus, imageCallBackTest.status);
        return imageCallBackTest.image;
    }

    private Project getProject(int expectedStatus) throws InterruptedException {

        ProjectCallBackTest projectCallBackTest = new ProjectCallBackTest();
        cmsFrontRestService.getProject("lib-test", projectCallBackTest);
        utils.waitNotify(projectCallBackTest);

        assertEquals(expectedStatus, projectCallBackTest.status);
        Project project = projectCallBackTest.project;
        assertNotNull(project);
        assertEquals(1, project.id);
        assertEquals(1, project.tabs.size());
        assertEquals(true, project.tabs.get(0).datas.containsKey(102));

        MaterialGroupPrimitive mgp = project.tabs.get(0).datas.get(102).get(0);

        assertNotNull(mgp);
        assertEquals(1, mgp.id);
        return project;
    }

    private List<MaterialGroup> getMaterialGroups(int expectedStatus) throws InterruptedException {
        MaterialGroupCallBackTest materialGroupCallBackTest = new MaterialGroupCallBackTest();
        long gid = 1L;
        cmsFrontRestService.getMaterialGroup(1, 1, new long[]{gid}, materialGroupCallBackTest);
        utils.waitNotify(materialGroupCallBackTest);
        assertEquals(materialGroupCallBackTest.status, expectedStatus);
        List<MaterialGroup> materialGroups = materialGroupCallBackTest.materialGroups;
        assertEquals(materialGroups.size(), 1);
        MaterialGroup materialGroup = materialGroups.get(0);
        assertEquals(materialGroup.total, 1);
        assertEquals(materialGroup.type, 102);
        assertEquals(materialGroup.contentType, 2);
        return materialGroups;
    }

    private List<AbstractModel> getMaterials(int expectedStatus) throws InterruptedException {

        MaterialsCallBackTest materialsCallBackTest = new MaterialsCallBackTest();
        cmsFrontRestService.getMaterials(1, 1, 5, 1, 10, CMSFrontRestService.Sort.DEFAULT, materialsCallBackTest);
        utils.waitNotify(materialsCallBackTest);

        assertEquals(materialsCallBackTest.status, expectedStatus);
        List<AbstractModel> materials = materialsCallBackTest.materials;
        assertEquals(materials.size(), 1);
        AbstractModel abstractModel = materials.get(0);
        assertTrue(abstractModel instanceof Apk);
        Apk apk = (Apk) abstractModel;
        assertEquals("com.dianxinos.cms", apk.pkg);
        assertEquals("AppEx", apk.title);
        assertEquals("DXAppEx_DXR_1.5.9", apk.versionName);
        return materials;
    }
    private List<MaterialGroup> getMaterialGroupWithTop(int expectedStatus) throws InterruptedException {

        MaterialGroupCallBackTest materialGroupCallBackTest = new MaterialGroupCallBackTest();
        long gid = 1L;
        cmsFrontRestService.getMaterialGroup(1, 1, new long[]{gid}, 1, materialGroupCallBackTest);
        utils.waitNotify(materialGroupCallBackTest);
        assertEquals(materialGroupCallBackTest.status, expectedStatus);
        List<MaterialGroup> materialGroups = materialGroupCallBackTest.materialGroups;
        assertEquals(materialGroups.size(), 1);
        MaterialGroup materialGroup = materialGroups.get(0);
        assertEquals(materialGroup.total, 1);
        assertEquals(materialGroup.type, 102);
        assertEquals(materialGroup.contentType, 2);
        //added one content data
        assertEquals(materialGroup.datas.size(),1);
        AbstractModel AdContent = materialGroup.datas.get(0);
        assertTrue(AdContent instanceof Ad);
        return materialGroups;
    }

    private List<AbstractModel> getSearch(int expectedStatus) throws InterruptedException {

        MaterialsCallBackTest materialsCallBackTest = new MaterialsCallBackTest();
        cmsFrontRestService.search(1, "点心",1, 5, materialsCallBackTest);
        utils.waitNotify(materialsCallBackTest);

        assertEquals(materialsCallBackTest.status, expectedStatus);
        List<AbstractModel> materials = materialsCallBackTest.materials;
        assertEquals(materials.size(), 5);
        for(int i = 0; i < materials.size(); i++){
            AbstractModel abstractModel = materials.get(i);
            assertTrue(abstractModel instanceof Apk);
            Apk apk = (Apk) abstractModel;
            assertTrue(apk.pkg.indexOf("dianxinos") != -1);
        }
        return materials;
    }

    public List<AbstractModel> checkUpdates(int expectedStatus) throws InterruptedException {
        MaterialsCallBackTest materialsCallBackTest = new MaterialsCallBackTest();
        Map<String, Integer> pkgs = new HashMap<String, Integer>() {{
            put("com.dianxinos.cms", 1);
        }};
        cmsFrontRestService.checkUpdates(pkgs, materialsCallBackTest);
        utils.waitNotify(materialsCallBackTest);
        List<AbstractModel> list = materialsCallBackTest.materials;
        assertNotNull(list);
        assertEquals(1, list.size());
        assertEquals(expectedStatus, materialsCallBackTest.status);
        return list;
    }

    public AbstractModel getDetail(int expectedStatus) throws InterruptedException {

        DetailCallBackTest detailCallBackTest = new DetailCallBackTest();
        cmsFrontRestService.getDetail(1, 1, 5, 1, 1, detailCallBackTest);
        utils.waitNotify(detailCallBackTest);

        assertEquals(detailCallBackTest.status, expectedStatus);
        AbstractModel detail = detailCallBackTest.material;
        assertNotNull(detail);
        assertTrue(detail instanceof Apk);
        Apk apk = (Apk) detail;
        assertEquals(159, apk.versionCode);
        assertEquals("DXAppEx_DXR_1.5.9", apk.versionName);
        assertNull(apk.images);
        assertEquals(1153226, apk.size);
        assertEquals("请选择...", apk.categories);
        return detail;
    }
    public AbstractModel getAPKDetail(int expectedStatus) throws InterruptedException {

        DetailCallBackTest detailCallBackTest = new DetailCallBackTest();
        cmsFrontRestService.getDetail(1,"com.dianxinos.cms", detailCallBackTest);
        utils.waitNotify(detailCallBackTest);

        assertEquals(detailCallBackTest.status, expectedStatus);
        AbstractModel detail = detailCallBackTest.material;
        assertNotNull(detail);
        assertTrue(detail instanceof Apk);
        Apk apk = (Apk) detail;
        assertEquals(159, apk.versionCode);
        assertEquals("DXAppEx_DXR_1.5.9", apk.versionName);
        assertNull(apk.images);
        assertEquals(1153226, apk.size);
        assertEquals("请选择...", apk.categories);
        return detail;
    }


}
