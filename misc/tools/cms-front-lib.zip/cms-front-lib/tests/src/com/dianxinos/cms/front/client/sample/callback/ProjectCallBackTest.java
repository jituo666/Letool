package com.dianxinos.cms.front.client.sample.callback;

import android.util.Log;
import com.dianxinos.cms.front.client.callback.CMSFrontRestCallBack;
import com.dianxinos.cms.front.client.model.Project;

import java.util.concurrent.Future;

/**
 * Created with IntelliJ IDEA.
 * User: wangweiwei
 * Date: 4/6/12
 * Time: 4:54 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProjectCallBackTest implements CMSFrontRestCallBack<Project> {
    private static final String TAG = ProjectCallBackTest.class.getName();
    public Project project;
    public int status;

    @Override
    public void onSubmit(Future future) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public void onFail(int status, String msg) {
        this.status = status;
        Log.w(TAG, "status:" + status + ",msg:" + msg);
        utils.safeNotify(this);
    }

    @Override
    public void onException(Exception e, Project data) {
        Log.w(TAG, e);
        this.project = data;
        utils.safeNotify(this);
    }

    @Override
    public void onSuccess(int status, Project data) {
        this.status = status;
        project = data;
        utils.safeNotify(this);
    }

    @Override
    public void onProgress(double percent) {
        //To change body of implemented methods use File | Settings | File Templates.
    }
}
