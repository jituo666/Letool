package com.dianxinos.cms.front.client.sample.callback;

import android.util.Log;
import com.dianxinos.cms.front.client.callback.CMSFrontRestCallBack;
import com.dianxinos.cms.front.client.model.AbstractModel;

import java.util.List;
import java.util.concurrent.Future;

/**
 * Created with IntelliJ IDEA.
 * User: wangweiwei
 * Date: 4/6/12
 * Time: 4:54 PM
 * To change this template use File | Settings | File Templates.
 */
public class MaterialsCallBackTest implements CMSFrontRestCallBack<List<AbstractModel>> {
    private static final String TAG = MaterialsCallBackTest.class.getName();
    public List<AbstractModel> materials;
    public int status;

    @Override
    public void onSubmit(Future future) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public void onFail(int status, String msg) {
        this.status = status;
        Log.w(TAG, "status:" + status + ",msg:" + msg);
        utils.safeNotify(this);
    }

    @Override
    public void onException(Exception e,List<AbstractModel> data) {
        Log.w(TAG, e);
        this.materials = data;
        utils.safeNotify(this);
    }

    @Override
    public void onSuccess(int status, List<AbstractModel> data) {
        this.status = status;
        this.materials = data;
        utils.safeNotify(this);
    }

    @Override
    public void onProgress(double percent) {
    }
}
