package com.dianxinos.cms.front.client.sample.callback;

import android.util.Log;
import com.dianxinos.cms.front.client.callback.CMSFrontRestCallBack;
import com.dianxinos.cms.front.client.model.AbstractModel;

import java.io.File;
import java.io.InputStream;
import java.util.concurrent.Future;

/**
 * Created with IntelliJ IDEA.
 * User: wangweiwei
 * Date: 4/6/12
 * Time: 4:54 PM
 * To change this template use File | Settings | File Templates.
 */
public class ImageCallBackTest implements CMSFrontRestCallBack<InputStream> {
    private static final String TAG = ImageCallBackTest.class.getName();
    public InputStream image;
    public int status;

    @Override
    public void onSubmit(Future future) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public void onFail(int status, String msg) {
        this.status = status;
        Log.w(TAG, "status:" + status + ",msg:" + msg);
        utils.safeNotify(this);
    }

    @Override
    public void onException(Exception e, InputStream data) {
        Log.w(TAG, e);
        this.image = data;
        utils.safeNotify(this);
    }

    @Override
    public void onSuccess(int status, InputStream data) {
        this.status = status;
        image = data;
        utils.safeNotify(this);
    }

    @Override
    public void onProgress(double percent) {
    }
}
