package com.dianxinos.cms.front.client.sample.callback;

import com.dianxinos.cms.front.client.callback.CMSFrontRestCallBack;
import junit.framework.Assert;

/**
 * Created by IntelliJ IDEA.
 * User: guofu
 * Date: 12-4-18
 * Time: 上午10:54
 * To change this template use File | Settings | File Templates.
 */
public class utils {

    public static void safeNotify(CMSFrontRestCallBack callBack){
        synchronized (callBack){
            callBack.notify();
        }
    }
    public static void waitNotify(CMSFrontRestCallBack callBack){
        synchronized (callBack){
            try{
                callBack.wait(10000);
            } catch (InterruptedException e){
                Assert.fail("InterruptedException:" + e.toString());

            }
        }
    }
}
