#UMENG SDK EXAMPLE (Android)#
Example application for [UMENG SDK](http://git.fm/android/umeng-sdk)(Android). Find the app on [Google Play ![Foo](https://play.google.com/static/client/images/1282043220-favicon.ico)](https://play.google.com/). 

The new example application utlize the ActionBar and Dashboard design patterns imported in Android 3.0. Check [iosched](http://code.google.com/p/iosched/) for a quick reference. The following screenshot illustrates what the two design patterns look like.
![](http://iosched.googlecode.com/hg/art/screen.png)

Check design documentation for detail. [UMENG SDK Application](https://docs.google.com/a/umeng.com/document/d/1Y6yZv_PDfVHUhsGBSB8atPEw5PF4R7CW9Xx7ggEOwX4/edit#heading=h.ndy62ngc8jbg)


Each activity now has a action bar. So when implement your example activity, please inherit it from `com.umeng.ui.BaseSinglePaneActivity` and override `onCreatePane()` to return a `Fragment`, which stands for the pane under the action bar. See `UmengHome` for example.

